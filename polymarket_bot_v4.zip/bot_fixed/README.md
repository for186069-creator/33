# Polymarket Quant Bot

> Automated market-making / edge-capturing bot for Polymarket BTC Up/Down binary markets.
> Runs in **paper mode** by default — no real money touched until you flip the switch.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│                        polymarket_bot/                               │
│                                                                      │
│  app/                                                                │
│  ├── main.py            ← Entry point, lifespan, scheduler          │
│  ├── core/                                                           │
│  │   ├── config.py      ← All settings (env-driven)                 │
│  │   └── db.py          ← Async SQLAlchemy engine                   │
│  ├── db/                                                             │
│  │   ├── models.py      ← Trade, MarketSnapshot ORM                 │
│  │   └── init_db.py     ← CREATE TABLE on first run                 │
│  ├── services/                                                       │
│  │   ├── market_feed.py     ← WS subscriber + MarketState cache     │
│  │   ├── fair_value.py      ← Weighted mid + imbalance + decay      │
│  │   ├── signal_engine.py   ← edge detection + Kelly sizing         │
│  │   ├── order_manager.py   ← Paper fill / EIP-712 live order       │
│  │   ├── position_tracker.py← TP/SL/expiry + P&L calculation        │
│  │   ├── risk_manager.py    ← Daily loss / consecutive loss guards  │
│  │   └── snapshot_service.py← Periodic DB snapshots for charts      │
│  ├── admin/                                                          │
│  │   └── api.py         ← FastAPI router (metrics, trades, risk)    │
│  └── static/                                                         │
│      └── index.html     ← Admin dashboard (Chart.js, auto-refresh)  │
└──────────────────────────────────────────────────────────────────────┘
```

### Data flow (every 2 seconds)

```
MarketFeed (WS) ──→ MarketState dict
                          │
                          ▼
                  SignalEngine.scan()
                  └─ FairValue.compute()
                  └─ Kelly sizing
                          │
                     signal list
                          │
                          ▼
                  RiskManager.approve()
                  └─ open positions count
                  └─ daily loss check
                  └─ consecutive losses
                          │
                     approved signal
                          │
                          ▼
                  OrderManager.execute()
                  └─ paper: fill in DB
                  └─ live:  EIP-712 → CLOB API
                          │
                          ▼
                   Trade row in SQLite
                          │
                    (every 2s)
                          ▼
                  PositionTracker.update()
                  └─ TP / SL / near-expiry
                  └─ P&L → RiskManager
```

---

## Quick Start

### 1. Install dependencies

```bash
cd polymarket_bot
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env — defaults are fine for paper mode:
#   PAPER_TRADING=True
#   PAPER_BALANCE_USDC=1000.0
```

### 3. Run

```bash
python -m app.main
# or:
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000** to see the live dashboard.

---

## Paper Mode vs Live Mode

| | Paper | Live |
|---|---|---|
| `PAPER_TRADING` env | `True` | `False` |
| Orders | Written to SQLite only | Signed EIP-712 → CLOB API |
| Wallet needed | No | Yes — Polygon + MATIC + USDC |
| Recommended first | ✓ 500+ trades | After winrate ≥ 52% |

### Going Live

1. Create a dedicated Polygon wallet (never reuse personal wallet)
2. Fund with USDC and ~0.5 MATIC for gas
3. Set in `.env`:
   ```
   PAPER_TRADING=False
   POLYGON_PRIVATE_KEY=0x...
   POLYGON_WALLET_ADDRESS=0x...
   ```
4. Start with small `KELLY_FRACTION=0.05` until live performance matches paper

---

## Fair Value Model

```
fair_value = clamp(baseline + imbalance_adj × time_factor, 0.01, 0.99)
```

| Component | Formula | Purpose |
|---|---|---|
| `baseline` | √-weighted mid from order book depth | Robust mid-price |
| `imbalance_adj` | `(bid_depth − ask_depth) / total × 0.015` | Short-term pressure |
| `time_factor` | Linear fade-out in last 5 min | Reduce model weight near oracle |

---

## Signal Logic

```python
edge_yes = fair_value - ask          # buy YES if positive
edge_no  = (1 - fair_value) - (1-bid)  # buy NO if positive

if edge > MIN_EDGE (0.03):  → TradeSignal
```

**Kelly sizing:**
```
b = (1 - price) / price          # net odds
f = (p×b − (1−p)) / b            # full Kelly
size = min(f × 0.25 × bankroll, MAX_POSITION_SIZE_USD)
```

---

## Risk Controls

| Guard | Threshold | Action |
|---|---|---|
| Open positions | ≤ 5 | Reject new signals |
| Daily loss | −$200 | Halt trading |
| Single position | ≤ $100 | Kelly cap |
| Market exposure | ≤ 20% bankroll | Reject oversized |
| Consecutive losses | 10 | Halt + log critical |

Resume via **POST /api/risk/resume** or the dashboard button.

---

## Admin API

| Endpoint | Method | Description |
|---|---|---|
| `/api/health` | GET | Service health |
| `/api/dashboard` | GET | All KPIs in one call |
| `/api/trades` | GET | Trade list (filter by resolution) |
| `/api/markets` | GET | Live market states |
| `/api/snapshots/{id}` | GET | Price history for charting |
| `/api/risk` | GET | Risk status |
| `/api/risk/resume` | POST | Un-halt trading |
| `/api/paper/reset` | POST | Wipe all paper trades |
| `/api/analytics/pnl_by_market` | GET | P&L breakdown by market |

---

## Success Criteria

Before switching to live:

- [ ] ≥ 500 paper trades completed
- [ ] Win rate ≥ 52% over last 200 trades
- [ ] Avg edge at entry ≥ 0.03
- [ ] Avg P&L per trade > $0 (net of spread)
- [ ] Sharpe ratio > 1.0
- [ ] No consecutive-loss halts in last 100 trades

---

## Performance Targets

| Metric | Target |
|---|---|
| Win rate | 54–58% |
| Trades / hour | 20–35 |
| Avg edge at entry | 0.035–0.055 |
| Daily P&L (1k bankroll) | $15–$40 |
| Max drawdown | < 15% |

---

## Project Structure

```
polymarket_bot/
├── requirements.txt
├── .env.example
├── README.md
└── app/
    ├── __init__.py
    ├── main.py
    ├── core/
    │   ├── config.py
    │   └── db.py
    ├── db/
    │   ├── models.py
    │   └── init_db.py
    ├── services/
    │   ├── market_feed.py
    │   ├── fair_value.py
    │   ├── signal_engine.py
    │   ├── order_manager.py
    │   ├── position_tracker.py
    │   ├── risk_manager.py
    │   └── snapshot_service.py
    ├── admin/
    │   └── api.py
    └── static/
        └── index.html
```

---

## Important Notes

- **Polygon gas**: ~$0.001/tx in MATIC, keep 0.5 MATIC in wallet
- **BTC oracle**: resolution via Pyth on-chain — no manipulation risk
- **USDC only**: all P&L in USDC, no volatile base currency risk
- **EIP-712**: private key never leaves your machine — signatures are local
- **Binary contract math**: max loss = position size (if wrong), max gain = size × (1/price − 1)

С Богом! 🎲
