from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Mode
    paper_trading: bool = True
    paper_balance_usdc: float = 1000.0

    # Wallet / Auth
    polygon_private_key: str = ""
    polygon_wallet_address: str = ""
    clob_api_key: str = ""
    clob_api_secret: str = ""
    clob_api_passphrase: str = ""

    # Polymarket API
    clob_base_url: str = "https://clob.polymarket.com"
    ws_url: str = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

    # BTC Feed
    btc_feed_enabled: bool = True

    # Risk
    max_open_positions: int = 4
    max_daily_loss_usd: float = 150.0
    max_position_size_usd: float = 25.0
    max_exposure_per_market: float = 0.25
    stop_trading_consecutive_losses: int = 8

    # Strategy — налаштовані під BS-модель
    min_edge: float = 0.04         # 4% мінімальний edge (після спреду)
    kelly_fraction: float = 0.12   # консервативний Kelly
    signal_check_interval_sec: int = 5
    snapshot_interval_sec: int = 10

    # Admin
    admin_host: str = "127.0.0.1"
    admin_port: int = 8000
    secret_key: str = "change-me-in-production"
    database_url: str = "sqlite+aiosqlite:///./polymarket_bot.db"

settings = Settings()
