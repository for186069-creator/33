"""
app/admin/api.py — v2
REST endpoints for admin/monitoring.
New: /api/btc, /api/arb, GET /api/config
"""
from __future__ import annotations

import math
from datetime import date, datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.db import get_db
from app.db.models import MarketSnapshot, Resolution, Trade

admin_router = APIRouter(tags=["admin"])

_risk_manager = None
_market_feed = None
_position_tracker = None
_btc_feed = None


def inject_services(risk, feed, tracker, btc_feed=None):
    global _risk_manager, _market_feed, _position_tracker, _btc_feed
    _risk_manager = risk
    _market_feed = feed
    _position_tracker = tracker
    _btc_feed = btc_feed


# ── Config ────────────────────────────────────────────────────────────────────

class LotSizeUpdate(BaseModel):
    max_position_size_usd: float

@admin_router.get("/config")
async def get_config():
    return {
        "max_position_size_usd": settings.max_position_size_usd,
        "min_edge": settings.min_edge,
        "kelly_fraction": settings.kelly_fraction,
        "max_daily_loss_usd": settings.max_daily_loss_usd,
        "paper_trading": settings.paper_trading,
        "btc_feed_enabled": settings.btc_feed_enabled,
    }

@admin_router.post("/config/lot_size")
async def set_lot_size(body: LotSizeUpdate):
    if body.max_position_size_usd < 1 or body.max_position_size_usd > 10000:
        raise HTTPException(400, "Lot size must be between $1 and $10000")
    settings.max_position_size_usd = body.max_position_size_usd
    return {"ok": True, "max_position_size_usd": settings.max_position_size_usd}


# ── BTC feed ──────────────────────────────────────────────────────────────────

@admin_router.get("/btc")
async def btc_status():
    if not _btc_feed:
        return {"ready": False, "price": None}
    return {
        "ready": _btc_feed.ready,
        "price": round(_btc_feed.price, 2),
        "momentum_pct": round(_btc_feed.momentum * 100, 4),
        "price_1m_ago": round(_btc_feed.price_1m_ago, 2),
    }


# ── Arbitrage ─────────────────────────────────────────────────────────────────

@admin_router.get("/diagnostics")
async def signal_diagnostics():
    """Show BS fair value for all active markets — useful for debugging."""
    if not _market_feed:
        return []
    from app.services.fair_value import fair_value_components
    result = []
    for m in _market_feed.active_markets():
        comps = fair_value_components(m)
        yes_edge = comps["fair_value"] - m.ask
        no_edge  = (1 - comps["fair_value"]) - (1 - m.bid)
        result.append({
            "market": m.market_name,
            "bid": round(m.bid, 4),
            "ask": round(m.ask, 4),
            "spread": round(m.spread, 4),
            "fair_value": comps["fair_value"],
            "btc_price": comps.get("btc_price"),
            "strike": comps.get("strike"),
            "ttr_hours": comps.get("ttr_hours"),
            "bs_probability": comps.get("bs_probability"),
            "vol_pct": comps.get("btc_vol_annual_pct"),
            "signal_source": comps.get("signal_source"),
            "yes_edge": round(yes_edge, 4),
            "no_edge":  round(no_edge, 4),
            "best_edge": round(max(yes_edge, no_edge), 4),
            "tradeable": max(yes_edge, no_edge) > 0.04,
        })
    result.sort(key=lambda x: x["best_edge"], reverse=True)
    return result

@admin_router.get("/arb")
async def arb_opportunities():
    if not _market_feed:
        return []
    from app.services.fair_value import detect_arbitrage
    markets = _market_feed.active_markets()
    return detect_arbitrage(markets)


# ── Dashboard ─────────────────────────────────────────────────────────────────

@admin_router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Trade))
    trades: list[Trade] = list(result.scalars().all())

    closed = [t for t in trades if t.resolution != Resolution.OPEN]
    wins   = [t for t in closed if t.resolution == Resolution.WIN]

    total_pnl = sum(t.pnl_usdc or 0.0 for t in closed)
    win_rate  = (len(wins) / len(closed) * 100) if closed else 0.0
    avg_edge  = (sum(t.edge_at_entry for t in trades) / len(trades)) if trades else 0.0
    avg_pnl   = (total_pnl / len(closed)) if closed else 0.0

    sharpe = _compute_sharpe(closed)
    max_dd = _compute_max_drawdown(closed)

    cutoff = datetime.utcnow() - timedelta(hours=24)
    recent = [t for t in trades if t.opened_at and t.opened_at >= cutoff]
    tph = len(recent) / 24.0 if recent else 0.0

    try:
        bankroll = await _position_tracker.get_bankroll(db) if _position_tracker else settings.paper_balance_usdc
    except Exception:
        bankroll = settings.paper_balance_usdc

    btc_info = None
    if _btc_feed and _btc_feed.ready:
        btc_info = {
            "price": round(_btc_feed.price, 2),
            "momentum_pct": round(_btc_feed.momentum * 100, 4),
        }

    return {
        "bankroll_usdc": round(bankroll, 2),
        "total_trades": len(trades),
        "open_trades": len(trades) - len(closed),
        "closed_trades": len(closed),
        "win_rate_pct": round(win_rate, 2),
        "total_pnl_usdc": round(total_pnl, 4),
        "avg_edge_at_entry": round(avg_edge, 6),
        "avg_pnl_per_trade_usdc": round(avg_pnl, 4),
        "sharpe_ratio": round(sharpe, 4),
        "max_drawdown_pct": round(max_dd, 4),
        "trades_per_hour_24h": round(tph, 2),
        "btc": btc_info,
        "risk": _risk_manager.status if _risk_manager else {
            "halted": False, "halt_reason": "",
            "open_positions": 0, "daily_pnl_usdc": 0.0,
            "consecutive_losses": 0,
            "limits": {
                "max_daily_loss_usd": settings.max_daily_loss_usd,
                "max_position_size_usd": settings.max_position_size_usd,
                "stop_consecutive_losses": settings.stop_trading_consecutive_losses,
            },
        },
    }


# ── Trades ────────────────────────────────────────────────────────────────────

@admin_router.get("/trades")
async def list_trades(
    limit: int = 100, offset: int = 0,
    resolution: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(Trade).order_by(Trade.opened_at.desc()).offset(offset).limit(limit)
    if resolution:
        try:
            q = q.where(Trade.resolution == Resolution[resolution.upper()])
        except KeyError:
            raise HTTPException(400, f"Invalid resolution: {resolution}")
    result = await db.execute(q)
    return [_trade_to_dict(t) for t in result.scalars().all()]


@admin_router.get("/trades/{trade_id}")
async def get_trade(trade_id: int, db: AsyncSession = Depends(get_db)):
    trade = await db.get(Trade, trade_id)
    if not trade:
        raise HTTPException(404, "Trade not found")
    return _trade_to_dict(trade)


# ── Markets ───────────────────────────────────────────────────────────────────

@admin_router.get("/markets")
async def list_markets():
    if not _market_feed:
        return []
    from app.services.fair_value import fair_value_components
    from app.services.btc_feed import parse_strike_from_name
    markets = _market_feed.all_markets()
    result = []
    for m in markets:
        item = {
            "market_id": m.market_id,
            "market_name": m.market_name,
            "bid": round(m.bid, 6),
            "ask": round(m.ask, 6),
            "mid": round(m.mid, 6),
            "spread": round(m.spread, 6),
            "volume_24h": round(m.volume_24h, 2),
            "time_to_resolution_sec": round(m.time_to_resolution, 1),
            "active": m.active,
            "strike": parse_strike_from_name(m.market_name),
        }
        result.append(item)
    return result


# ── Snapshots ─────────────────────────────────────────────────────────────────

@admin_router.get("/snapshots/{market_id}")
async def market_snapshots(
    market_id: str, hours: int = 1,
    db: AsyncSession = Depends(get_db),
):
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    result = await db.execute(
        select(MarketSnapshot)
        .where(MarketSnapshot.market_id == market_id)
        .where(MarketSnapshot.captured_at >= cutoff)
        .order_by(MarketSnapshot.captured_at.asc())
        .limit(5000)
    )
    return [
        {"ts": s.captured_at.isoformat(), "bid": s.bid, "ask": s.ask, "mid": s.mid}
        for s in result.scalars().all()
    ]


# ── Risk controls ─────────────────────────────────────────────────────────────

@admin_router.get("/risk")
async def risk_status():
    if not _risk_manager:
        return {}
    return _risk_manager.status


@admin_router.post("/risk/resume")
async def resume_trading():
    if not _risk_manager:
        raise HTTPException(503, "Risk manager not initialised")
    prev_reason = _risk_manager.resume_trading()
    return {"resumed": True, "was_halted_for": prev_reason}


# ── Paper trading ─────────────────────────────────────────────────────────────

@admin_router.post("/paper/reset")
async def reset_paper(db: AsyncSession = Depends(get_db)):
    if not settings.paper_trading:
        raise HTTPException(403, "Not in paper mode")
    result = await db.execute(select(Trade))
    for t in result.scalars().all():
        await db.delete(t)
    await db.commit()
    if _risk_manager:
        _risk_manager._halted = False
        _risk_manager._halt_reason = ""
        _risk_manager._open_positions = {}
        _risk_manager._daily_pnl = 0.0
        _risk_manager._consecutive_losses = 0
    return {"reset": True, "new_balance": settings.paper_balance_usdc}


# ── Analytics ─────────────────────────────────────────────────────────────────

@admin_router.get("/analytics/pnl_by_market")
async def pnl_by_market(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Trade.market_name, func.sum(Trade.pnl_usdc), func.count(Trade.id))
        .where(Trade.resolution != Resolution.OPEN)
        .group_by(Trade.market_name)
        .order_by(func.sum(Trade.pnl_usdc).desc())
    )
    return [
        {"market_name": r[0], "total_pnl": round(r[1] or 0, 4), "trade_count": r[2]}
        for r in result.all()
    ]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _trade_to_dict(t: Trade) -> dict[str, Any]:
    return {
        "id": t.id, "market_id": t.market_id, "market_name": t.market_name,
        "side": t.side.value, "entry_price": t.entry_price, "exit_price": t.exit_price,
        "size_usdc": t.size_usdc, "pnl_usdc": t.pnl_usdc, "pnl_pct": t.pnl_pct,
        "fair_value_at_entry": t.fair_value_at_entry, "edge_at_entry": t.edge_at_entry,
        "resolution": t.resolution.value, "order_id": t.order_id,
        "opened_at": t.opened_at.isoformat() if t.opened_at else None,
        "closed_at": t.closed_at.isoformat() if t.closed_at else None,
    }

def _compute_sharpe(closed: list[Trade]) -> float:
    if len(closed) < 5:
        return 0.0
    by_day: dict[date, float] = {}
    for t in closed:
        if t.closed_at:
            d = t.closed_at.date()
            by_day[d] = by_day.get(d, 0.0) + (t.pnl_usdc or 0.0)
    returns = list(by_day.values())
    if len(returns) < 2:
        return 0.0
    mean = sum(returns) / len(returns)
    var  = sum((r - mean) ** 2 for r in returns) / (len(returns) - 1)
    std  = math.sqrt(var)
    return (mean / std) * math.sqrt(365) if std > 0 else 0.0

def _compute_max_drawdown(closed: list[Trade]) -> float:
    """MaxDD as % of starting bankroll (не від cumulative peak)."""
    from app.core.config import settings
    if not closed:
        return 0.0
    sorted_trades = sorted(closed, key=lambda t: t.opened_at or datetime.utcnow())
    start = settings.paper_balance_usdc
    cumulative = 0.0
    peak_equity = start
    max_dd = 0.0
    for t in sorted_trades:
        cumulative += t.pnl_usdc or 0.0
        equity = start + cumulative
        if equity > peak_equity:
            peak_equity = equity
        dd = (peak_equity - equity) / peak_equity * 100
        if dd > max_dd:
            max_dd = dd
    return max_dd
