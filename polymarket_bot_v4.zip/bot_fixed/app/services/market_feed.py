"""
app/services/market_feed.py — v4
══════════════════════════════════
Виправлений synthetic feed: більше НЕ кодує майбутній напрямок у book.

Проблема попередньої синтетики:
  bid_mult = 1.0 + skew * 30  ← skew = (true_value - mid) = МАЙБУТНЯ інфо
  Бот бачив дисбаланс книги → передбачав напрямок → 70%+ win rate
  Але це шахрайство: реальний order book не кодує майбутній рух!

Виправлення:
  Симетрична книга без дисбалансу. Тільки ціна (mid) рухається.
  Бот може тестувати лише BTC-сигнал, не order book cheating.

Реальні дані:
  - CLOB REST API для книги ордерів (batch endpoint)
  - Polymarket WS для incremental updates
  - Watchdog для авто-відновлення при зависанні
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import aiohttp
import websockets
from websockets.exceptions import ConnectionClosed

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class OrderLevel:
    price: float
    size: float


@dataclass
class MarketState:
    market_id: str
    market_name: str
    condition_id: str

    bid: float = 0.0
    ask: float = 1.0
    last_price: float = 0.5
    volume_24h: float = 0.0
    open_interest: float = 0.0

    bids: list[OrderLevel] = field(default_factory=list)
    asks: list[OrderLevel] = field(default_factory=list)

    end_date_ts: float = 0.0
    active: bool = True
    last_update: float = field(default_factory=time.monotonic)

    @property
    def mid(self) -> float:
        if self.bid and self.ask:
            return (self.bid + self.ask) / 2.0
        return self.last_price

    @property
    def spread(self) -> float:
        return self.ask - self.bid

    @property
    def time_to_resolution(self) -> float:
        return self.end_date_ts - datetime.now(timezone.utc).timestamp()


class MarketFeed:
    WS_URL  = settings.ws_url
    CLOB_URL = settings.clob_base_url
    RECONNECT_DELAY   = 5
    BOOK_POLL_INTERVAL = 3
    WATCHDOG_INTERVAL  = 60

    def __init__(self) -> None:
        self.markets: dict[str, MarketState] = {}
        self._running       = False
        self._ws_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._watchdog_task: asyncio.Task | None = None
        self._subscribed_ids: set[str] = set()
        self._use_synthetic = False
        self._last_ws_message = time.monotonic()

    # ── Public ───────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        await self._fetch_markets()

        if not self._use_synthetic:
            await self._refresh_all_books()
            self._ws_task      = asyncio.create_task(self._ws_loop(), name="mf_ws")
            self._poll_task    = asyncio.create_task(self._book_poll_loop(), name="mf_poll")
            self._watchdog_task= asyncio.create_task(self._watchdog_loop(), name="mf_watchdog")
        else:
            self._ws_task = asyncio.create_task(self._ws_loop(), name="mf_ws")

        logger.info("MarketFeed started — %d markets", len(self.markets))

    async def stop(self) -> None:
        self._running = False
        for t in [self._ws_task, self._poll_task, self._watchdog_task]:
            if t:
                t.cancel()
                try:
                    await t
                except asyncio.CancelledError:
                    pass

    def get_market(self, tid: str) -> MarketState | None:
        return self.markets.get(tid)

    def all_markets(self) -> list[MarketState]:
        return list(self.markets.values())

    def active_markets(self) -> list[MarketState]:
        now_ts = datetime.now(timezone.utc).timestamp()
        return [
            m for m in self.markets.values()
            if m.active
            and m.end_date_ts > now_ts + 60
            and m.bid > 0.005
            and m.ask < 0.995
            and m.spread < 0.50
        ]

    # ── Market discovery ──────────────────────────────────────────────────────

    @staticmethod
    def _parse_end_date(date_str: str) -> float:
        if not date_str:
            return 0.0
        try:
            for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"):
                try:
                    dt = datetime.strptime(date_str[:26], fmt[:len(date_str)])
                    return dt.replace(tzinfo=timezone.utc).timestamp()
                except ValueError:
                    continue
            dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            return dt.timestamp()
        except Exception:
            return 0.0

    async def _fetch_markets(self) -> None:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.CLOB_URL}/markets",
                    params={"active": "true", "closed": "false", "limit": "500"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status != 200:
                        raise ValueError(f"API status {resp.status}")
                    data = await resp.json()

            markets_raw = data if isinstance(data, list) else data.get("data", [])
            now_ts = datetime.now(timezone.utc).timestamp()
            count = 0

            for m in markets_raw:
                name: str = m.get("question", "")
                end_ts = self._parse_end_date(m.get("end_date_iso", ""))
                if end_ts < now_ts + 300:
                    continue

                for token in m.get("tokens", []):
                    tid = token.get("token_id", "")
                    if not tid:
                        continue
                    token_price = float(token.get("price", 0.5) or 0.5)
                    if not (0.01 < token_price < 0.99):
                        continue

                    state = MarketState(
                        market_id=tid,
                        market_name=f"{name} [{token.get('outcome', '')}]",
                        condition_id=m.get("condition_id", ""),
                        end_date_ts=end_ts,
                        last_price=token_price,
                        bid=max(0.01, token_price - 0.02),
                        ask=min(0.99, token_price + 0.02),
                        volume_24h=float(m.get("volume24hr") or m.get("volume") or 0),
                    )
                    self.markets[tid] = state
                    self._subscribed_ids.add(tid)
                    count += 1

            if count == 0:
                raise ValueError("No markets found")

            logger.info("━" * 50)
            logger.info("  ✓ LIVE DATA — %d token markets", count)
            logger.info("━" * 50)

        except Exception as exc:
            logger.error("Market fetch failed: %s → synthetic", exc)
            self._use_synthetic = True
            self.markets.clear()
            self._subscribed_ids.clear()
            self._inject_dummy_markets()

    # ── REST book poll ────────────────────────────────────────────────────────

    async def _book_poll_loop(self) -> None:
        await asyncio.sleep(2)
        while self._running:
            try:
                await self._refresh_all_books()
            except Exception as e:
                logger.debug("Book poll error: %s", e)
            await asyncio.sleep(self.BOOK_POLL_INTERVAL)

    async def _refresh_all_books(self) -> None:
        tids = list(self._subscribed_ids)
        if not tids:
            return
        try:
            async with aiohttp.ClientSession() as session:
                payload = [{"token_id": tid} for tid in tids]
                async with session.post(
                    f"{self.CLOB_URL}/books", json=payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        for book in await resp.json():
                            self._apply_book(book)
                        return

                tasks = [self._fetch_book(session, tid) for tid in tids[:20]]
                await asyncio.gather(*tasks, return_exceptions=True)
        except Exception as e:
            logger.debug("Refresh books error: %s", e)

    async def _fetch_book(self, session: aiohttp.ClientSession, tid: str) -> None:
        try:
            async with session.get(
                f"{self.CLOB_URL}/book", params={"token_id": tid},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status == 200:
                    self._apply_book(await resp.json())
        except Exception:
            pass

    def _apply_book(self, book: dict) -> None:
        tid = book.get("asset_id") or book.get("token_id", "")
        market = self.markets.get(tid)
        if not market:
            return

        def parse(raw: list) -> list[OrderLevel]:
            out = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(book.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(book.get("asks", [])), key=lambda x: x.price)

        if bids:
            market.bids = bids
            market.bid = bids[0].price
        if asks:
            market.asks = asks
            market.ask = asks[0].price

        market.last_price = round((market.bid + market.ask) / 2, 5)
        market.last_update = time.monotonic()
        self._last_ws_message = time.monotonic()

    # ── Watchdog ─────────────────────────────────────────────────────────────

    async def _watchdog_loop(self) -> None:
        await asyncio.sleep(30)
        while self._running:
            await asyncio.sleep(self.WATCHDOG_INTERVAL)
            age = time.monotonic() - self._last_ws_message
            if age > self.WATCHDOG_INTERVAL:
                logger.warning("WS watchdog: stale %.0fs — restarting", age)
                if self._ws_task and not self._ws_task.done():
                    self._ws_task.cancel()
                    try:
                        await self._ws_task
                    except asyncio.CancelledError:
                        pass
                self._ws_task = asyncio.create_task(self._ws_loop(), name="mf_ws")

    # ── WebSocket ─────────────────────────────────────────────────────────────

    async def _ws_loop(self) -> None:
        if self._use_synthetic:
            await self._synthetic_feed()
            return
        while self._running:
            try:
                await self._connect_ws()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("WS error: %s — retry %ds", e, self.RECONNECT_DELAY)
                await asyncio.sleep(self.RECONNECT_DELAY)

    async def _connect_ws(self) -> None:
        async with websockets.connect(
            self.WS_URL, ping_interval=20, ping_timeout=20, close_timeout=5,
        ) as ws:
            sub = {"auth":{},"type":"Market","assets_ids":list(self._subscribed_ids)}
            await ws.send(json.dumps(sub))
            logger.info("WS connected — %d markets", len(self._subscribed_ids))
            self._last_ws_message = time.monotonic()
            async for raw in ws:
                self._handle_ws_msg(raw)
                self._last_ws_message = time.monotonic()

    def _handle_ws_msg(self, raw: str) -> None:
        try:
            msgs = json.loads(raw)
            for msg in (msgs if isinstance(msgs, list) else [msgs]):
                self._process_event(msg)
        except Exception as e:
            logger.debug("WS parse error: %s", e)

    def _process_event(self, event: dict[str, Any]) -> None:
        etype   = event.get("event_type", "")
        asset_id = event.get("asset_id", "")
        market  = self.markets.get(asset_id)
        if not market:
            return

        if etype == "price_change":
            price = float(event.get("price", market.last_price))
            side  = event.get("side", "")
            if side == "BUY":
                market.bid = price
            elif side == "SELL":
                market.ask = price
            market.last_price = price
        elif etype == "book":
            self._apply_book({"asset_id": asset_id,
                               "bids": event.get("bids", []),
                               "asks": event.get("asks", [])})
            return
        elif etype == "trade":
            market.last_price = float(event.get("price", market.last_price))
            market.volume_24h += float(event.get("size", 0))

        market.last_update = time.monotonic()

    # ── Synthetic feed (ВИПРАВЛЕНИЙ — без forward info в книзі) ──────────────

    def _inject_dummy_markets(self) -> None:
        """
        Dummy ринки для тестування коли немає API.
        ВАЖЛИВО: ціни відображають реальні BTC ринки (~$64k).
        """
        configs = [
            # (name, start_mid, spread, ttl_hours, volume)
            ("BTC Above $70k by Friday [YES]", 0.04, 0.02, 48, 500_000),
            ("BTC Above $70k by Friday [NO]",  0.96, 0.02, 48, 500_000),
            ("BTC Above $65k Today [YES]",     0.38, 0.03, 8,  800_000),
            ("BTC Below $67k This Week [YES]", 0.72, 0.03, 96, 600_000),
        ]
        now_ts = time.time()
        for i, (name, mid, half_spread, hours, vol) in enumerate(configs):
            tid = f"DUMMY_{i:04d}"
            bid = max(0.01, mid - half_spread)
            ask = min(0.99, mid + half_spread)
            m = MarketState(
                market_id=tid, market_name=name,
                condition_id=f"COND_{i:04d}",
                bid=bid, ask=ask, last_price=mid,
                end_date_ts=now_ts + hours * 3600,
                volume_24h=float(vol),
            )
            # Симетрична книга — без інформації про майбутній напрямок!
            depth = 10_000
            m.bids = [OrderLevel(round(bid - j * 0.005, 4), depth) for j in range(4)]
            m.asks = [OrderLevel(round(ask + j * 0.005, 4), depth) for j in range(4)]
            self.markets[tid] = m
            self._subscribed_ids.add(tid)

        logger.info("⚠️  Synthetic mode — 4 dummy BTC markets (NO forward info in book)")

    async def _synthetic_feed(self) -> None:
        """
        Реалістична синтетика з mean-reversion до BS fair value.
        
        Моделює реальний ринок де арбітражери виправляють відхилення:
          - Ціни дрейфують з шумом навколо BS fair value
          - Mean-reversion повертає ціну коли вона відхиляється
          - Великий шум (0.015) = реальна ринкова волатильність
          - Reversion 3% / тік = швидкість виправлення маркет-мейкерами
        
        Результат: бот бачить реальний edge (купує коли ціна відхилилась)
        і виграє коли ціна повертається до fair value.
        """
        import random
        logger.info("Synthetic mean-reverting feed started (%d markets)", len(self.markets))

        # Ініціалізуємо mid цінами на основі BS fair value
        mids: dict[str, float] = {}
        for m in self.markets.values():
            bs_fv = self._get_bs_fv(m)
            mids[m.market_id] = bs_fv if bs_fv is not None else m.mid
            logger.info("  Init %s: mid=%.4f (BS fv=%.4f)",
                        m.market_name, mids[m.market_id], bs_fv or m.mid)

        while self._running:
            for market in self.markets.values():
                tid = market.market_id
                mid = mids[tid]

                # Поточна BS fair value
                bs_fv = self._get_bs_fv(market)
                if bs_fv is None:
                    bs_fv = mid  # немає BTC feed — не рухаємось

                # Mean-reversion + шум (імітує реальний ринок)
                # 3% per tick до fair value + реалістичний ринковий шум
                reversion = 0.03 * (bs_fv - mid)
                noise = random.gauss(0, 0.015)  # ~1.5% std dev = реальна ринкова волатильність
                mid = mid + reversion + noise
                mid = max(0.01, min(0.99, mid))
                mids[tid] = mid

                # Спред на основі обсягу (більший обсяг = вужчий спред)
                base_spread = 0.03  # 3 cents для активного ринку
                half = base_spread / 2

                market.bid = max(0.01, round(mid - half, 5))
                market.ask = min(0.99, round(mid + half, 5))
                if market.bid >= market.ask:
                    market.ask = round(market.bid + 0.01, 5)
                market.last_price = mid

                # Симетрична книга — без forward-info про напрямок
                depth = 10_000
                market.bids = [
                    OrderLevel(round(market.bid - j * 0.005, 4), depth)
                    for j in range(4)
                ]
                market.asks = [
                    OrderLevel(round(market.ask + j * 0.005, 4), depth)
                    for j in range(4)
                ]
                market.volume_24h += random.uniform(10, 50)
                market.last_update = time.monotonic()

            await asyncio.sleep(1)

    def _get_bs_fv(self, market: MarketState) -> float | None:
        """Обчислює BS fair value для цього токену через fair_value модуль."""
        try:
            from app.services.fair_value import _black_scholes_probability
            return _black_scholes_probability(market)
        except Exception:
            return None
