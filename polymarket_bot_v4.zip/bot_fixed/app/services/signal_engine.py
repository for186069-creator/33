"""
app/services/signal_engine.py — v4
════════════════════════════════════
Фільтр сигналів з урахуванням спреду.

Ключові зміни v4:
  1. Spread filter: edge must be > spread/2 (інакше комісія з'їдає прибуток)
  2. BS fair value logging: показуємо чому сигнал генерується/відхиляється
  3. Cooldown check використовує position_tracker
  4. MAX_CONCURRENT = 4 (менше ліпше для початку)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from app.core.config import settings
from app.services.fair_value import compute_fair_value, detect_arbitrage, fair_value_components
from app.services.market_feed import MarketState

if TYPE_CHECKING:
    from app.services.position_tracker import PositionTracker

logger = logging.getLogger(__name__)

Side = Literal["YES", "NO"]

# ── Якісні фільтри ────────────────────────────────────────────────────────────
MIN_VOLUME_USD  = 10_000   # знижено: реальні ринки з $10k+ volume
MIN_BOOK_DEPTH  = 50       # знижено: реальний ринок може бути тонким
MAX_SPREAD      = 0.15     # до 15 cents spread (реальний Polymarket ширший)
MIN_TTR_SECONDS = 900      # мінімум 15 хвилин (було 30)
MAX_TTR_SECONDS = 14 * 86400  # 2 тижні максимум

MAX_CONCURRENT  = 4


@dataclass
class TradeSignal:
    market_id: str
    market_name: str
    side: Side
    fair_value: float
    current_price: float
    edge: float
    size_usdc: float
    bid: float
    ask: float
    signal_type: str = "edge"


class SignalEngine:
    def __init__(
        self,
        bankroll_fn,
        position_tracker: "PositionTracker | None" = None,
        open_market_names_fn=None,
        open_count_fn=None,
    ) -> None:
        self._bankroll = bankroll_fn
        self._tracker = position_tracker
        self._open_names = open_market_names_fn or (lambda: set())
        self._open_count = open_count_fn or (lambda: 0)

    def scan(self, markets: list[MarketState]) -> list[TradeSignal]:
        if self._open_count() >= MAX_CONCURRENT:
            return []

        open_names = self._open_names()
        signals: list[TradeSignal] = []

        # Спочатку арбітраж (найвищий пріоритет)
        for sig in self._scan_arbitrage(markets, open_names):
            signals.append(sig)

        for market in markets:
            if market.market_name in open_names:
                continue
            if self._tracker and self._tracker.is_on_cooldown(market.market_name):
                remaining = self._tracker.cooldown_remaining(market.market_name)
                logger.debug("Cooldown: %s (%.0fs)", market.market_name, remaining)
                continue
            sig = self._evaluate(market)
            if sig:
                signals.append(sig)

        signals.sort(key=lambda s: s.edge, reverse=True)
        slots = MAX_CONCURRENT - self._open_count()
        return signals[:max(0, slots)]

    def _evaluate(self, market: MarketState) -> TradeSignal | None:
        if not market.active:
            return None
        ttr = market.time_to_resolution
        if ttr < MIN_TTR_SECONDS or ttr > MAX_TTR_SECONDS:
            return None
        if market.bid <= 0.005 or market.ask >= 0.995:
            return None
        spread = market.ask - market.bid
        if spread > MAX_SPREAD:
            return None
        if market.volume_24h < MIN_VOLUME_USD:
            return None

        # Перевірка глибини книги (менш суворий)
        bid_depth = sum(l.size for l in market.bids[:5])
        ask_depth = sum(l.size for l in market.asks[:5])
        if bid_depth + ask_depth < MIN_BOOK_DEPTH:
            return None

        fv = compute_fair_value(market)
        bankroll = self._bankroll()

        # Мінімальний edge = max(min_edge з config, половина спреду)
        # Щоб edge покривав комісію на виході
        effective_min_edge = max(settings.min_edge, spread * 0.5)

        # YES сигнал: fair_value > ask (ринок недооцінює)
        yes_edge = fv - market.ask
        if yes_edge >= effective_min_edge:
            size = self._kelly_size(fv, market.ask, bankroll)
            if size >= 1.0:
                comps = fair_value_components(market)
                logger.info(
                    "✅ YES signal %s | fv=%.4f ask=%.4f edge=%.4f | BS=%.4f TTR=%.1fh",
                    market.market_name, fv, market.ask, yes_edge,
                    comps.get("bs_probability") or 0, ttr / 3600,
                )
                return TradeSignal(
                    market_id=market.market_id,
                    market_name=market.market_name,
                    side="YES",
                    fair_value=fv,
                    current_price=market.ask,
                    edge=yes_edge,
                    size_usdc=size,
                    bid=market.bid,
                    ask=market.ask,
                )

        # NO сигнал: (1-fair_value) > (1-bid) → ринок переоцінює YES
        no_fv    = 1.0 - fv
        no_price = 1.0 - market.bid   # ціна NO токену
        no_edge  = no_fv - no_price
        if no_edge >= effective_min_edge:
            size = self._kelly_size(no_fv, no_price, bankroll)
            if size >= 1.0:
                comps = fair_value_components(market)
                logger.info(
                    "✅ NO  signal %s | fv=%.4f bid=%.4f no_edge=%.4f | BS=%.4f TTR=%.1fh",
                    market.market_name, fv, market.bid, no_edge,
                    comps.get("bs_probability") or 0, ttr / 3600,
                )
                return TradeSignal(
                    market_id=market.market_id,
                    market_name=market.market_name,
                    side="NO",
                    fair_value=fv,
                    current_price=no_price,
                    edge=no_edge,
                    size_usdc=size,
                    bid=market.bid,
                    ask=market.ask,
                )

        return None

    def _scan_arbitrage(
        self, markets: list[MarketState], open_names: set[str]
    ) -> list[TradeSignal]:
        arbs = detect_arbitrage(markets)
        signals = []
        bankroll = self._bankroll()

        for arb in arbs:
            if arb.get("edge", 0) < 0.03:
                continue
            ma = next((m for m in markets if m.market_name == arb.get("market_a")), None)
            if not ma or ma.market_name in open_names:
                continue
            if self._tracker and self._tracker.is_on_cooldown(ma.market_name):
                continue
            arb_size = min(bankroll * 0.05, settings.max_position_size_usd / 2)
            signals.append(TradeSignal(
                market_id=ma.market_id,
                market_name=ma.market_name,
                side="YES",
                fair_value=0.99,
                current_price=ma.ask,
                edge=arb["edge"],
                size_usdc=round(arb_size, 2),
                bid=ma.bid,
                ask=ma.ask,
                signal_type="arb",
            ))

        return signals

    @staticmethod
    def _kelly_size(p: float, price: float, bankroll: float) -> float:
        if price <= 0 or price >= 1:
            return 0.0
        b = (1.0 - price) / price
        f_kelly = (p * b - (1.0 - p)) / b
        f_safe  = max(0.0, f_kelly * settings.kelly_fraction)
        return round(min(f_safe * bankroll, settings.max_position_size_usd), 2)
