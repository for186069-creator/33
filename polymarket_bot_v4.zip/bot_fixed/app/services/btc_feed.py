"""
app/services/btc_feed.py — v2
Binance public WebSocket для реального BTC price.

Нові можливості v2:
  - realized_vol_annual: розрахунок реалізованої волатильності з цінової 
    історії. Годиться для BS-моделі. Fallback = 65% (типовий для BTC).
  - Більш стабільне повторне підключення
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from collections import deque

import websockets
from websockets.exceptions import ConnectionClosed

logger = logging.getLogger(__name__)

BINANCE_WS = "wss://stream.binance.com:9443/ws/btcusdt@trade"
BINANCE_REST = "https://api.binance.com/api/v3/ticker/price"
RECONNECT_DELAY = 3
HISTORY_SECONDS = 7200  # keep 2 hours of price history for vol calculation


class BtcPriceFeed:
    def __init__(self) -> None:
        self.price: float = 0.0
        self.ready: bool = False
        self._price_history: deque[tuple[float, float]] = deque()  # (ts, price)
        self._task: asyncio.Task | None = None
        self._running = False

    # ── Public properties ─────────────────────────────────────────────────────

    @property
    def momentum(self) -> float:
        """% price change over last 60 seconds."""
        if not self._price_history or self.price == 0:
            return 0.0
        now = time.monotonic()
        old = [p for ts, p in self._price_history if ts <= now - 60]
        if not old or old[-1] == 0:
            return 0.0
        return (self.price - old[-1]) / old[-1]

    @property
    def price_1m_ago(self) -> float:
        now = time.monotonic()
        old = [p for ts, p in self._price_history if ts <= now - 60]
        return old[-1] if old else self.price

    @property
    def realized_vol_annual(self) -> float:
        """
        Annualized BTC volatility from recent price history.
        
        Uses log-returns from price snapshots spaced ~1 minute apart.
        This gives stable 1-hour realized vol.
        Default: 0.65 (65% annual, conservative BTC estimate).
        """
        history = list(self._price_history)
        if len(history) < 20:
            return 0.65

        # Sample approximately every 60 seconds
        now = time.monotonic()
        sample_interval = 60.0  # seconds
        samples: list[float] = []
        last_ts = -999999

        for ts, price in history:
            if ts - last_ts >= sample_interval and price > 0:
                samples.append(price)
                last_ts = ts

        if len(samples) < 3:
            return 0.65

        # Compute log returns
        log_returns = [
            math.log(samples[i] / samples[i - 1])
            for i in range(1, len(samples))
            if samples[i - 1] > 0 and samples[i] > 0
        ]

        if len(log_returns) < 2:
            return 0.65

        mean = sum(log_returns) / len(log_returns)
        variance = sum((r - mean) ** 2 for r in log_returns) / max(1, len(log_returns) - 1)
        std_per_minute = math.sqrt(variance)

        # Annualize: sqrt(minutes per year)
        annual_vol = std_per_minute * math.sqrt(365 * 24 * 60)

        # Clamp to realistic range
        result = max(0.30, min(2.00, annual_vol))
        logger.debug("Realized vol: %.1f%% annual (from %d samples)", result * 100, len(samples))
        return result

    def market_implied_prob(self, strike: float) -> float | None:
        """DEPRECATED — use fair_value.bs_binary_call() directly."""
        if not self.ready or self.price <= 0 or strike <= 0:
            return None
        from app.services.fair_value import bs_binary_call
        T = 1.0 / 365  # 1 day default when called directly
        return bs_binary_call(self.price, strike, T, self.realized_vol_annual)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        await self._fetch_rest_price()
        self._task = asyncio.create_task(self._ws_loop(), name="btc_feed_ws")
        logger.info("BTC feed started: $%.2f  σ=%.0f%%",
                    self.price, self.realized_vol_annual * 100)

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    # ── REST ─────────────────────────────────────────────────────────────────

    async def _fetch_rest_price(self) -> None:
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    BINANCE_REST, params={"symbol": "BTCUSDT"},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        price = float(data["price"])
                        self.price = price
                        self.ready = True
                        self._record(price)
                        logger.info("BTC REST price: $%.2f", price)
        except Exception as e:
            logger.warning("BTC REST failed: %s", e)

    # ── WebSocket ─────────────────────────────────────────────────────────────

    async def _ws_loop(self) -> None:
        while self._running:
            try:
                await self._connect()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("BTC WS error: %s — retry in %ds", e, RECONNECT_DELAY)
                await self._fetch_rest_price()
                await asyncio.sleep(RECONNECT_DELAY)

    async def _connect(self) -> None:
        async with websockets.connect(
            BINANCE_WS, ping_interval=20, ping_timeout=15,
        ) as ws:
            logger.info("BTC Binance WS connected")
            async for raw in ws:
                msg = json.loads(raw)
                price = float(msg.get("p", 0))
                if price > 0:
                    self.price = price
                    self.ready = True
                    self._record(price)

    def _record(self, price: float) -> None:
        now = time.monotonic()
        self._price_history.append((now, price))
        cutoff = now - HISTORY_SECONDS
        while self._price_history and self._price_history[0][0] < cutoff:
            self._price_history.popleft()


# ── Strike parser ─────────────────────────────────────────────────────────────

def parse_strike_from_name(market_name: str) -> float | None:
    """
    Extract BTC strike from market name.
    'BTC Above $70k by Friday' → 70_000.0
    'BTC Below $65k This Week' → 65_000.0
    'BTC Above $68500 Today'   → 68_500.0
    """
    import re
    match = re.search(r'\$(\d[\d,]*\.?\d*)\s*[kK]?', market_name)
    if not match:
        return None
    raw = match.group(1).replace(",", "")
    value = float(raw)
    original = match.group(0)
    if original.lower().rstrip().endswith('k') or (value < 5000 and 'k' in original.lower()):
        value *= 1000
    return value if value > 1000 else None
