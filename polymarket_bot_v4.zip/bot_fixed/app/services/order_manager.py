"""
app/services/order_manager.py — v4
════════════════════════════════════
Виправлено БАГ: неправильна ціна входу для NO позицій.

Раніше:
  NO fill_price = signal.bid (= YES bid ≈ 0.43) ← НЕПРАВИЛЬНО
  Але current_value = 1 - ask ≈ 0.53 → старт +10%, до TP залишалось 2 cents

Зараз:
  YES: fill_price = ask + slippage     (платимо ask за YES токен)
  NO:  fill_price = (1-bid) + slippage (платимо NO ask = 1 - YES bid)
  
  Це правильно відображає реальну вартість входу в позицію.
"""
from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime, timezone

import aiohttp
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import Resolution, Side, Trade
from app.services.signal_engine import TradeSignal

logger = logging.getLogger(__name__)


class OrderManager:
    def __init__(self, position_tracker=None) -> None:
        self._tracker = position_tracker
        self._usdc_balance: float | None = None
        self._balance_ts: float = 0.0

    async def execute(self, signal: TradeSignal, db: AsyncSession) -> Trade | None:
        if settings.paper_trading:
            return await self._paper_execute(signal, db)
        else:
            return await self._live_execute(signal, db)

    # ── Paper mode ────────────────────────────────────────────────────────────

    async def _paper_execute(self, signal: TradeSignal, db: AsyncSession) -> Trade | None:
        spread = signal.ask - signal.bid
        slippage = spread * 0.10  # 10% of spread as execution cost

        if signal.side == "YES":
            # Купуємо YES токен → платимо ASK + slippage
            fill_price = min(0.99, signal.ask + slippage)
        else:
            # Купуємо NO токен → платимо NO_ASK = 1 - YES_BID + slippage
            no_ask = 1.0 - signal.bid
            fill_price = min(0.98, no_ask + slippage)

        fill_price = max(0.01, fill_price)

        trade = Trade(
            market_id=signal.market_id,
            market_name=signal.market_name,
            side=Side.YES if signal.side == "YES" else Side.NO,
            entry_price=round(fill_price, 6),
            size_usdc=signal.size_usdc,
            fair_value_at_entry=signal.fair_value,
            edge_at_entry=signal.edge,
            resolution=Resolution.OPEN,
            order_id=f"PAPER-{uuid.uuid4().hex[:12]}",
            opened_at=datetime.utcnow(),
        )
        db.add(trade)
        await db.commit()
        await db.refresh(trade)

        # Розраховуємо реальний initial edge (після слипажу)
        mid = (signal.bid + signal.ask) / 2
        if signal.side == "YES":
            start_edge = mid - fill_price
        else:
            start_edge = (1.0 - mid) - fill_price

        logger.info(
            "[PAPER] %s %s @ %.4f  size=%.2f  fair=%.4f  edge=%.4f  start_unrealised=%.4f",
            signal.side, signal.market_name, fill_price,
            signal.size_usdc, signal.fair_value, signal.edge, start_edge,
        )
        return trade

    # ── Live mode ─────────────────────────────────────────────────────────────

    async def _live_execute(self, signal: TradeSignal, db: AsyncSession) -> Trade | None:
        balance = await self._get_usdc_balance()
        if balance is not None and balance < signal.size_usdc:
            logger.warning("Insufficient USDC: %.2f < %.2f", balance, signal.size_usdc)
            return None

        try:
            order  = self._build_order(signal)
            signed = self._sign_order(order)

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{settings.clob_base_url}/order",
                    json=signed,
                    headers=self._auth_headers(),
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as resp:
                    body = await resp.json()

            if resp.status not in (200, 201):
                logger.error("Order rejected %d: %s", resp.status, body)
                return None

            order_id   = body.get("orderID") or body.get("id", "")
            fill_price = float(body.get("price", signal.current_price))

            trade = Trade(
                market_id=signal.market_id,
                market_name=signal.market_name,
                side=Side.YES if signal.side == "YES" else Side.NO,
                entry_price=round(fill_price, 6),
                size_usdc=signal.size_usdc,
                fair_value_at_entry=signal.fair_value,
                edge_at_entry=signal.edge,
                resolution=Resolution.OPEN,
                order_id=order_id,
                opened_at=datetime.utcnow(),
            )
            db.add(trade)
            await db.commit()
            await db.refresh(trade)

            logger.info("[LIVE] %s %s @ %.4f  size=%.2f  order=%s",
                        signal.side, signal.market_name, fill_price,
                        signal.size_usdc, order_id)
            return trade

        except Exception as exc:
            logger.exception("Live order failed: %s", exc)
            return None

    # ── USDC balance check ────────────────────────────────────────────────────

    async def _get_usdc_balance(self) -> float | None:
        now = time.monotonic()
        if self._usdc_balance is not None and (now - self._balance_ts) < 30:
            return self._usdc_balance
        if not settings.polygon_wallet_address:
            return None
        try:
            USDC = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
            data = ("0x70a08231"
                    + settings.polygon_wallet_address.lower().replace("0x", "").zfill(64))
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://polygon-rpc.com",
                    json={"jsonrpc":"2.0","method":"eth_call",
                          "params":[{"to":USDC,"data":data},"latest"],"id":1},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    result = await resp.json()
            balance = int(result.get("result", "0x0"), 16) / 1_000_000
            self._usdc_balance = balance
            self._balance_ts = now
            logger.info("USDC balance: %.2f", balance)
            return balance
        except Exception as e:
            logger.warning("Balance check failed: %s", e)
            return None

    # ── Live signing / auth ───────────────────────────────────────────────────

    def _auth_headers(self) -> dict:
        if not settings.polygon_private_key:
            return {}
        try:
            from eth_account import Account
            from eth_account.messages import encode_defunct
            ts  = str(int(time.time()))
            msg = encode_defunct(text=ts)
            acc = Account.from_key(settings.polygon_private_key)
            sig = acc.sign_message(msg)
            return {
                "POLY_ADDRESS":   settings.polygon_wallet_address,
                "POLY_SIGNATURE": sig.signature.hex(),
                "POLY_TIMESTAMP": ts,
                "POLY_NONCE":     "0",
            }
        except Exception as e:
            logger.warning("Auth header failed: %s", e)
            return {}

    def _build_order(self, signal: TradeSignal) -> dict:
        price = signal.ask if signal.side == "YES" else (1.0 - signal.bid)
        return {
            "tokenID":   signal.market_id,
            "side":      "BUY",
            "price":     str(round(price, 4)),
            "size":      str(round(signal.size_usdc / price, 2)),
            "orderType": "GTC",
            "nonce":     str(int(time.time() * 1000)),
            "maker":     settings.polygon_wallet_address,
            "signer":    settings.polygon_wallet_address,
            "expiration":"0",
        }

    def _sign_order(self, order: dict) -> dict:
        if not settings.polygon_private_key:
            raise ValueError("POLYGON_PRIVATE_KEY not set")
        from eth_account import Account
        acc = Account.from_key(settings.polygon_private_key)
        domain = {
            "name": "Polymarket CTF Exchange", "version": "1",
            "chainId": 137,
            "verifyingContract": "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E",
        }
        types = {"Order": [
            {"name":"salt","type":"uint256"},{"name":"maker","type":"address"},
            {"name":"signer","type":"address"},{"name":"taker","type":"address"},
            {"name":"tokenId","type":"uint256"},{"name":"makerAmount","type":"uint256"},
            {"name":"takerAmount","type":"uint256"},{"name":"expiration","type":"uint256"},
            {"name":"nonce","type":"uint256"},{"name":"feeRateBps","type":"uint256"},
            {"name":"side","type":"uint8"},{"name":"signatureType","type":"uint8"},
        ]}
        price_i = int(float(order["price"]) * 10**6)
        size_i  = int(float(order["size"])  * 10**6)
        msg = {
            "salt":int(order["nonce"]),"maker":acc.address,"signer":acc.address,
            "taker":"0x0000000000000000000000000000000000000000",
            "tokenId":0,"makerAmount":size_i*price_i//10**6,"takerAmount":size_i,
            "expiration":0,"nonce":0,"feeRateBps":0,"side":0,"signatureType":0,
        }
        signed = acc.sign_typed_data(domain_data=domain, message_types=types, message_data=msg)
        return {**order, "signature": signed.signature.hex(), "signatureType": 0}
