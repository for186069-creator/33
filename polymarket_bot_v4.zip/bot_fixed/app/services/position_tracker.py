"""
app/services/position_tracker.py — v4
═══════════════════════════════════════
Виправлено ГОЛОВНИЙ БАГ v3: використовуємо MID ціну для поточної вартості
позиції, а не bid/ask окремо.

Чому це важливо:
  - YES позиція: входимо за ASK (0.47), але bid = 0.43 → старт з -4% без причини
  - При SL = -10% від entry: SL спрацьовував після руху всього -6% (4%+6%)
  - Результат: 0% win rate навіть при правильних сигналах

Виправлення:
  - current_value = MID = (bid+ask)/2 для обох сторін
  - YES: unrealised = mid - entry_ask → старт ~-2% (тільки half-spread)
  - NO:  unrealised = (1-mid) - entry_no_ask → старт ~-2% (тільки half-spread)
  - TP = +0.06, SL = -0.05 (симетричні відносно fair value)
  - Cooldown після close: 120с для TP, 300с для SL
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import Resolution, Trade
from app.services.market_feed import MarketState

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from app.services.risk_manager import RiskManager

logger = logging.getLogger(__name__)

# ── Exit thresholds (relative to ENTRY PRICE, using MID for current value) ───
TAKE_PROFIT_EDGE = 0.06   # +6% від ціни входу → виходимо з прибутком
STOP_LOSS_EDGE   = -0.05  # -5% від ціни входу → виходимо зі збитком
MIN_TTR_TO_HOLD  = 600    # 10 хвилин — не тримаємо перед резолюцією

COOLDOWN_WIN  =  120  # 2 хв після take_profit
COOLDOWN_LOSS =  300  # 5 хв після stop_loss (було 240 → 300 щоб не поспішати)


class PositionTracker:
    def __init__(self, risk_manager: "RiskManager") -> None:
        self._risk = risk_manager
        self._cooldown_map: dict[str, float] = {}  # market_name → monotonic expiry

    # ── Cooldown API ──────────────────────────────────────────────────────────

    def is_on_cooldown(self, market_name: str) -> bool:
        return time.monotonic() < self._cooldown_map.get(market_name, 0.0)

    def cooldown_remaining(self, market_name: str) -> float:
        return max(0.0, self._cooldown_map.get(market_name, 0.0) - time.monotonic())

    # ── Main update loop ──────────────────────────────────────────────────────

    async def update(
        self,
        db: AsyncSession,
        market_states: dict[str, MarketState],
    ) -> None:
        result = await db.execute(
            select(Trade).where(Trade.resolution == Resolution.OPEN)
        )
        for trade in result.scalars().all():
            market = market_states.get(trade.market_id)
            if market is None:
                continue
            exit_price, reason = self._should_exit(trade, market)
            if exit_price is not None:
                await self._close_trade(trade, exit_price, reason, db)

    # ── Exit logic ────────────────────────────────────────────────────────────

    def _should_exit(
        self, trade: Trade, market: MarketState
    ) -> tuple[float | None, str]:
        ttr = market.time_to_resolution

        # Force close near expiry
        if ttr < MIN_TTR_TO_HOLD:
            mid = (market.bid + market.ask) / 2
            exit_price = mid if trade.side.value == "YES" else 1.0 - mid
            return exit_price, "approaching_resolution"

        # ── ВИПРАВЛЕННЯ: використовуємо MID для поточної вартості ────────────
        mid = (market.bid + market.ask) / 2

        if trade.side.value == "YES":
            current_value = mid
        else:
            # NO token: поточна вартість = 1 - mid(YES)
            current_value = 1.0 - mid

        unrealised_edge = current_value - trade.entry_price

        if unrealised_edge >= TAKE_PROFIT_EDGE:
            return current_value, "take_profit"

        if unrealised_edge <= STOP_LOSS_EDGE:
            return current_value, "stop_loss"

        return None, ""

    # ── Close trade ───────────────────────────────────────────────────────────

    async def _close_trade(
        self,
        trade: Trade,
        exit_price: float,
        reason: str,
        db: AsyncSession,
    ) -> None:
        # P&L: скільки заробили/втратили на цій позиції
        pnl_per_unit = exit_price - trade.entry_price
        pnl_usdc = trade.size_usdc * pnl_per_unit / max(trade.entry_price, 0.001)
        pnl_pct  = (pnl_per_unit / max(trade.entry_price, 0.001)) * 100.0

        resolution = Resolution.WIN if pnl_usdc > 0 else Resolution.LOSS

        trade.exit_price  = round(exit_price, 6)
        trade.pnl_usdc    = round(pnl_usdc, 4)
        trade.pnl_pct     = round(pnl_pct, 4)
        trade.resolution  = resolution
        trade.closed_at   = datetime.now(timezone.utc)

        await db.commit()
        self._risk.on_position_closed(trade.market_id, pnl_usdc)

        # Cooldown: довший після збитку
        cooldown = COOLDOWN_LOSS if reason == "stop_loss" else COOLDOWN_WIN
        self._cooldown_map[trade.market_name] = time.monotonic() + cooldown

        logger.info(
            "[CLOSE] %s %s | %s | exit=%.4f pnl=%.2f USDC (%.1f%%) | reason=%s | cooldown=%ds",
            trade.side.value, trade.market_name, resolution.value,
            exit_price, pnl_usdc, pnl_pct, reason, cooldown,
        )

    # ── Bankroll ──────────────────────────────────────────────────────────────

    async def get_bankroll(self, db: AsyncSession) -> float:
        if settings.paper_trading:
            result = await db.execute(
                select(Trade).where(Trade.resolution != Resolution.OPEN)
            )
            realised = sum(t.pnl_usdc or 0.0 for t in result.scalars().all())
            return settings.paper_balance_usdc + realised
        return settings.paper_balance_usdc
