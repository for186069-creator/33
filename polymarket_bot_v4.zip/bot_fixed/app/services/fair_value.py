"""
app/services/fair_value.py — v4 Black-Scholes
═══════════════════════════════════════════════
Замінюємо примітивну sigmoid-модель на математично коректну модель
ціноутворення бінарних опціонів (Black-Scholes digital call/put).

Чому це важливо:
  Polymarket BTC ринки — це бінарні опціони. BS-модель враховує:
  - Поточну ціну BTC відносно страйку
  - Час до експірації (TTR)
  - Волатильність BTC (65% річних = стандарт для BTC)
  
  Попередня sigmoid-модель давала 26% для "BTC>$70k при BTC=$64k за 2 дні"
  BS-модель дає правильні ~3% — саме так і повинно бути.

Формула BS для бінарного кола (платить $1 якщо BTC > K):
  P(BTC_T > K) = N(d2)
  d2 = [ln(S/K) - σ²T/2] / (σ√T)
  де N — кумулятивна нормальна розподіл (без scipy, лише math)
"""
from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING

from app.services.market_feed import MarketState, OrderLevel

if TYPE_CHECKING:
    from app.services.btc_feed import BtcPriceFeed

logger = logging.getLogger(__name__)

_btc_feed: "BtcPriceFeed | None" = None

def set_btc_feed(feed: "BtcPriceFeed") -> None:
    global _btc_feed
    _btc_feed = feed


# ── Normal CDF (pure Python, no scipy) ───────────────────────────────────────

def _norm_cdf(x: float) -> float:
    """Cumulative distribution function for standard normal."""
    return (1.0 + math.erf(x / math.sqrt(2.0))) / 2.0


# ── Black-Scholes Binary Option Pricing ──────────────────────────────────────

def bs_binary_call(S: float, K: float, T: float, sigma: float) -> float:
    """
    Fair value of binary call option: P(BTC > K at time T).
    
    S     = current BTC price
    K     = strike price
    T     = time to expiry in YEARS
    sigma = annual volatility (e.g. 0.65 for 65%)
    
    Returns probability in [0.01, 0.99].
    """
    if T <= 0:
        return 0.99 if S > K else 0.01
    if S <= 0 or K <= 0 or sigma <= 0:
        return 0.5

    try:
        d2 = (math.log(S / K) - 0.5 * sigma ** 2 * T) / (sigma * math.sqrt(T))
        prob = _norm_cdf(d2)
        return max(0.01, min(0.99, prob))
    except (ValueError, ZeroDivisionError, OverflowError):
        return 0.5


def bs_binary_put(S: float, K: float, T: float, sigma: float) -> float:
    """
    Fair value of binary put option: P(BTC < K at time T).
    """
    return 1.0 - bs_binary_call(S, K, T, sigma)


# ── Main entry point ──────────────────────────────────────────────────────────

def compute_fair_value(market: MarketState) -> float:
    """
    Returns fair-value in [0.01, 0.99].
    
    Priority:
    1. Black-Scholes with BTC feed (most accurate)
    2. Order book mid + imbalance (fallback)
    """
    book_mid      = _weighted_mid(market)
    imbalance_adj = _imbalance_adjustment(market)
    time_factor   = _time_factor(market)

    bs_prob = _black_scholes_probability(market)

    if bs_prob is not None:
        # Blend: 80% BS model, 20% book mid
        fv = bs_prob * 0.80 + (book_mid + imbalance_adj * time_factor) * 0.20
        logger.debug("FV %s bs=%.4f book=%.4f → %.4f",
                     market.market_name, bs_prob, book_mid, fv)
    else:
        fv = book_mid + imbalance_adj * time_factor
        logger.debug("FV %s book=%.4f → %.4f", market.market_name, book_mid, fv)

    return float(_clamp(fv, 0.01, 0.99))


# ── Black-Scholes probability ─────────────────────────────────────────────────

def _black_scholes_probability(market: MarketState) -> float | None:
    """
    Compute BS fair value for this market token.
    Returns None if BTC feed unavailable or market name has no strike.
    """
    if _btc_feed is None or not _btc_feed.ready or _btc_feed.price <= 0:
        return None

    from app.services.btc_feed import parse_strike_from_name
    strike = parse_strike_from_name(market.market_name)
    if strike is None or strike <= 0:
        return None

    name_lower = market.market_name.lower()
    is_above   = "above" in name_lower
    is_below   = "below" in name_lower
    is_yes     = "[yes]" in name_lower

    if not is_above and not is_below:
        return None

    S     = _btc_feed.price
    K     = strike
    T     = market.time_to_resolution / (365.0 * 24 * 3600)  # seconds → years
    sigma = _btc_feed.realized_vol_annual

    if T <= 0:
        T = 1 / (365 * 24 * 3600)  # 1 second minimum

    # Base probability: P(BTC > strike at expiry)
    p_above = bs_binary_call(S, K, T, sigma)

    # Determine which side this token represents
    if is_above and is_yes:
        prob = p_above
    elif is_above and not is_yes:      # NO token on "BTC Above"
        prob = 1.0 - p_above
    elif is_below and is_yes:          # YES token on "BTC Below"
        prob = 1.0 - p_above
    elif is_below and not is_yes:      # NO token on "BTC Below"
        prob = p_above
    else:
        return None

    logger.debug(
        "BS: %s | S=%.2f K=%.2f T=%.4f σ=%.2f → p_above=%.4f prob=%.4f",
        market.market_name, S, K, T, sigma, p_above, prob
    )
    return _clamp(prob, 0.01, 0.99)


# ── Order book components (fallback) ─────────────────────────────────────────

BOOK_LEVELS       = 5
MAX_IMBALANCE_ADJ = 0.015   # reduced: book imbalance is weaker signal now
SIZE_WEIGHT_POWER = 0.5
DECAY_START       = 300


def _weighted_mid(market: MarketState) -> float:
    bids = market.bids[:BOOK_LEVELS]
    asks = market.asks[:BOOK_LEVELS]

    if not bids and not asks:
        return (market.bid + market.ask) / 2.0 if market.bid and market.ask else market.last_price

    def wprice(levels: list[OrderLevel], desc: bool) -> float:
        if not levels:
            return 0.0
        levels = sorted(levels, key=lambda l: l.price, reverse=desc)
        tw = sum(l.size ** SIZE_WEIGHT_POWER for l in levels)
        return sum(l.price * (l.size ** SIZE_WEIGHT_POWER) for l in levels) / tw if tw else levels[0].price

    bm = wprice(bids, True)
    am = wprice(asks, False)
    if bm and am:
        return (bm + am) / 2.0
    return bm or am or market.last_price


def _imbalance_adjustment(market: MarketState) -> float:
    bids = market.bids[:BOOK_LEVELS]
    asks = market.asks[:BOOK_LEVELS]
    bd = sum(l.size for l in bids)
    ad = sum(l.size for l in asks)
    total = bd + ad
    if total < 1.0:
        return 0.0
    return ((bd - ad) / total) * MAX_IMBALANCE_ADJ


def _time_factor(market: MarketState) -> float:
    ttr = market.time_to_resolution
    if ttr <= 0:
        return 0.0
    return min(1.0, ttr / DECAY_START)


def _clamp(val: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, val))


# ── Arbitrage detector ────────────────────────────────────────────────────────

def detect_arbitrage(markets: list[MarketState]) -> list[dict]:
    """Find YES+NO pairs where buying both < $1 (guaranteed profit)."""
    arbs = []
    by_cond: dict[str, list[MarketState]] = {}
    for m in markets:
        cid = m.condition_id or m.market_name.rsplit("[", 1)[0].strip()
        by_cond.setdefault(cid, []).append(m)

    for cid, pair in by_cond.items():
        if len(pair) != 2:
            continue
        a, b = pair
        combined_ask = a.ask + b.ask
        if combined_ask < 0.97:
            arbs.append({
                "type": "buy_both",
                "market_a": a.market_name,
                "market_b": b.market_name,
                "ask_a": a.ask, "ask_b": b.ask,
                "combined": combined_ask,
                "edge": round(1.0 - combined_ask, 4),
            })
    return arbs


# ── Diagnostics ───────────────────────────────────────────────────────────────

def fair_value_components(market: MarketState) -> dict:
    from app.services.btc_feed import parse_strike_from_name
    bs = _black_scholes_probability(market)
    return {
        "fair_value": round(compute_fair_value(market), 6),
        "btc_price": round(_btc_feed.price, 2) if _btc_feed else None,
        "btc_vol_annual_pct": round(_btc_feed.realized_vol_annual * 100, 2) if _btc_feed else None,
        "strike": parse_strike_from_name(market.market_name),
        "ttr_hours": round(market.time_to_resolution / 3600, 2),
        "bs_probability": round(bs, 6) if bs is not None else None,
        "book_mid": round(_weighted_mid(market), 6),
        "current_market_mid": round((market.bid + market.ask) / 2, 6),
        "signal_source": "black_scholes" if bs is not None else "book_only",
    }
