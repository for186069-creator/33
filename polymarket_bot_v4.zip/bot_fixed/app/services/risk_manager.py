"""
app/services/risk_manager.py
─────────────────────────────
Pre-trade risk checks. All signals must pass through here before execution.

Checks (in order)
─────────────────
1. Trading-halt flag  — if set, reject everything until reset.
2. Max open positions — never more than N concurrent bets.
3. Daily loss limit   — if today's realised P&L < -MAX_DAILY_LOSS_USD, halt.
4. Per-market exposure — size vs total bankroll ≤ MAX_EXPOSURE_PER_MARKET.
5. Consecutive losses — after N losses in a row, pause trading.

The risk manager is stateful; it must be updated after every trade closure.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import TYPE_CHECKING

from app.core.config import settings

if TYPE_CHECKING:
    from app.services.signal_engine import TradeSignal

logger = logging.getLogger(__name__)


class RiskManager:
    def __init__(self) -> None:
        self._halted: bool = False
        self._halt_reason: str = ""

        self._open_positions: dict[str, float] = {}  # market_id → size_usdc
        self._daily_pnl: float = 0.0
        self._daily_reset_date: date = datetime.now(timezone.utc).date()
        self._consecutive_losses: int = 0

    # ── External interface ────────────────────────────────────────────────────

    def approve(self, signal: "TradeSignal") -> tuple[bool, str]:
        """Returns (approved: bool, reason: str)."""
        self._maybe_reset_daily_counters()

        if self._halted:
            return False, f"Trading halted: {self._halt_reason}"

        n_open = len(self._open_positions)
        if n_open >= settings.max_open_positions:
            return False, f"Max open positions reached ({n_open})"

        if self._daily_pnl <= -settings.max_daily_loss_usd:
            self._halt("daily loss limit hit")
            return False, "Daily loss limit reached"

        exposure = signal.size_usdc / max(self._bankroll_estimate(), 1)
        if exposure > settings.max_exposure_per_market:
            return False, (
                f"Exposure {exposure:.1%} > limit "
                f"{settings.max_exposure_per_market:.1%}"
            )

        if self._consecutive_losses >= settings.stop_trading_consecutive_losses:
            self._halt(f"{self._consecutive_losses} consecutive losses")
            return False, "Consecutive loss limit — trading paused"

        return True, "ok"

    def on_position_opened(self, market_id: str, size_usdc: float) -> None:
        self._open_positions[market_id] = (
            self._open_positions.get(market_id, 0.0) + size_usdc
        )

    def on_position_closed(self, market_id: str, pnl_usdc: float) -> None:
        self._open_positions.pop(market_id, None)
        self._daily_pnl += pnl_usdc
        if pnl_usdc < 0:
            self._consecutive_losses += 1
            logger.warning(
                "Loss recorded (consecutive=%d) | daily_pnl=%.2f",
                self._consecutive_losses, self._daily_pnl,
            )
        else:
            self._consecutive_losses = 0

    def resume_trading(self) -> str:
        """Manual override — admin can call this to un-halt."""
        prev = self._halt_reason
        self._halted = False
        self._halt_reason = ""
        self._consecutive_losses = 0
        logger.info("Trading resumed (was halted: %s)", prev)
        return prev

    # ── Status snapshot ───────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "halted": self._halted,
            "halt_reason": self._halt_reason,
            "open_positions": len(self._open_positions),
            "daily_pnl_usdc": round(self._daily_pnl, 4),
            "consecutive_losses": self._consecutive_losses,
            "limits": {
                "max_open_positions": settings.max_open_positions,
                "max_daily_loss_usd": settings.max_daily_loss_usd,
                "max_position_size_usd": settings.max_position_size_usd,
                "stop_consecutive_losses": settings.stop_trading_consecutive_losses,
            },
        }

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _halt(self, reason: str) -> None:
        if not self._halted:
            logger.critical("TRADING HALTED: %s", reason)
            self._halted = True
            self._halt_reason = reason

    def _maybe_reset_daily_counters(self) -> None:
        today = datetime.now(timezone.utc).date()
        if today != self._daily_reset_date:
            logger.info(
                "New trading day — resetting daily P&L (was %.2f)",
                self._daily_pnl,
            )
            self._daily_pnl = 0.0
            self._daily_reset_date = today
            # Do NOT auto-reset halt or consecutive-losses — those need human review.

    def _bankroll_estimate(self) -> float:
        """Rough bankroll for exposure calculation — updated externally if needed."""
        return settings.paper_balance_usdc  # position_tracker will override this
