"""
app/services/snapshot_service.py
──────────────────────────────────
Periodically persists a MarketSnapshot row for every active market.
Used for backtesting, model validation, and the admin dashboard charts.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import AsyncSessionLocal
from app.db.models import MarketSnapshot
from app.services.market_feed import MarketFeed

logger = logging.getLogger(__name__)


class SnapshotService:
    def __init__(self, feed: MarketFeed) -> None:
        self._feed = feed

    async def capture(self) -> None:
        """Called by the scheduler every SNAPSHOT_INTERVAL_SEC seconds."""
        # Only snapshot liquid markets with recent activity
        markets = [m for m in self._feed.active_markets()
                   if m.volume_24h >= 1000 and m.spread <= 0.10]
        if not markets:
            return

        now = datetime.now(timezone.utc)
        async with AsyncSessionLocal() as db:
            for m in markets:
                snap = MarketSnapshot(
                    market_id=m.market_id,
                    market_name=m.market_name,
                    bid=m.bid,
                    ask=m.ask,
                    mid=m.mid,
                    volume_24h=m.volume_24h,
                    time_to_resolution=m.time_to_resolution,
                    captured_at=now,
                )
                db.add(snap)
            await db.commit()
        logger.debug("Captured %d market snapshots", len(markets))
