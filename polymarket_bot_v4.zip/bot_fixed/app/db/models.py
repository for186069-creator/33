"""
app/db/models.py
────────────────
SQLAlchemy ORM models: Trade and MarketSnapshot.
"""
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, Float, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base


# ── Enums ────────────────────────────────────────────────────────────────────

class Side(str, enum.Enum):
    YES = "YES"
    NO = "NO"


class Resolution(str, enum.Enum):
    WIN = "WIN"
    LOSS = "LOSS"
    OPEN = "OPEN"


# ── ORM Models ───────────────────────────────────────────────────────────────

class Trade(Base):
    __tablename__ = "trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    market_name: Mapped[str] = mapped_column(String, nullable=False)
    side: Mapped[Side] = mapped_column(Enum(Side), nullable=False)

    entry_price: Mapped[float] = mapped_column(Float, nullable=False)
    exit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    size_usdc: Mapped[float] = mapped_column(Float, nullable=False)

    pnl_usdc: Mapped[float | None] = mapped_column(Float, nullable=True)
    pnl_pct: Mapped[float | None] = mapped_column(Float, nullable=True)

    fair_value_at_entry: Mapped[float] = mapped_column(Float, nullable=False)
    edge_at_entry: Mapped[float] = mapped_column(Float, nullable=False)

    resolution: Mapped[Resolution] = mapped_column(
        Enum(Resolution), default=Resolution.OPEN, nullable=False
    )

    # live-trade order id (null in paper mode)
    order_id: Mapped[str | None] = mapped_column(String, nullable=True)

    opened_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    def __repr__(self) -> str:
        return (
            f"<Trade id={self.id} {self.market_name} {self.side.value} "
            f"entry={self.entry_price:.4f} size={self.size_usdc:.2f}>"
        )


class MarketSnapshot(Base):
    __tablename__ = "market_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    market_name: Mapped[str] = mapped_column(String, nullable=False)

    bid: Mapped[float | None] = mapped_column(Float, nullable=True)
    ask: Mapped[float | None] = mapped_column(Float, nullable=True)
    mid: Mapped[float | None] = mapped_column(Float, nullable=True)
    volume_24h: Mapped[float | None] = mapped_column(Float, nullable=True)
    time_to_resolution: Mapped[float | None] = mapped_column(Float, nullable=True)  # seconds

    captured_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        return (
            f"<Snapshot {self.market_name} mid={self.mid:.4f} "
            f"captured={self.captured_at}>"
        )
