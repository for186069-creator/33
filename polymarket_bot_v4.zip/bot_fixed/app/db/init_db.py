"""
app/db/init_db.py
─────────────────
Creates all tables on first run.
"""
from __future__ import annotations

from app.core.db import Base, engine
from app.db import models  # noqa: F401  — registers ORM models with metadata


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
