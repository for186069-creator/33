"""app/main.py — v4"""
from __future__ import annotations
import asyncio, logging, sys
from contextlib import asynccontextmanager

import uvicorn
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.admin.api import admin_router, inject_services
from app.core.config import settings
from app.core.db import AsyncSessionLocal
from app.db.init_db import init_db
from app.db.models import Resolution, Trade
from app.services.btc_feed import BtcPriceFeed
from app.services.fair_value import set_btc_feed
from app.services.market_feed import MarketFeed
from app.services.order_manager import OrderManager
from app.services.position_tracker import PositionTracker
from app.services.risk_manager import RiskManager
from app.services.signal_engine import SignalEngine
from app.services.snapshot_service import SnapshotService
from sqlalchemy import select

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

btc_feed  = BtcPriceFeed()
feed      = MarketFeed()
risk      = RiskManager()
tracker   = PositionTracker(risk)
orders    = OrderManager(tracker)
snapshots = SnapshotService(feed)

_bankroll_cache    = [settings.paper_balance_usdc]
_open_names_cache: set[str] = set()
_open_count_cache  = [0]

def _bankroll_sync() -> float:   return _bankroll_cache[0]
def _open_names_sync() -> set:   return _open_names_cache
def _open_count_sync() -> int:   return _open_count_cache[0]

signals_engine = SignalEngine(
    bankroll_fn=_bankroll_sync,
    position_tracker=tracker,
    open_market_names_fn=_open_names_sync,
    open_count_fn=_open_count_sync,
)

async def _update_caches() -> None:
    async with AsyncSessionLocal() as db:
        _bankroll_cache[0] = await tracker.get_bankroll(db)
        result = await db.execute(select(Trade).where(Trade.resolution == Resolution.OPEN))
        open_trades = list(result.scalars().all())
        _open_names_cache.clear()
        _open_names_cache.update(t.market_name for t in open_trades)
        _open_count_cache[0] = len(open_trades)

async def trading_loop() -> None:
    await _update_caches()
    active = feed.active_markets()
    if not active:
        return

    if btc_feed.ready:
        logger.debug("BTC $%.2f  σ=%.0f%%  mom=%+.3f%%",
                     btc_feed.price,
                     btc_feed.realized_vol_annual * 100,
                     btc_feed.momentum * 100)

    market_states = {m.market_id: m for m in feed.all_markets()}
    async with AsyncSessionLocal() as db:
        await tracker.update(db, market_states)

    raw_signals = signals_engine.scan(active)
    if not raw_signals:
        return

    for signal in raw_signals:
        approved, reason = risk.approve(signal)
        if not approved:
            logger.debug("Rejected — %s: %s", signal.market_name, reason)
            continue

        async with AsyncSessionLocal() as db:
            trade = await orders.execute(signal, db)

        if trade:
            risk.on_position_opened(signal.market_id, signal.size_usdc)
            _open_names_cache.add(signal.market_name)
            _open_count_cache[0] += 1
            logger.info(
                "✓ %s %s | edge=%.4f | size=$%.0f | fair=%.4f | %s",
                signal.side, signal.market_name,
                signal.edge, signal.size_usdc,
                signal.fair_value, signal.signal_type,
            )

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("━" * 60)
    logger.info(" PolyQuant Bot v4 — Black-Scholes Edition")
    logger.info(" Mode: %s", "PAPER 📄" if settings.paper_trading else "LIVE 🔴")
    logger.info(" BTC Feed: %s", "✓" if settings.btc_feed_enabled else "✗")
    logger.info("━" * 60)

    await init_db()

    if settings.btc_feed_enabled:
        await btc_feed.start()
        set_btc_feed(btc_feed)
        logger.info("BTC: $%.2f  σ=%.0f%% annual",
                    btc_feed.price, btc_feed.realized_vol_annual * 100)

    await feed.start()
    inject_services(risk, feed, tracker, btc_feed)

    scheduler = AsyncIOScheduler()
    scheduler.add_job(trading_loop, "interval",
        seconds=settings.signal_check_interval_sec,
        id="trading_loop", max_instances=1, coalesce=True)
    scheduler.add_job(snapshots.capture, "interval",
        seconds=settings.snapshot_interval_sec,
        id="snapshot", max_instances=1)
    scheduler.start()
    logger.info("Scheduler started — every %ds", settings.signal_check_interval_sec)

    yield

    logger.info("Shutting down…")
    scheduler.shutdown(wait=False)
    await feed.stop()
    await btc_feed.stop()

app = FastAPI(title="PolyQuant Bot v4", version="4.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(admin_router, prefix="/api")

import os
if os.path.exists("app/static"):
    app.mount("/", StaticFiles(directory="app/static", html=True), name="static")

if __name__ == "__main__":
    uvicorn.run("app.main:app",
                host=settings.admin_host, port=settings.admin_port,
                reload=False, log_level="info")
