"""
tests/unit/test_config.py — Settings validation tests.
"""
from __future__ import annotations

import os

import pytest


class TestConfig:
    def test_default_settings_load(self):
        from app.core.config import Settings

        s = Settings()
        assert s.paper_trading is True
        assert s.spread_cents > 0
        assert s.spread_min_cents <= s.spread_cents <= s.spread_max_cents

    def test_live_mode_requires_credentials(self):
        from app.core.config import Settings

        with pytest.raises(ValueError, match="LIVE mode requires"):
            Settings(paper_trading=False, polygon_private_key="", polygon_wallet_address="")

    def test_live_mode_with_credentials(self):
        from app.core.config import Settings

        s = Settings(
            paper_trading=False,
            polygon_private_key="0x" + "a" * 64,
            polygon_wallet_address="0x" + "b" * 40,
        )
        assert s.paper_trading is False

    def test_invalid_signature_type_rejected(self):
        from app.core.config import Settings

        with pytest.raises(ValueError, match="SIGNATURE_TYPE"):
            Settings(
                paper_trading=False,
                polygon_private_key="0x" + "a" * 64,
                polygon_wallet_address="0x" + "b" * 40,
                signature_type=99,
            )

    def test_spread_bounds_validated(self):
        from app.core.config import Settings

        # spread_cents < spread_min_cents
        with pytest.raises(ValueError, match="Spread bounds violated"):
            Settings(spread_cents=1.0, spread_min_cents=2.0, spread_max_cents=10.0)

    def test_multi_level_sizes_must_sum_to_one(self):
        from app.core.config import Settings

        with pytest.raises(ValueError, match="Multi-level size percentages must sum to 1.0"):
            Settings(
                multi_level_enabled=True,
                multi_level_1_size_pct=0.5,
                multi_level_2_size_pct=0.5,
                multi_level_3_size_pct=0.5,  # total 1.5
            )

    def test_session_bounds(self):
        from app.core.config import Settings

        with pytest.raises(ValueError, match="SESSION_ACTIVE_START_UTC"):
            Settings(session_active_start_utc=22, session_active_end_utc=14)

    def test_private_key_normalized_with_0x(self):
        from app.core.config import Settings

        s = Settings(polygon_private_key="abcd1234")
        assert s.polygon_private_key.startswith("0x")

    def test_wallet_address_lowercased(self):
        from app.core.config import Settings

        s = Settings(polygon_wallet_address="0xABCDEF1234567890")
        assert s.polygon_wallet_address == "0xabcdef1234567890"

    def test_keywords_list(self):
        from app.core.config import Settings

        s = Settings(auto_pick_keywords="NBA, NFL, Soccer")
        assert s.keywords_list == ["nba", "nfl", "soccer"]

    def test_exclude_keywords_list(self):
        from app.core.config import Settings

        s = Settings(auto_pick_exclude_keywords="bitcoin, eth")
        assert "bitcoin" in s.exclude_keywords_list
        assert "eth" in s.exclude_keywords_list

    def test_explicit_token_ids_empty(self):
        from app.core.config import Settings

        s = Settings(market_token_ids="")
        assert s.explicit_token_ids == []

    def test_explicit_token_ids_parsed(self):
        from app.core.config import Settings

        s = Settings(market_token_ids="abc, def , ghi")
        assert s.explicit_token_ids == ["abc", "def", "ghi"]
