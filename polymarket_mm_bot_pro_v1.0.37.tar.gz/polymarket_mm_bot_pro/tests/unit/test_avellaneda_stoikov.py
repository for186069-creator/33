"""
tests/unit/test_avellaneda_stoikov.py — A-S reservation price tests.

Verifies:
  - Reservation price shifts opposite to inventory (long → r < mid)
  - Sigma is floored at AS_MIN_VOLATILITY
  - Outputs are clamped to [0.01, 0.99]
  - Empty history returns mid unchanged
"""
from __future__ import annotations

import math

import pytest

from app.services.pricing.avellaneda_stoikov import AvellanedaStoikov


class TestAvellanedaStoikov:
    def test_empty_history_returns_mid(self):
        as_calc = AvellanedaStoikov()
        r, sigma, penalty = as_calc.compute("tok", current_mid=0.50, inventory_tokens=0)
        assert r == 0.50
        assert sigma > 0  # floored
        assert penalty == 0.0

    def test_long_inventory_lowers_reservation(self):
        """Long position → reservation < mid (encourage selling)."""
        as_calc = AvellanedaStoikov()
        # Feed some price history to get a real sigma
        for p in [0.50, 0.501, 0.499, 0.502, 0.498, 0.500, 0.501, 0.499, 0.500, 0.502]:
            as_calc.update("tok", p)

        r_long, _, penalty_long = as_calc.compute(
            "tok", current_mid=0.50, inventory_tokens=100, max_inventory_tokens=100
        )
        # Long inventory → penalty > 0 → r < mid
        assert penalty_long > 0, "Long inventory should produce positive penalty"
        assert r_long < 0.50, "Long inventory should lower reservation price"

    def test_short_inventory_raises_reservation(self):
        """Short position → reservation > mid (encourage buying)."""
        as_calc = AvellanedaStoikov()
        for p in [0.50, 0.501, 0.499, 0.502, 0.498, 0.500, 0.501, 0.499, 0.500, 0.502]:
            as_calc.update("tok", p)

        r_short, _, penalty_short = as_calc.compute(
            "tok", current_mid=0.50, inventory_tokens=-100, max_inventory_tokens=100
        )
        assert penalty_short < 0, "Short inventory should produce negative penalty"
        assert r_short > 0.50, "Short inventory should raise reservation price"

    def test_flat_inventory_no_shift(self):
        """Zero inventory → reservation == mid."""
        as_calc = AvellanedaStoikov()
        for p in [0.50, 0.501, 0.499]:
            as_calc.update("tok", p)
        r, _, penalty = as_calc.compute(
            "tok", current_mid=0.50, inventory_tokens=0
        )
        assert penalty == 0.0
        assert r == 0.50

    def test_reservation_clamped(self):
        """Reservation price never goes below 0.01 or above 0.99."""
        as_calc = AvellanedaStoikov()
        for p in [0.50, 0.501, 0.499]:
            as_calc.update("tok", p)
        # Extreme long inventory
        r, _, _ = as_calc.compute(
            "tok", current_mid=0.50, inventory_tokens=10000, max_inventory_tokens=100
        )
        assert 0.01 <= r <= 0.99
        # Extreme short
        r, _, _ = as_calc.compute(
            "tok", current_mid=0.50, inventory_tokens=-10000, max_inventory_tokens=100
        )
        assert 0.01 <= r <= 0.99

    def test_sigma_floored(self):
        """Sigma is at least AS_MIN_VOLATILITY."""
        as_calc = AvellanedaStoikov()
        # Identical prices → zero variance → floored sigma
        for _ in range(10):
            as_calc.update("tok", 0.50)
        _, sigma, _ = as_calc.compute("tok", 0.50, 0)
        from app.core.config import settings

        assert sigma >= settings.as_min_volatility

    def test_higher_gamma_more_aggressive(self):
        """Higher gamma → larger inventory penalty."""
        from app.core.config import settings

        as_calc = AvellanedaStoikov()
        for p in [0.50, 0.501, 0.499, 0.502, 0.498]:
            as_calc.update("tok", p)

        # Save original gamma
        orig = settings.as_gamma
        try:
            settings.as_gamma = 0.1
            _, _, penalty_low = as_calc.compute("tok", 0.50, 50, 100)

            settings.as_gamma = 1.0
            _, _, penalty_high = as_calc.compute("tok", 0.50, 50, 100)

            assert penalty_high > penalty_low, "Higher gamma should mean larger penalty"
        finally:
            settings.as_gamma = orig

    def test_clear(self):
        as_calc = AvellanedaStoikov()
        as_calc.update("tok", 0.50)
        assert as_calc.get_state("tok") is not None
        as_calc.clear("tok")
        assert as_calc.get_state("tok") is None
