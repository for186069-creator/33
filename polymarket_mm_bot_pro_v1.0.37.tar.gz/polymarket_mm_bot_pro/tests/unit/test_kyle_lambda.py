"""
tests/unit/test_kyle_lambda.py — Kyle's lambda tests.

Verifies:
  - Balanced book → lambda ≈ 0, multiplier ≈ 1.0
  - Imbalanced book → lambda > 0, multiplier > 1.0
  - Empty book → no crash, returns 1.0 multiplier
"""
from __future__ import annotations

import pytest

from app.services.pricing.kyle_lambda import KyleLambda


class TestKyleLambda:
    def test_balanced_book_low_lambda(self, sample_book):
        kyle = KyleLambda()
        lam, mult = kyle.update_and_compute("tok", sample_book)
        # Balanced book → low lambda, mult ~1.0
        assert lam < 0.3, f"Balanced book should have low lambda, got {lam}"
        assert mult <= 1.5, f"Balanced book should have mult ~1.0, got {mult}"

    def test_imbalanced_book_high_lambda(self, imbalanced_book):
        kyle = KyleLambda()
        # Multiple updates to smooth out
        for _ in range(5):
            lam, mult = kyle.update_and_compute("tok", imbalanced_book)
        assert lam > 0.5, f"Imbalanced book should have high lambda, got {lam}"
        assert mult > 1.5, f"Imbalanced book should have mult > 1.5, got {mult}"

    def test_empty_book_safe(self):
        from app.services.clob_client import MarketBook

        kyle = KyleLambda()
        empty_book = MarketBook(token_id="empty")
        lam, mult = kyle.update_and_compute("empty", empty_book)
        assert lam == 0.0
        assert mult == 1.0

    def test_one_sided_book_safe(self):
        """Only bids, no asks → no crash."""
        from app.services.clob_client import MarketBook, OrderLevel

        kyle = KyleLambda()
        book = MarketBook(
            token_id="one-sided",
            bids=[OrderLevel(0.50, 100)],
            asks=[],
        )
        lam, mult = kyle.update_and_compute("one-sided", book)
        assert mult == 1.0  # safe default

    def test_multiplier_capped(self, imbalanced_book):
        """Multiplier never exceeds kyle_max_spread_mult."""
        from app.core.config import settings

        kyle = KyleLambda()
        for _ in range(30):  # fill history
            _, mult = kyle.update_and_compute("tok", imbalanced_book)
        assert mult <= settings.kyle_max_spread_mult + 0.001

    def test_clear(self, sample_book):
        kyle = KyleLambda()
        kyle.update_and_compute("tok", sample_book)
        assert kyle.get_state("tok") is not None
        kyle.clear("tok")
        assert kyle.get_state("tok") is None
