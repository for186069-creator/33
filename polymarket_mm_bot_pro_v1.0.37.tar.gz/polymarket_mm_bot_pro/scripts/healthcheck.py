#!/usr/bin/env python3
"""Healthcheck script — exit 0 if bot is healthy, 1 otherwise."""
from __future__ import annotations

import sys
import urllib.request


def main() -> int:
    try:
        with urllib.request.urlopen("http://127.0.0.1:8000/health", timeout=3) as resp:
            if resp.status == 200:
                return 0
            print(f"HTTP {resp.status}", file=sys.stderr)
            return 1
    except Exception as e:
        print(f"Healthcheck failed: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
