#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then
    echo "ERROR: .env not found. Run: cp .env.example .env"
    exit 1
fi
if grep -q "^PAPER_TRADING=true" .env; then
    echo "ERROR: PAPER_TRADING=true. Set to false for LIVE."
    exit 1
fi
echo "LIVE MODE - REAL ORDERS. Start with \$5-20 only."
read -p "Type 'yes' to continue: " confirm
[ "$confirm" = "yes" ] || exit 0
exec python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --log-level info
