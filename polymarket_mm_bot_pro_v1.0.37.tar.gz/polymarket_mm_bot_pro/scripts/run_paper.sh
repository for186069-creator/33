#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then
    echo "Copying .env.example to .env"
    cp .env.example .env
fi
echo "Starting PAPER mode. Dashboard: http://127.0.0.1:8000"
exec python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --log-level info
