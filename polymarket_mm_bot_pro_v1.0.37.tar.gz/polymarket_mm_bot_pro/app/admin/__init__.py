"""app.admin — REST API + dashboard."""
