"""
app/admin/api.py — Admin REST endpoints.

All endpoints are prefixed /api. Includes:
  - Dashboard / inventory / quotes / markets / trades
  - Config get/set
  - Risk control: start/pause/resume/emergency_stop
  - Mode toggle: paper <-> live (with checklist)
  - Diagnostics: 8-point health check
  - Live checklist: 8-point readiness check
  - Analytics: by_market, time_series

Authentication: NONE. This server is intended for local use only (binds to
127.0.0.1 by default). Exposing to internet requires adding auth.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.db import get_db
from app.core.logging import get_logger
from app.db.models import HaltEvent, Quote, Trade

log = get_logger(__name__)

admin_router = APIRouter(tags=["admin"])
root_router = APIRouter(tags=["root"])

# Injected at startup (main.py)
_clob = None
_inventory = None
_mm = None
_risk = None
_analytics = None
_alerter = None


def inject_services(clob, inventory, mm, risk, analytics, alerter) -> None:
    global _clob, _inventory, _mm, _risk, _analytics, _alerter
    _clob = clob
    _inventory = inventory
    _mm = mm
    _risk = risk
    _analytics = analytics
    _alerter = alerter


def _require_services() -> None:
    if not all([_clob, _inventory, _mm, _risk]):
        raise HTTPException(503, "Bot not initialized")


# ═══════════════════════════════════════════════════════════════════════
# Dashboard
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/dashboard")
async def dashboard(db: AsyncSession = Depends(get_db)):
    """Main dashboard: P&L, win rate, active quotes, markets."""
    _require_services()
    # FIX: use naive UTC for SQLite comparison (SQLite stores naive datetimes;
    # comparing with timezone-aware raises TypeError in Python 3.12)
    cutoff = datetime.utcnow() - timedelta(hours=24)
    result = await db.execute(
        select(Trade).where(Trade.timestamp >= cutoff).order_by(Trade.timestamp.desc()).limit(500)
    )
    recent_trades = list(result.scalars().all())

    all_result = await db.execute(select(Trade))
    all_trades = list(all_result.scalars().all())

    summary = _analytics.compute_summary(all_trades)

    # Inventory value at current mid
    inventory_value = 0.0
    unrealized_pnl = 0.0
    for tid, inv in _inventory.inventories.items():
        book = _clob.books.get(tid)
        if book and inv.net_tokens != 0:
            inventory_value += inv.net_tokens * book.mid
            unrealized_pnl += inv.unrealized_pnl(book.mid)

    total_equity = _inventory.bankroll + inventory_value

    return {
        "mode": "LIVE" if not settings.paper_trading else "PAPER",
        "trading_paused": _mm._trading_paused,
        "halted": _inventory.halted,
        "halt_reason": _inventory.halt_reason,
        "bankroll_usdc": round(_inventory.bankroll, 4),
        "inventory_value_usdc": round(inventory_value, 4),
        "unrealized_pnl_usdc": round(unrealized_pnl, 4),
        "total_equity_usdc": round(total_equity, 4),
        "starting_balance_usdc": round(_inventory.starting_balance, 2),
        "daily_pnl_usdc": round(_inventory.daily_pnl, 4),
        "consecutive_losses": _inventory.consecutive_losses,
        "max_inventory_usdc": round(_inventory.max_inventory_usdc(), 2),
        "active_markets": len(_clob.books),
        "active_quotes": sum(len(qs) for qs in _mm.active_quotes.values()),
        "cycle_count": _mm._cycle_count,
        "fill_count": _mm._fill_count,
        "round_trip_count": _mm._round_trip_count,
        "ws_age_sec": round(_clob.last_ws_msg_age, 1),
        "summary": summary,
        "recent_trades": [
            {
                "id": t.id,
                "market": t.market_name[:40],
                "side": t.side.value,
                "price": t.price,
                "size_usdc": t.size_usdc,
                "pnl": t.pnl_usdc,
                "level": t.level,
                "is_hedge": t.is_hedge,
                "timestamp": t.timestamp.isoformat() if t.timestamp else None,
            }
            for t in recent_trades[:20]
        ],
    }


@admin_router.get("/inventory")
async def inventory_status():
    _require_services()
    # Add unrealized P&L per market
    status = _inventory.status
    for tid, mkt in status["markets"].items():
        book = _clob.books.get(tid)
        if book:
            inv = _inventory.get_inventory(tid)
            mkt["unrealized_pnl"] = round(inv.unrealized_pnl(book.mid), 4)
            mkt["current_mid"] = round(book.mid, 4)
            mkt["inventory_ratio"] = round(
                inv.inventory_ratio(_inventory.max_inventory_usdc()), 3
            )
    return status


@admin_router.get("/quotes")
async def active_quotes():
    _require_services()
    return _mm.status


@admin_router.get("/markets")
async def markets():
    _require_services()
    now_ts = datetime.now(timezone.utc).timestamp()
    result = []
    for tid, book in _clob.books.items():
        info = _clob.markets.get(tid)
        inv = _inventory.inventories.get(tid)

        # Compute TTR (Time To Resolution) in hours
        ttr_hours = None
        ttr_warning = False
        if info and info.end_date_ts > 0:
            ttr_sec = info.end_date_ts - now_ts
            ttr_hours = round(ttr_sec / 3600, 1)
            # Warning if within pre_resolution_exit window
            ttr_warning = ttr_sec < settings.pre_resolution_exit_sec

        result.append(
            {
                "token_id": tid[:16],
                "question": info.question[:60] if info else "Unknown",
                "outcome": info.outcome if info else "?",
                "best_bid": round(book.best_bid, 4),
                "best_ask": round(book.best_ask, 4),
                "mid": round(book.mid, 4),
                "spread_cents": round(book.spread * 100, 2),
                "volume_24h": round(info.volume_24h, 0) if info else 0,
                "end_date": datetime.fromtimestamp(
                    info.end_date_ts, tz=timezone.utc
                ).isoformat() if info and info.end_date_ts > 0 else None,
                "ttr_hours": ttr_hours,
                "ttr_warning": ttr_warning,
                "neg_risk": book.neg_risk,
                "tick_size": book.tick_size,
                "last_update_age_sec": round(time_now() - book.last_update, 1),
                "our_inventory_tokens": round(inv.net_tokens, 4) if inv else 0,
                "our_inventory_usdc": round(inv.net_usdc_at_entry, 4) if inv else 0,
            }
        )
    return {"markets": result, "count": len(result)}


@admin_router.post("/markets/refresh_info")
async def refresh_market_info():
    _require_services()
    await _clob._fetch_market_info(list(_clob.books.keys()))
    return {"ok": True, "markets": len(_clob.markets)}


@admin_router.post("/markets/replace")
async def replace_markets(count: int = 5):
    """Replace ALL current markets with new auto-picked ones."""
    _require_services()
    # Cancel all quotes
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
    # Stop WS subscriptions for old markets
    old_tids = list(_clob.books.keys())
    for tid in old_tids:
        await _clob._feed.unsubscribe(tid)
    _clob.books.clear()
    _clob.markets.clear()
    _clob._feed._subscribed.clear()
    # Discover new
    old_count = settings.auto_pick_count
    settings.auto_pick_count = max(1, min(count, 20))
    try:
        infos = await _clob.discover_markets()
    finally:
        settings.auto_pick_count = old_count
    # Create fresh books for newly discovered markets
    from app.services.clob_client import MarketBook

    for info in infos:
        _clob.books[info.token_id] = MarketBook(token_id=info.token_id)
        _clob.markets[info.token_id] = info
    # Restart WS
    await _clob._feed.stop()
    await _clob._feed.start([i.token_id for i in infos])
    await _clob._refresh_all_books()
    return {"ok": True, "new_markets": len(infos)}


@admin_router.post("/markets/add")
async def add_markets(count: int = 3):
    """ADD new markets WITHOUT removing existing ones.

    Unlike /markets/replace which clears everything, this endpoint:
    1. Keeps all current markets, positions, and quotes
    2. Discovers new markets via Gamma API
    3. Adds only markets NOT already in books
    4. Subscribes WS for new markets
    5. Refreshes books

    Use this to scale up trading without losing P&L.
    """
    _require_services()
    existing_count = len(_clob.books)
    log.info("markets_add_started", existing=existing_count, requested=count)

    # Discover new markets (temporarily override count)
    old_count = settings.auto_pick_count
    settings.auto_pick_count = max(1, min(count + existing_count, 20))
    try:
        infos = await _clob.discover_markets()
    finally:
        settings.auto_pick_count = old_count

    # Add only markets NOT already in books
    from app.services.clob_client import MarketBook

    added = 0
    new_token_ids = []
    for info in infos:
        if info.token_id not in _clob.books:
            _clob.books[info.token_id] = MarketBook(token_id=info.token_id)
            _clob.markets[info.token_id] = info
            new_token_ids.append(info.token_id)
            added += 1

    if added > 0:
        # Subscribe WS for new markets (without restarting existing)
        for tid in new_token_ids:
            await _clob._feed.subscribe(tid)
        await _clob._refresh_all_books()
        log.info("markets_add_done", added=added, total=len(_clob.books))
    else:
        log.info("markets_add_no_new", existing=existing_count)

    return {
        "ok": True,
        "added": added,
        "total_markets": len(_clob.books),
        "existing_before": existing_count,
        "message": f"Added {added} new markets (total: {len(_clob.books)})" if added > 0
        else f"No new markets found (all {existing_count} already loaded)",
    }


@admin_router.get("/trades")
async def list_trades(limit: int = 100, db: AsyncSession = Depends(get_db)):
    _require_services()
    result = await db.execute(
        select(Trade).order_by(Trade.timestamp.desc()).limit(limit)
    )
    trades = list(result.scalars().all())
    return {
        "trades": [
            {
                "id": t.id,
                "market_id": t.market_id[:16],
                "market_name": t.market_name[:50],
                "side": t.side.value,
                "price": t.price,
                "size_usdc": t.size_usdc,
                "size_tokens": round(t.size_tokens, 4),
                "pnl_usdc": t.pnl_usdc,
                "fees_usdc": t.fees_usdc,
                "inventory_after": round(t.inventory_after, 4),
                "level": t.level,
                "is_hedge": t.is_hedge,
                "mode": t.mode.value,
                "reservation_price": t.reservation_price,
                "spread_cents": t.spread_cents,
                "timestamp": t.timestamp.isoformat() if t.timestamp else None,
            }
            for t in trades
        ],
        "count": len(trades),
    }


# ═══════════════════════════════════════════════════════════════════════
# Config
# ═══════════════════════════════════════════════════════════════════════


class ConfigUpdate(BaseModel):
    spread_cents: float | None = None
    spread_min_cents: float | None = None
    spread_max_cents: float | None = None
    order_size_usdc: float | None = None
    order_size_min_usdc: float | None = None
    max_inventory_usdc: float | None = None
    max_inventory_pct_of_bankroll: float | None = None
    requote_interval_sec: float | None = None
    requote_threshold_cents: float | None = None
    max_daily_loss_usd: float | None = None
    stop_trading_consecutive_losses: int | None = None
    as_gamma: float | None = None
    pre_resolution_exit_sec: int | None = None
    auto_pick_count: int | None = None
    auto_pick_min_volume_24h: float | None = None
    auto_pick_min_spread_cents: float | None = None
    multi_level_enabled: bool | None = None
    paper_balance_usdc: float | None = None  # Start balance for Reset Paper


@admin_router.get("/config")
async def get_config():
    return {
        "paper_trading": settings.paper_trading,
        "paper_balance_usdc": settings.paper_balance_usdc,
        "spread_cents": settings.spread_cents,
        "spread_min_cents": settings.spread_min_cents,
        "spread_max_cents": settings.spread_max_cents,
        "order_size_usdc": settings.order_size_usdc,
        "order_size_min_usdc": settings.order_size_min_usdc,
        "max_inventory_usdc": settings.max_inventory_usdc,
        "max_inventory_pct_of_bankroll": settings.max_inventory_pct_of_bankroll,
        "requote_interval_sec": settings.requote_interval_sec,
        "requote_threshold_cents": settings.requote_threshold_cents,
        "max_daily_loss_usd": settings.max_daily_loss_usd,
        "stop_trading_consecutive_losses": settings.stop_trading_consecutive_losses,
        "as_gamma": settings.as_gamma,
        "pre_resolution_exit_sec": settings.pre_resolution_exit_sec,
        "auto_pick_count": settings.auto_pick_count,
        "auto_pick_min_volume_24h": settings.auto_pick_min_volume_24h,
        "auto_pick_min_spread_cents": settings.auto_pick_min_spread_cents,
        "multi_level_enabled": settings.multi_level_enabled,
        "hedging_enabled": settings.hedging_enabled,
        "session_quoting_enabled": settings.session_quoting_enabled,
        "adverse_selection_enabled": settings.adverse_selection_enabled,
    }


@admin_router.post("/config")
async def update_config(body: ConfigUpdate):
    _require_services()
    data = body.model_dump(exclude_none=True)
    for key, value in data.items():
        if hasattr(settings, key):
            setattr(settings, key, value)
            log.info("config_updated", key=key, value=value)
    return {"ok": True, "updated": list(data.keys())}


class DepositUpdate(BaseModel):
    amount_usdc: float = Field(gt=0)


@admin_router.post("/config/deposit")
async def set_deposit(body: DepositUpdate):
    """Set paper balance (PAPER mode only).

    Updates both:
    1. settings.paper_balance_usdc (so Reset Paper uses new value)
    2. _inventory.bankroll + starting_balance (immediate effect)
    """
    if not settings.paper_trading:
        raise HTTPException(400, "Cannot set deposit in LIVE mode")
    # Update settings so Reset Paper uses new value
    settings.paper_balance_usdc = body.amount_usdc
    # Update current bankroll immediately
    _inventory.bankroll = body.amount_usdc
    _inventory.starting_balance = body.amount_usdc
    log.info("deposit_set", amount=body.amount_usdc, source="api")
    return {"ok": True, "bankroll": _inventory.bankroll}


# ═══════════════════════════════════════════════════════════════════════
# Trading control
# ═══════════════════════════════════════════════════════════════════════


@admin_router.post("/start")
async def start_trading():
    _require_services()
    if _mm.is_trading:
        return {"started": False, "message": "Already trading"}
    _mm.start_trading()
    return {"started": True, "message": "Trading STARTED — placing quotes"}


@admin_router.post("/pause")
async def pause_trading():
    _require_services()
    active = sum(len(qs) for qs in _mm.active_quotes.values())
    _mm.stop_trading()
    return {"paused": True, "orders_canceled": active}


@admin_router.post("/risk/resume")
async def resume_trading():
    _require_services()
    if not _inventory.halted:
        return {"resumed": False, "message": "Not halted"}
    prev = _risk.resume(preserve_counters=False)
    return {"resumed": True, "previous_reason": prev}


@admin_router.post("/emergency_stop")
async def emergency_stop():
    _require_services()
    canceled = 0
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
        canceled += 1
    _risk.emergency_stop()
    await _alerter.send(
        "critical",
        "EMERGENCY STOP",
        f"Manual kill switch triggered. {canceled} markets' quotes canceled.",
        alert_key="emergency_stop",
    )
    return {
        "stopped": True,
        "orders_canceled": canceled,
        "message": "🛑 EMERGENCY STOP — all orders canceled, trading halted",
    }


@admin_router.post("/mode/toggle")
async def toggle_mode():
    """Toggle PAPER <-> LIVE. LIVE requires checklist pass."""
    _require_services()
    import asyncio

    if settings.paper_trading:
        # PAPER -> LIVE: run checklist
        checklist = await live_checklist()
        if not checklist["ready"]:
            return {
                "success": False,
                "message": "Cannot switch to LIVE — fix issues first",
                "checks": checklist["checks"],
            }
        # Pause bot, cancel all quotes
        _inventory.halt(reason="USER_PAUSE", detail="Switching to LIVE mode")
        for tid in list(_mm.active_quotes.keys()):
            await _mm._cancel_all_levels(tid)
        await asyncio.sleep(1)
        # Switch
        settings.paper_trading = False
        _inventory.resume(preserve_counters=True)
        await _alerter.send("critical", "LIVE MODE", "Bot switched to LIVE — real orders will be placed!")
        return {"success": True, "mode": "LIVE", "message": "🔴 LIVE mode active"}
    else:
        # LIVE -> PAPER: always safe
        _inventory.halt(reason="USER_PAUSE", detail="Switching to PAPER mode")
        for tid in list(_mm.active_quotes.keys()):
            await _mm._cancel_all_levels(tid)
        await asyncio.sleep(1)
        settings.paper_trading = True
        _inventory.resume(preserve_counters=True)
        await _alerter.send("info", "PAPER MODE", "Bot switched to PAPER — safe simulation.")
        return {"success": True, "mode": "PAPER", "message": "📄 PAPER mode active"}


@admin_router.post("/paper/reset")
async def reset_paper(db: AsyncSession = Depends(get_db)):
    """Reset paper mode: clear inventory, trades, reset bankroll."""
    if not settings.paper_trading:
        raise HTTPException(400, "Not in PAPER mode")
    _require_services()
    # Cancel quotes
    for tid in list(_mm.active_quotes.keys()):
        await _mm._cancel_all_levels(tid)
    # Reset inventory
    _inventory.inventories.clear()
    _inventory.bankroll = settings.paper_balance_usdc
    _inventory.starting_balance = settings.paper_balance_usdc
    _inventory.consecutive_losses = 0
    _inventory.daily_pnl = 0.0
    _inventory.halted = False
    _inventory.halt_reason = ""
    # Reset in-memory counters
    _mm._fill_count = 0
    _mm._round_trip_count = 0
    _mm._cycle_count = 0
    _mm._hedge_attempts = 0
    _mm._hedge_fills = 0
    # Wipe DB trades
    from sqlalchemy import delete

    await db.execute(delete(Trade))
    await db.execute(delete(Quote))
    await db.commit()
    log.info("paper_reset_complete")
    return {"ok": True, "new_bankroll": _inventory.bankroll}


# ═══════════════════════════════════════════════════════════════════════
# Analytics
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/analytics/by_market")
async def by_market(db: AsyncSession = Depends(get_db)):
    _require_services()
    result = await db.execute(select(Trade))
    trades = list(result.scalars().all())
    return {"markets": _analytics.by_market(trades)}


@admin_router.get("/analytics/time_series")
async def time_series(db: AsyncSession = Depends(get_db)):
    _require_services()
    result = await db.execute(select(Trade).order_by(Trade.timestamp))
    trades = list(result.scalars().all())
    return {"series": _analytics.pnl_time_series(trades)}


# ═══════════════════════════════════════════════════════════════════════
# Diagnostics
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/diagnostics")
async def diagnostics(db: AsyncSession = Depends(get_db)):
    """8-point health check."""
    _require_services()
    import time

    checks = []
    overall_healthy = True

    # 1. WebSocket
    ws_age = _clob.last_ws_msg_age
    ws_ok = ws_age < settings.stale_data_threshold_sec
    detail = f"Last message {ws_age:.0f}s ago"
    if ws_age > 60:
        detail += " ⛔ INTERNET DOWN?"
    elif ws_age > 30:
        detail += " ⚠️ STALE"
    checks.append({"name": "WebSocket", "healthy": ws_ok, "detail": detail})
    if not ws_ok:
        overall_healthy = False

    # 2. Market data freshness
    if _clob.books:
        stale = sum(1 for b in _clob.books.values() if time.monotonic() - b.last_update > 15)
        total = len(_clob.books)
        books_ok = stale == 0
        checks.append(
            {
                "name": "Market Data",
                "healthy": books_ok,
                "detail": f"{total - stale}/{total} books fresh" + (f" ({stale} STALE!)" if stale else ""),
            }
        )
        if not books_ok:
            overall_healthy = False
    else:
        checks.append({"name": "Market Data", "healthy": False, "detail": "No books"})
        overall_healthy = False

    # 3. Book quality
    if _clob.books:
        good = sum(1 for b in _clob.books.values() if b.bids and b.asks)
        total = len(_clob.books)
        ok = good >= total * 0.8
        checks.append(
            {
                "name": "Book Quality",
                "healthy": ok,
                "detail": f"{good}/{total} have bid+ask",
            }
        )
        if not ok:
            overall_healthy = False

    # 4. P&L health (total equity)
    inventory_value = 0.0
    for tid, inv in _inventory.inventories.items():
        book = _clob.books.get(tid)
        if book and inv.net_tokens != 0:
            inventory_value += inv.net_tokens * book.mid
    total_equity = _inventory.bankroll + inventory_value
    pnl = total_equity - _inventory.starting_balance
    pnl_ok = pnl > -settings.max_daily_loss_usd
    checks.append(
        {
            "name": "P&L Health",
            "healthy": pnl_ok,
            "detail": f"{'+' if pnl >= 0 else ''}{pnl:.2f} USDC (cash ${_inventory.bankroll:.2f} + inv ${inventory_value:.2f})",
        }
    )
    if not pnl_ok:
        overall_healthy = False

    # 5. Inventory risk
    # Use the LARGER of ($ cap, % of bankroll) so inventory can scale with profits
    # Previously: min($5, 25%×bankroll) = $5 always (cap too restrictive when bankroll grows)
    # Now: max($5, 25%×bankroll) — allows scaling while keeping $5 floor
    total_inv = sum(abs(inv.net_usdc_at_entry) for inv in _inventory.inventories.values())
    pct_cap = _inventory.bankroll * settings.max_inventory_pct_of_bankroll
    effective_max_per_market = max(settings.max_inventory_usdc, pct_cap)
    max_allowed = effective_max_per_market * max(len(_inventory.inventories), 1)
    inv_ok = total_inv < max_allowed * 0.9
    checks.append(
        {
            "name": "Inventory Risk",
            "healthy": inv_ok,
            "detail": f"${total_inv:.2f} / ${max_allowed:.2f} ({total_inv / max(max_allowed, 1) * 100:.0f}%) — {len(_inventory.inventories)} markets × ${effective_max_per_market:.2f}",
        }
    )
    if not inv_ok:
        overall_healthy = False

    # 6. Trading status
    if _inventory.halted:
        checks.append(
            {"name": "Trading Status", "healthy": False, "detail": f"🛑 HALTED: {_inventory.halt_reason}"}
        )
        overall_healthy = False
    elif _mm._trading_paused:
        checks.append({"name": "Trading Status", "healthy": True, "detail": "⏸ PAUSED"})
    else:
        checks.append({"name": "Trading Status", "healthy": True, "detail": "▶ Active"})

    # 7. Fill rate
    fill_rate = (_mm._fill_count / max(_mm._cycle_count, 1)) * 100
    fill_ok = fill_rate > 0.5 or _mm._cycle_count < 60
    checks.append(
        {
            "name": "Fill Rate",
            "healthy": fill_ok,
            "detail": f"{_mm._fill_count} fills / {_mm._cycle_count} cycles ({fill_rate:.1f}%)",
        }
    )
    if not fill_ok:
        overall_healthy = False

    # 8. Adverse selection
    adverse_cooldown = _risk.adverse_selection.global_cooldown_remaining()
    adverse_ok = adverse_cooldown <= 0
    checks.append(
        {
            "name": "Adverse Selection",
            "healthy": adverse_ok,
            "detail": f"Global cooldown: {adverse_cooldown:.1f}s" + (" (active)" if adverse_cooldown > 0 else ""),
        }
    )

    return {
        "overall_healthy": overall_healthy,
        "status": "✅ ALL SYSTEMS OK" if overall_healthy else "⚠️ ISSUES DETECTED",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ═══════════════════════════════════════════════════════════════════════
# Live readiness checklist
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/live/checklist")
async def live_checklist():
    """8-point readiness check for LIVE mode."""
    checks = []
    ready = True

    if settings.paper_trading:
        checks.append({"name": "Paper mode OFF", "ok": False, "detail": "PAPER_TRADING=true"})
        ready = False
    else:
        checks.append({"name": "Paper mode OFF", "ok": True, "detail": "Live mode enabled"})

    if not settings.polygon_private_key:
        checks.append({"name": "Polygon private key", "ok": False, "detail": "POLYGON_PRIVATE_KEY not set"})
        ready = False
    else:
        checks.append(
            {"name": "Polygon private key", "ok": True, "detail": f"Key set (...{settings.polygon_private_key[-4:]})"}
        )

    if not settings.polygon_wallet_address:
        checks.append({"name": "Wallet address", "ok": False, "detail": "POLYGON_WALLET_ADDRESS not set"})
        ready = False
    else:
        checks.append(
            {"name": "Wallet address", "ok": True, "detail": f"0x...{settings.polygon_wallet_address[-4:]}"}
        )

    if settings.signature_type not in (0, 1, 2):
        checks.append(
            {"name": "Signature type", "ok": False, "detail": f"Invalid: {settings.signature_type}"}
        )
        ready = False
    else:
        names = {0: "EOA", 1: "POLY_PROXY", 2: "POLY_GNOSIS_SAFE"}
        checks.append(
            {"name": "Signature type", "ok": True, "detail": f"{names[settings.signature_type]} ({settings.signature_type})"}
        )

    if settings.order_size_usdc > 50:
        checks.append(
            {"name": "Order size safe", "ok": False, "detail": f"${settings.order_size_usdc} — too high (max $50)"}
        )
        ready = False
    elif settings.order_size_usdc < 2:
        checks.append(
            {"name": "Order size safe", "ok": False, "detail": f"${settings.order_size_usdc} — too low (min $5)"}
        )
        ready = False
    else:
        checks.append({"name": "Order size safe", "ok": True, "detail": f"${settings.order_size_usdc} per order"})

    if settings.max_daily_loss_usd > 50:
        checks.append(
            {"name": "Daily loss limit", "ok": False, "detail": f"${settings.max_daily_loss_usd} — too high"}
        )
        ready = False
    else:
        checks.append(
            {"name": "Daily loss limit", "ok": True, "detail": f"${settings.max_daily_loss_usd} max daily loss"}
        )

    # Check USDC balance via CLOB API
    try:
        bal = await _clob.get_balance_allowance()
        balance_usd = float(bal.get("balance", 0)) / 1e6  # USDC has 6 decimals
        if balance_usd < 5:
            checks.append(
                {"name": "USDC balance", "ok": False, "detail": f"${balance_usd:.2f} — too low (need ≥$5)"}
            )
            ready = False
        else:
            checks.append(
                {"name": "USDC balance", "ok": True, "detail": f"${balance_usd:.2f} USDC"}
            )
    except Exception as e:
        checks.append(
            {"name": "USDC balance", "ok": False, "detail": f"Check failed: {e}"}
        )
        ready = False

    # Allowance check
    try:
        bal = await _clob.get_balance_allowance()
        allowance = float(bal.get("allowance", 0)) / 1e6
        if allowance < 5:
            checks.append(
                {
                    "name": "USDC allowance",
                    "ok": False,
                    "detail": f"${allowance:.2f} — approve USDC for the exchange contract",
                }
            )
            ready = False
        else:
            checks.append(
                {"name": "USDC allowance", "ok": True, "detail": f"${allowance:.2f} approved"}
            )
    except Exception as e:
        checks.append(
            {"name": "USDC allowance", "ok": False, "detail": f"Check failed: {e}"}
        )
        ready = False

    return {
        "ready": ready,
        "status": "✅ READY FOR LIVE" if ready else "❌ NOT READY — fix issues above",
        "checks": checks,
    }


# ═══════════════════════════════════════════════════════════════════════
# Alerts log
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/alerts")
async def alerts():
    return {"alerts": _alerter.recent_alerts if _alerter else []}


# ═══════════════════════════════════════════════════════════════════════
# Halt events
# ═══════════════════════════════════════════════════════════════════════


@admin_router.get("/halt_events")
async def halt_events(limit: int = 50, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HaltEvent).order_by(HaltEvent.timestamp.desc()).limit(limit)
    )
    events = list(result.scalars().all())
    return {
        "events": [
            {
                "id": e.id,
                "event": e.event,
                "reason": e.reason,
                "detail": e.detail,
                "bankroll_at_event": e.bankroll_at_event,
                "timestamp": e.timestamp.isoformat() if e.timestamp else None,
            }
            for e in events
        ]
    }


# ═══════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════


def time_now() -> float:
    import time

    return time.monotonic()


@root_router.get("/health")
async def health():
    """Simple liveness probe."""
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}
