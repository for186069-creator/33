"""
app/core/metrics.py — Prometheus metrics for observability.

Expose /metrics endpoint (mounted in main.py) for scraping by Prometheus.
Use gauges for state, counters for events, histograms for latency.
"""
from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram

# ── Trading state ────────────────────────────────────────────────────────
BANKROLL_USD = Gauge(
    "mm_bankroll_usd", "Current bankroll (cash, excludes inventory)"
)
INVENTORY_USD = Gauge(
    "mm_inventory_usd", "Total USD exposure in open inventory"
)
EQUITY_USD = Gauge(
    "mm_equity_usd", "Total equity (bankroll + inventory mark-to-mid)"
)
DAILY_PNL_USD = Gauge("mm_daily_pnl_usd", "Realized P&L today (USD)")
ACTIVE_QUOTES = Gauge("mm_active_quotes", "Number of active quotes placed")
HALTED = Gauge("mm_halted", "1 if trading is halted, 0 otherwise")

# ── Cycle / fill counters ────────────────────────────────────────────────
CYCLES_TOTAL = Counter("mm_cycles_total", "Total requote cycles executed")
FILLS_TOTAL = Counter(
    "mm_fills_total", "Total fills", labelnames=("side", "mode")
)
ROUND_TRIPS_TOTAL = Counter(
    "mm_round_trips_total", "Completed buy+sell round-trips"
)

# ── Risk events ──────────────────────────────────────────────────────────
ADVERSE_TRIGGERS = Counter(
    "mm_adverse_triggers_total", "Adverse selection triggers"
)
CIRCUIT_BREAKER_TRIPS = Counter(
    "mm_circuit_breaker_trips_total",
    "Circuit breaker trips",
    labelnames=("reason",),
)
HALT_REASONS = Counter(
    "mm_halt_reasons_total", "Trading halt reasons", labelnames=("reason",)
)

# ── Strategy metrics ─────────────────────────────────────────────────────
SPREAD_CENTS = Gauge(
    "mm_spread_cents", "Current spread in cents", labelnames=("token_id",)
)
RESERVATION_PRICE = Gauge(
    "mm_reservation_price",
    "Avellaneda-Stoikov reservation price",
    labelnames=("token_id",),
)
KYLE_LAMBDA = Gauge(
    "mm_kyle_lambda", "Kyle's lambda estimate", labelnames=("token_id",)
)
INVENTORY_RATIO = Gauge(
    "mm_inventory_ratio",
    "Inventory ratio (-1..+1)",
    labelnames=("token_id",),
)

# ── Latency ──────────────────────────────────────────────────────────────
CYCLE_LATENCY_SEC = Histogram(
    "mm_cycle_latency_seconds",
    "Time spent in one requote cycle",
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5),
)
ORDER_PLACE_LATENCY_SEC = Histogram(
    "mm_order_place_latency_seconds",
    "Latency of place_order API call (LIVE)",
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0),
)
WS_MSG_AGE_SEC = Gauge("mm_ws_msg_age_sec", "Seconds since last WS message")

# ── API / HTTP ───────────────────────────────────────────────────────────
API_REQUESTS = Counter(
    "mm_api_requests_total",
    "Admin API requests",
    labelnames=("method", "endpoint", "status"),
)
