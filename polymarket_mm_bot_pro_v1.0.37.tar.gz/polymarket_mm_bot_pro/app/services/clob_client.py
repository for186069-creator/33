"""
app/services/clob_client.py — Polymarket CLOB client wrapper.

CRITICAL: This module uses the OFFICIAL `py-clob-client` library which
provides REAL EIP-712 order signing via `py-order-utils`. The previous
bot version (v10.13) had a stub `_sign_order` that returned `signature: ""`
— every LIVE order was rejected. This wrapper fixes that.

Layers:
  1. `ClobClient` (official) — order placement, cancel, balance, market data
  2. `MarketDataFeed` (custom) — WebSocket for real-time book updates
  3. `ClobService` — unified facade used by the market maker

PAPER mode: ClobService short-circuits order placement to simulate fills.
LIVE mode: real orders via py-clob-client, real signing.
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import aiohttp
import websockets
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ORDER_PLACE_LATENCY_SEC,
    WS_MSG_AGE_SEC,
)

log = get_logger(__name__)

# ─── Local imports of official client (deferred until first LIVE use) ────
_PY_CLOB_AVAILABLE: bool | None = None


def _ensure_py_clob() -> None:
    """Check that py-clob-client is importable. Raise informative error if not."""
    global _PY_CLOB_AVAILABLE
    if _PY_CLOB_AVAILABLE is True:
        return
    try:
        from py_clob_client.client import ClobClient as _PC  # noqa: F401
        from py_clob_client.clob_types import (  # noqa: F401
            ApiCreds,
            BalanceAllowanceParams,
            OpenOrderParams,
            OrderArgs,
            OrderType,
        )
        from py_clob_client.constants import POLYGON  # noqa: F401
        from py_clob_client.http_helpers.helpers import PolyApiException  # noqa: F401
    except ImportError as e:
        _PY_CLOB_AVAILABLE = False
        raise RuntimeError(
            "py-clob-client is not installed. Run: pip install -r requirements.txt"
        ) from e
    _PY_CLOB_AVAILABLE = True


# ═══════════════════════════════════════════════════════════════════════
# Data classes (used by both PAPER and LIVE)
# ═══════════════════════════════════════════════════════════════════════


@dataclass
class OrderLevel:
    """A single price level in the order book."""

    price: float
    size: float  # in tokens (shares)


@dataclass
class MarketBook:
    """Current order book for a token. Thread-safe via GIL (asyncio single-thread)."""

    token_id: str
    bids: list[OrderLevel] = field(default_factory=list)
    asks: list[OrderLevel] = field(default_factory=list)
    last_price: float = 0.5
    last_update: float = field(default_factory=time.monotonic)
    tick_size: float = 0.01  # minimum price increment
    neg_risk: bool = False
    min_order_size: float = 5.0

    @property
    def best_bid(self) -> float:
        return max((lvl.price for lvl in self.bids), default=0.0)

    @property
    def best_ask(self) -> float:
        return min((lvl.price for lvl in self.asks), default=1.0)

    @property
    def mid(self) -> float:
        if self.best_bid > 0 and self.best_ask < 1:
            return (self.best_bid + self.best_ask) / 2
        return self.last_price

    @property
    def spread(self) -> float:
        return self.best_ask - self.best_bid

    def depth_bid(self, levels: int) -> float:
        """Total USD depth on bid side, top N levels."""
        return sum(lvl.price * lvl.size for lvl in self.bids[:levels])

    def depth_ask(self, levels: int) -> float:
        return sum(lvl.price * lvl.size for lvl in self.asks[:levels])


@dataclass
class MarketInfo:
    """Static info about a market."""

    token_id: str
    condition_id: str
    question: str
    outcome: str  # "Yes" or "No"
    end_date_ts: float
    volume_24h: float
    tick_size: float = 0.01
    neg_risk: bool = False


@dataclass
class OrderResult:
    """Result of order placement — unified PAPER/LIVE shape."""

    success: bool
    order_id: str = ""
    error: str = ""
    raw: dict[str, Any] | None = None


# ═══════════════════════════════════════════════════════════════════════
# WebSocket market data feed
# ═══════════════════════════════════════════════════════════════════════


class MarketDataFeed:
    """Real-time order book updates via Polymarket WS.

    WS endpoint: wss://ws-subscriptions-clob.polymarket.com/ws/market
    Subscribe with: {"auth": {}, "type": "Market", "assets_ids": [...]}
    Event types: "book", "price_change", "trade"
    """

    def __init__(self, books: dict[str, MarketBook]) -> None:
        self.books = books
        self._running = False
        self._task: asyncio.Task | None = None
        self._subscribed: set[str] = set()
        self.last_msg_time: float = time.monotonic()

    async def start(self, token_ids: list[str]) -> None:
        self._subscribed.update(token_ids)
        if self._task is None or self._task.done():
            self._running = True
            self._task = asyncio.create_task(self._ws_loop(), name="market_ws")

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def subscribe(self, token_id: str) -> None:
        """Add a new token to the WS subscription. Reconnects with new list."""
        self._subscribed.add(token_id)
        # Reconnect picks up the new subscribed set on next iteration
        await self.stop()
        await self.start(list(self._subscribed))

    async def unsubscribe(self, token_id: str) -> None:
        self._subscribed.discard(token_id)

    async def _ws_loop(self) -> None:
        """Connect with exponential backoff. On disconnect, REST fallback kicks in."""
        backoff = 3
        while self._running:
            try:
                await self._ws_connect()
                backoff = 3  # reset on clean disconnect
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("ws_disconnect", error=str(e), retry_in=backoff)
                await asyncio.sleep(backoff)
                backoff = min(30, backoff * 2)

    async def _ws_connect(self) -> None:
        async with websockets.connect(
            settings.ws_url,
            ping_interval=15,
            ping_timeout=10,
            close_timeout=3,
            max_size=2**22,  # 4MB — large snapshots
        ) as ws:
            sub_msg = {
                "auth": {},
                "type": "Market",
                "assets_ids": list(self._subscribed),
            }
            await ws.send(json.dumps(sub_msg))
            log.info("ws_connected", markets=len(self._subscribed))
            self.last_msg_time = time.monotonic()

            async for raw in ws:
                try:
                    msgs = json.loads(raw)
                    if isinstance(msgs, dict):
                        msgs = [msgs]
                    for msg in msgs:
                        self._process_event(msg)
                except Exception as e:
                    log.debug("ws_parse_error", error=str(e))
                self.last_msg_time = time.monotonic()
                WS_MSG_AGE_SEC.set(0.0)

    def _process_event(self, event: dict) -> None:
        etype = event.get("event_type", "")
        asset_id = event.get("asset_id", "")
        book = self.books.get(asset_id)
        if not book:
            return

        if etype == "price_change":
            price = float(event.get("price", 0))
            side = event.get("side", "")
            size = float(event.get("size", 0))
            if price <= 0 or size <= 0:
                return
            level = OrderLevel(price=price, size=size)
            if side == "BUY":
                book.bids = [level] + [l for l in book.bids if abs(l.price - price) > 1e-9]
                book.bids = sorted(book.bids, key=lambda x: x.price, reverse=True)[:20]
            elif side == "SELL":
                book.asks = [level] + [l for l in book.asks if abs(l.price - price) > 1e-9]
                book.asks = sorted(book.asks, key=lambda x: x.price)[:20]
            if book.bids and book.asks:
                book.last_price = (book.best_bid + book.best_ask) / 2
            book.last_update = time.monotonic()

        elif etype == "book":
            self._apply_snapshot(book, event)
            book.last_update = time.monotonic()

        elif etype == "trade":
            price = float(event.get("price", book.last_price))
            if 0 < price < 1:
                book.last_price = price

    @staticmethod
    def _apply_snapshot(book: MarketBook, event: dict) -> None:
        def parse(raw: list) -> list[OrderLevel]:
            out: list[OrderLevel] = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(event.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(event.get("asks", [])), key=lambda x: x.price)
        if bids:
            book.bids = bids
        if asks:
            book.asks = asks
        if bids and asks:
            book.last_price = (bids[0].price + asks[0].price) / 2


# ═══════════════════════════════════════════════════════════════════════
# Main service facade
# ═══════════════════════════════════════════════════════════════════════


class ClobService:
    """Unified facade for PAPER + LIVE modes.

    PAPER: order placement returns simulated immediate fill.
    LIVE:  real orders via py-clob-client with proper EIP-712 signing.
    """

    def __init__(self) -> None:
        self.books: dict[str, MarketBook] = {}
        self.markets: dict[str, MarketInfo] = {}
        self._feed = MarketDataFeed(self.books)
        self._poll_task: asyncio.Task | None = None
        self._running = False
        self._client: Any = None  # py_clob_client.client.ClobClient (LIVE only)
        self._creds: Any = None  # ApiCreds

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self, token_ids: list[str]) -> None:
        self._running = True
        for tid in token_ids:
            self._feed._subscribed.add(tid)
            self.books.setdefault(tid, MarketBook(token_id=tid))

        # Fetch static info first
        await self._fetch_market_info(token_ids)
        # Initial REST snapshot of all books
        await self._refresh_all_books()
        # Start WS for real-time updates
        await self._feed.start(token_ids)
        # Start REST polling as fallback / heartbeat
        self._poll_task = asyncio.create_task(self._poll_loop(), name="clob_poll")

        # Initialize LIVE client if needed
        if not settings.paper_trading:
            await self._init_live_client()

        log.info(
            "clob_started",
            mode="PAPER" if settings.paper_trading else "LIVE",
            markets=len(token_ids),
        )

    async def stop(self) -> None:
        self._running = False
        await self._feed.stop()
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        log.info("clob_stopped")

    async def _init_live_client(self) -> None:
        """Initialize official py-clob-client with real signing."""
        _ensure_py_clob()
        from py_clob_client.client import ClobClient as _PC
        from py_clob_client.clob_types import ApiCreds

        kwargs: dict[str, Any] = {
            "host": settings.clob_base_url,
            "key": settings.polygon_private_key,
            "chain_id": settings.chain_id,
            "signature_type": settings.signature_type,
        }
        if settings.funder_address and settings.signature_type != 0:
            kwargs["funder"] = settings.funder_address

        self._client = _PC(**kwargs)

        # Use provided creds, or derive them once
        if settings.clob_api_key and settings.clob_api_secret and settings.clob_api_passphrase:
            self._creds = ApiCreds(
                api_key=settings.clob_api_key,
                api_secret=settings.clob_api_secret,
                api_passphrase=settings.clob_api_passphrase,
            )
        else:
            log.info("deriving_api_creds", wallet=settings.polygon_wallet_address)
            self._creds = self._client.create_or_derive_api_creds()
            log.info(
                "api_creds_derived",
                api_key=self._creds.api_key[:8] + "...",
                secret_set=bool(self._creds.api_secret),
                passphrase_set=bool(self._creds.api_passphrase),
            )
            log.info(
                "PERSIST THESE IN .env",
                clob_api_key=self._creds.api_key,
                clob_api_secret=self._creds.api_secret,
                clob_api_passphrase=self._creds.api_passphrase,
            )
        self._client.set_api_creds(self._creds)

    # ── Market discovery (Gamma API) ──────────────────────────────────────

    async def discover_markets(self) -> list[MarketInfo]:
        """Find liquid markets matching keyword + spread filters."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={
                        "active": "true",
                        "closed": "false",
                        "limit": "500",
                        "order": "volume24hr",
                        "ascending": "false",
                    },
                    headers={"User-Agent": "PolyMMBotPro/1.0"},
                    timeout=aiohttp.ClientTimeout(total=20),
                ) as resp:
                    if resp.status != 200:
                        raise ValueError(f"Gamma API status {resp.status}")
                    data = await resp.json()
                events = data if isinstance(data, list) else data.get("data", [])

            now_ts = datetime.now(timezone.utc).timestamp()
            keywords = settings.keywords_list
            exclude = settings.exclude_keywords_list
            min_spread_dollars = settings.auto_pick_min_spread_cents / 100.0

            candidates: list[tuple[float, MarketInfo, float, float]] = []

            for event in events:
                title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                if keywords and not any(kw in title for kw in keywords):
                    continue
                if any(ex in title for ex in exclude):
                    continue

                for m in event.get("markets") or []:
                    if not m.get("active", True) or m.get("closed", False):
                        continue
                    end_ts = self._parse_date(m.get("endDate") or m.get("endDateIso") or "")
                    if end_ts < now_ts + 3600:
                        continue

                    raw_ids = m.get("clobTokenIds", "[]")
                    try:
                        token_ids = (
                            json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        )
                    except Exception:
                        continue
                    raw_outcomes = m.get("outcomes", "[]")
                    try:
                        outcomes = (
                            json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        )
                    except Exception:
                        outcomes = []
                    if len(token_ids) != len(outcomes):
                        continue

                    vol_24h = float(
                        m.get("volume24hr")
                        or m.get("volume24hrClob")
                        or m.get("volumeNum")
                        or 0
                    )
                    if vol_24h < settings.auto_pick_min_volume_24h:
                        continue

                    best_bid = float(m.get("bestBid") or 0)
                    best_ask = float(m.get("bestAsk") or 0)
                    market_spread = (
                        best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0
                    )
                    if market_spread < min_spread_dollars:
                        continue

                    question = m.get("question", "")
                    condition_id = m.get("conditionId", "")
                    raw_prices = m.get("outcomePrices", "[]")
                    try:
                        prices = (
                            json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        )
                    except Exception:
                        prices = []
                    if len(prices) != len(token_ids):
                        continue

                    for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                        try:
                            price = float(price_str)
                        except (TypeError, ValueError):
                            continue
                        if price < 0.10 or price > 0.90:
                            continue

                        info = MarketInfo(
                            token_id=str(tid),
                            condition_id=condition_id,
                            question=question,
                            outcome=str(outcome),
                            end_date_ts=end_ts,
                            volume_24h=vol_24h,
                        )
                        uncertainty = 1.0 - abs(price - 0.5) * 2
                        spread_bonus = 1.0 + (market_spread * 50)
                        score = vol_24h * uncertainty * spread_bonus
                        candidates.append((score, info, price, market_spread))

            candidates.sort(key=lambda x: x[0], reverse=True)
            top = candidates[: settings.auto_pick_count]
            result = [info for _, info, _, _ in top]

            log.info(
                "markets_discovered",
                candidates=len(candidates),
                picked=len(result),
                min_spread_cents=settings.auto_pick_min_spread_cents,
            )
            for score, info, price, spread in top:
                log.info(
                    "market_picked",
                    question=info.question[:55],
                    outcome=info.outcome,
                    price=round(price, 3),
                    spread_cents=round(spread * 100, 1),
                    volume=round(info.volume_24h, 0),
                    score=round(score, 0),
                )

            # Fallback: relax spread threshold to 0.8¢
            if not result:
                log.warning("markets_discovery_fallback", relaxed_spread_cents=0.8)
                relaxed = 0.008
                for event in events:
                    title = (event.get("title", "") + " " + event.get("slug", "")).lower()
                    if keywords and not any(kw in title for kw in keywords):
                        continue
                    if any(ex in title for ex in exclude):
                        continue
                    for m in event.get("markets") or []:
                        if not m.get("active", True) or m.get("closed", False):
                            continue
                        end_ts = self._parse_date(m.get("endDate") or "")
                        if end_ts < now_ts + 3600:
                            continue
                        raw_ids = m.get("clobTokenIds", "[]")
                        try:
                            token_ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                        except Exception:
                            continue
                        raw_outcomes = m.get("outcomes", "[]")
                        try:
                            outcomes = json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                        except Exception:
                            outcomes = []
                        if len(token_ids) != len(outcomes):
                            continue
                        vol_24h = float(
                            m.get("volume24hr") or m.get("volume24hrClob") or m.get("volumeNum") or 0
                        )
                        if vol_24h < settings.auto_pick_min_volume_24h:
                            continue
                        best_bid = float(m.get("bestBid") or 0)
                        best_ask = float(m.get("bestAsk") or 0)
                        market_spread = best_ask - best_bid if best_bid > 0 and best_ask > 0 else 0
                        if market_spread < relaxed:
                            continue
                        question = m.get("question", "")
                        condition_id = m.get("conditionId", "")
                        raw_prices = m.get("outcomePrices", "[]")
                        try:
                            prices = json.loads(raw_prices) if isinstance(raw_prices, str) else list(raw_prices)
                        except Exception:
                            prices = []
                        if len(prices) != len(token_ids):
                            continue
                        for tid, outcome, price_str in zip(token_ids, outcomes, prices):
                            try:
                                price = float(price_str)
                            except (TypeError, ValueError):
                                continue
                            if price < 0.10 or price > 0.90:
                                continue
                            info = MarketInfo(
                                token_id=str(tid),
                                condition_id=condition_id,
                                question=question,
                                outcome=str(outcome),
                                end_date_ts=end_ts,
                                volume_24h=vol_24h,
                            )
                            uncertainty = 1.0 - abs(price - 0.5) * 2
                            spread_bonus = 1.0 + (market_spread * 50)
                            score = vol_24h * uncertainty * spread_bonus
                            candidates.append((score, info, price, market_spread))
                candidates.sort(key=lambda x: x[0], reverse=True)
                top = candidates[: settings.auto_pick_count]
                result = [info for _, info, _, _ in top]
                log.info("markets_discovery_fallback_result", picked=len(result))

            return result
        except Exception as e:
            log.error("markets_discovery_failed", error=str(e))
            return []

    async def _fetch_market_info(self, token_ids: list[str]) -> None:
        """Populate self.markets via Gamma /events batch."""
        if not token_ids:
            return
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{settings.gamma_url}/events",
                    params={"active": "true", "closed": "false", "limit": "500"},
                    headers={"User-Agent": "PolyMMBotPro/1.0"},
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status != 200:
                        return
                    events = await resp.json()
                    if isinstance(events, dict):
                        events = events.get("data", [])

                    tid_set = set(str(t) for t in token_ids)
                    for event in events:
                        for m in event.get("markets") or []:
                            raw_ids = m.get("clobTokenIds", "[]")
                            try:
                                ids = json.loads(raw_ids) if isinstance(raw_ids, str) else list(raw_ids)
                            except Exception:
                                continue
                            raw_outcomes = m.get("outcomes", "[]")
                            try:
                                outcomes = (
                                    json.loads(raw_outcomes) if isinstance(raw_outcomes, str) else list(raw_outcomes)
                                )
                            except Exception:
                                outcomes = []
                            for tid, outcome in zip(ids, outcomes):
                                if str(tid) in tid_set:
                                    end_ts = self._parse_date(
                                        m.get("endDate") or m.get("endDateIso") or ""
                                    )
                                    self.markets[str(tid)] = MarketInfo(
                                        token_id=str(tid),
                                        condition_id=m.get("conditionId", ""),
                                        question=m.get("question", ""),
                                        outcome=str(outcome),
                                        end_date_ts=end_ts,
                                        volume_24h=float(m.get("volume24hr") or 0),
                                    )
        except Exception as e:
            log.debug("market_info_fetch_failed", error=str(e))

    # ── Book polling (REST fallback) ──────────────────────────────────────

    async def _poll_loop(self) -> None:
        await asyncio.sleep(2)
        while self._running:
            try:
                await self._refresh_all_books()
            except Exception as e:
                log.debug("book_poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _refresh_all_books(self) -> None:
        tids = list(self._feed._subscribed)
        if not tids:
            return
        async with aiohttp.ClientSession() as session:
            tasks = [self._fetch_book(session, tid) for tid in tids]
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _fetch_book(self, session: aiohttp.ClientSession, tid: str) -> None:
        try:
            async with session.get(
                f"{settings.clob_base_url}/book",
                params={"token_id": tid},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self._apply_book(tid, data)
                    # Update tick size if present
                    if "tick_size" in data and data["tick_size"]:
                        try:
                            self.books[tid].tick_size = float(data["tick_size"])
                        except (TypeError, ValueError):
                            pass
                    if "neg_risk" in data:
                        self.books[tid].neg_risk = bool(data["neg_risk"])
        except Exception:
            pass

    def _apply_book(self, tid: str, data: dict) -> None:
        book = self.books.get(tid)
        if not book:
            book = MarketBook(token_id=tid)
            self.books[tid] = book

        def parse(raw: list) -> list[OrderLevel]:
            out: list[OrderLevel] = []
            for item in raw:
                try:
                    p = float(item.get("price", 0))
                    s = float(item.get("size", 0))
                    if p > 0 and s > 0:
                        out.append(OrderLevel(p, s))
                except (TypeError, ValueError):
                    pass
            return out

        bids = sorted(parse(data.get("bids", [])), key=lambda x: x.price, reverse=True)
        asks = sorted(parse(data.get("asks", [])), key=lambda x: x.price)
        if bids:
            book.bids = bids
        if asks:
            book.asks = asks
        if bids and asks:
            book.last_price = (bids[0].price + asks[0].price) / 2
        book.last_update = time.monotonic()
        self._feed.last_msg_time = time.monotonic()

    # ── Order placement ───────────────────────────────────────────────────

    @retry(
        retry=retry_if_exception_type(Exception),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
        reraise=True,
    )
    async def place_order(
        self,
        token_id: str,
        side: str,  # "BUY" or "SELL"
        price: float,
        size_usdc: float,
        order_type: str = "GTC",  # GTC | FOK | GTD | FAK
        post_only: bool = True,
    ) -> OrderResult:
        """Place an order. PAPER = simulate, LIVE = real signed order."""
        # Validate inputs
        if side not in ("BUY", "SELL"):
            return OrderResult(success=False, error=f"Invalid side: {side}")
        if not (0.0 < price < 1.0):
            return OrderResult(success=False, error=f"Price out of range: {price}")
        if size_usdc < settings.order_size_min_usdc:
            return OrderResult(
                success=False, error=f"Size below minimum: {size_usdc} < {settings.order_size_min_usdc}"
            )

        # ── PAPER MODE: simulate immediate fill ──
        if settings.paper_trading:
            return OrderResult(
                success=True,
                order_id=f"PAPER-{int(time.time() * 1000)}-{side[0]}",
                raw={
                    "status": "MATCHED",
                    "orderID": f"PAPER-{int(time.time() * 1000)}-{side[0]}",
                    "price": str(price),
                    "size": str(size_usdc / max(price, 0.01)),
                    "side": side,
                },
            )

        # ── LIVE MODE: real order via py-clob-client ──
        if not self._client:
            await self._init_live_client()

        from py_clob_client.clob_types import OrderArgs, OrderType
        from py_clob_client.http_helpers.helpers import PolyApiException

        # Snap price to tick size to avoid rejection
        book = self.books.get(token_id)
        tick = book.tick_size if book else 0.01
        snapped_price = round(round(price / tick) * tick, 6)
        if not (tick <= snapped_price <= 1 - tick):
            return OrderResult(
                success=False,
                error=f"Snapped price {snapped_price} outside [{tick}, {1 - tick}]",
            )

        # Convert USD size → token shares
        size_tokens = size_usdc / max(snapped_price, 0.01)
        if book and size_tokens < book.min_order_size:
            size_tokens = book.min_order_size
            size_usdc = size_tokens * snapped_price

        order_args = OrderArgs(
            token_id=token_id,
            price=snapped_price,
            size=size_tokens,
            side=side,
        )

        ot = OrderType.GTC
        if order_type == "FOK":
            ot = OrderType.FOK
        elif order_type == "GTD":
            ot = OrderType.GTD
        elif order_type == "FAK":
            ot = OrderType.FAK

        t0 = time.monotonic()
        try:
            signed = self._client.create_order(order_args)
            resp = self._client.post_order(signed, orderType=ot, post_only=post_only)
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)

            order_id = ""
            success = False
            if isinstance(resp, dict):
                order_id = resp.get("orderID") or resp.get("id", "")
                status = (resp.get("status") or "").upper()
                # Success statuses: LIVE (sitting on book), MATCHED, FILLED
                success = status in ("LIVE", "MATCHED", "FILLED", "FILLED_PARTIAL") or bool(order_id)

            log.info(
                "order_placed_live",
                token_id=token_id[:12],
                side=side,
                price=snapped_price,
                size_usdc=round(size_usdc, 2),
                size_tokens=round(size_tokens, 2),
                order_id=order_id,
                status=resp.get("status") if isinstance(resp, dict) else "?",
                latency_ms=round(elapsed * 1000, 1),
            )
            return OrderResult(success=success, order_id=order_id, raw=resp)

        except PolyApiException as e:
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)
            log.error(
                "order_rejected",
                token_id=token_id[:12],
                side=side,
                price=snapped_price,
                status=getattr(e, "status_code", "?"),
                error=str(getattr(e, "error_msg", e)),
                latency_ms=round(elapsed * 1000, 1),
            )
            return OrderResult(
                success=False,
                error=f"PolyApiException {getattr(e, 'status_code', '?')}: {getattr(e, 'error_msg', e)}",
            )
        except Exception as e:
            elapsed = time.monotonic() - t0
            ORDER_PLACE_LATENCY_SEC.observe(elapsed)
            log.exception("order_place_failed", error=str(e))
            return OrderResult(success=False, error=str(e))

    async def cancel_order(self, order_id: str) -> bool:
        """Cancel by order ID. PAPER = no-op, LIVE = real cancel."""
        if settings.paper_trading or order_id.startswith("PAPER-"):
            return True
        if not self._client:
            return False
        from py_clob_client.http_helpers.helpers import PolyApiException

        try:
            resp = self._client.cancel(order_id)
            log.info("order_canceled", order_id=order_id, resp=resp)
            return True
        except PolyApiException as e:
            log.warning("cancel_failed", order_id=order_id, error=str(getattr(e, "error_msg", e)))
            return False
        except Exception as e:
            log.warning("cancel_exception", order_id=order_id, error=str(e))
            return False

    async def cancel_all(self) -> int:
        """Cancel ALL open orders. Returns count canceled. LIVE only."""
        if settings.paper_trading or not self._client:
            return 0
        try:
            self._client.cancel_all()
            log.info("cancel_all_done")
            return -1  # API doesn't return count
        except Exception as e:
            log.warning("cancel_all_failed", error=str(e))
            return 0

    async def get_open_orders(self) -> list[dict]:
        """List all open orders. LIVE only; PAPER returns empty list."""
        if settings.paper_trading or not self._client:
            return []
        try:
            from py_clob_client.clob_types import OpenOrderParams

            return list(self._client.get_orders(OpenOrderParams()))
        except Exception as e:
            log.warning("get_open_orders_failed", error=str(e))
            return []

    async def get_balance_allowance(self) -> dict[str, Any]:
        """Check USDC balance + allowance on Polygon. LIVE only."""
        if settings.paper_trading or not self._client:
            return {"balance": "0", "allowance": "0"}
        try:
            from py_clob_client.clob_types import AssetType, BalanceAllowanceParams

            params = BalanceAllowanceParams(asset_type=AssetType.COLLATERAL)
            return self._client.get_balance_allowance(params)
        except Exception as e:
            log.warning("balance_check_failed", error=str(e))
            return {"balance": "0", "allowance": "0"}

    # ── Helpers ───────────────────────────────────────────────────────────

    @property
    def last_ws_msg_age(self) -> float:
        return time.monotonic() - self._feed.last_msg_time

    @staticmethod
    def _parse_date(date_str: str) -> float:
        """Parse ISO date string → unix timestamp (UTC). Returns 0 on failure."""
        if not date_str:
            return 0.0
        try:
            # Try ISO format with Z (most common from Polymarket)
            return datetime.fromisoformat(date_str.replace("Z", "+00:00")).timestamp()
        except (ValueError, TypeError):
            pass
        # Fallback to common formats
        for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"):
            try:
                return datetime.strptime(date_str[:26], fmt).replace(
                    tzinfo=timezone.utc
                ).timestamp()
            except ValueError:
                continue
        return 0.0
