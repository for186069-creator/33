"""
app/services/risk/circuit_breakers.py — Trading halt conditions.

Each circuit breaker is a CHECK function that returns (should_halt, reason).
The RiskManager aggregates them and decides whether to halt trading.

Circuit breakers (in order of severity):
  1. EMERGENCY_STOP     — manual kill switch
  2. MIN_BALANCE        — bankroll < $min_balance_usd (LIVE only)
  3. DAILY_LOSS         — daily_pnl ≤ -max_daily_loss_usd
  4. CONSECUTIVE_LOSSES — N consecutive losing fills
  5. STALE_DATA         — WS silent > stale_data_threshold_sec
  6. MAJOR_MOVE         — mid moved > cancel_on_major_move_cents in short window
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from app.core.config import settings
from app.core.logging import get_logger

if TYPE_CHECKING:
    from app.services.clob_client import ClobService
    from app.services.inventory_manager import InventoryManager

log = get_logger(__name__)


@dataclass
class MajorMoveState:
    """Per-token major-move tracking."""

    price_history: deque = field(default_factory=lambda: deque(maxlen=60))


class CircuitBreakers:
    """All circuit-breaker checks. Pure functions — no side effects."""

    def __init__(self) -> None:
        self._major_move_states: dict[str, MajorMoveState] = {}
        self._emergency_stop_triggered: bool = False

    def emergency_stop(self) -> None:
        """Manually trigger the kill switch. Sticky until reset."""
        self._emergency_stop_triggered = True
        log.critical("emergency_stop_triggered")

    def reset_emergency_stop(self) -> None:
        self._emergency_stop_triggered = False

    # ── Individual checks ─────────────────────────────────────────────────

    def check_emergency(self) -> tuple[bool, str]:
        if self._emergency_stop_triggered:
            return True, "EMERGENCY_STOP:manual kill switch"
        return False, ""

    def check_min_balance(self, inventory: InventoryManager) -> tuple[bool, str]:
        if settings.paper_trading:
            return False, ""
        if inventory.bankroll < settings.min_balance_usd:
            return True, f"MIN_BALANCE: ${inventory.bankroll:.2f} < ${settings.min_balance_usd}"
        return False, ""

    def check_daily_loss(self, inventory: InventoryManager) -> tuple[bool, str]:
        if inventory.daily_pnl <= -settings.max_daily_loss_usd:
            return (
                True,
                f"DAILY_LOSS: ${inventory.daily_pnl:.2f} ≤ -${settings.max_daily_loss_usd}",
            )
        return False, ""

    def check_consecutive_losses(self, inventory: InventoryManager) -> tuple[bool, str]:
        if inventory.consecutive_losses >= settings.stop_trading_consecutive_losses:
            return (
                True,
                f"CONSECUTIVE_LOSSES: {inventory.consecutive_losses} ≥ {settings.stop_trading_consecutive_losses}",
            )
        return False, ""

    def check_stale_data(self, clob: ClobService) -> tuple[bool, str]:
        age = clob.last_ws_msg_age
        if age > settings.stale_data_threshold_sec:
            return True, f"STALE_DATA: WS silent {age:.0f}s"
        return False, ""

    def check_major_move(self, token_id: str, current_mid: float) -> tuple[bool, str]:
        """Detect sharp price moves (>cancel_on_major_move_cents in 60s)."""
        state = self._major_move_states.setdefault(token_id, MajorMoveState())
        state.price_history.append((time.monotonic(), current_mid))

        if len(state.price_history) < 5:
            return False, ""

        now = time.monotonic()
        window = 60  # 60-second window
        threshold = settings.cancel_on_major_move_cents / 100.0

        oldest_in_window = None
        for ts, mid in state.price_history:
            if now - ts <= window:
                oldest_in_window = (ts, mid)
                break
        if oldest_in_window is None:
            return False, ""

        _, old_mid = oldest_in_window
        move = abs(current_mid - old_mid)
        if move >= threshold:
            # Clear history to prevent re-trigger
            state.price_history.clear()
            return True, f"MAJOR_MOVE: {token_id[:12]} moved {move * 100:.1f}¢ in {window}s"
        return False, ""

    # ── Aggregate check ───────────────────────────────────────────────────

    def check_all(
        self,
        inventory: InventoryManager,
        clob: ClobService,
    ) -> tuple[bool, str]:
        """Run all circuit breakers. Returns (should_halt, reason).

        First trip wins. Order matters: emergency > min_balance > stale_data
        > daily_loss > consecutive_losses.
        """
        for check in (
            self.check_emergency,
            lambda: self.check_min_balance(inventory),
            lambda: self.check_stale_data(clob),
            lambda: self.check_daily_loss(inventory),
            lambda: self.check_consecutive_losses(inventory),
        ):
            should_halt, reason = check()
            if should_halt:
                return True, reason
        return False, ""

    def clear_token(self, token_id: str) -> None:
        self._major_move_states.pop(token_id, None)
