"""
app/services/pricing/avellaneda_stoikov.py — Avellaneda-Stoikov MM model.

Reference: Avellaneda & Stoikov (2008), "High-frequency trading in a limit
order book".

The model defines a RESERVATION PRICE r(s, q, t) — the fair price adjusted
for inventory — and an OPTIMAL SPREAD around it:

    r(s, t) = s - q * gamma * sigma^2 * (T - t)
    spread  = gamma * sigma^2 * (T - t) + (2/gamma) * ln(1 + gamma/k)

Where:
    s       = mid price (reference)
    q       = inventory (in tokens, + long / - short)
    gamma   = inventory risk aversion (0..1+)
    sigma   = volatility (decimal, e.g. 0.02 = 2%)
    T - t   = time to horizon (we use a rolling window, not a fixed T)
    k       = arrival intensity (we approximate via Kyle's lambda)

In our adaptation:
  - We use a perpetual horizon (T-t = 1.0 normalized) since prediction
    markets don't have a trading-day boundary the same way equities do.
  - sigma is estimated from recent mid-price history.
  - Reservation price shifts OPPOSITE to inventory: long → r < s (encourage
    selling), short → r > s (encourage buying).

This is a TOOL — not a guarantee of profit. The model assumes Brownian
motion, which prediction markets violate (especially near sports game
ends / election nights). We cap and floor all outputs.
"""
from __future__ import annotations

import math
import time
from collections import deque
from dataclasses import dataclass

from app.core.config import settings
from app.core.logging import get_logger

log = get_logger(__name__)


@dataclass
class ASState:
    """Per-token A-S state."""

    price_history: deque  # of (timestamp, mid) tuples
    last_sigma: float
    last_reservation: float


class AvellanedaStoikov:
    """Per-token A-S calculator.

    Usage:
        as_calc = AvellanedaStoikov()
        as_calc.update(token_id, mid_price)
        r, sigma = as_calc.compute(token_id, current_mid, inventory_tokens)
    """

    def __init__(self) -> None:
        self._states: dict[str, ASState] = {}

    def update(self, token_id: str, mid: float, ts: float | None = None) -> None:
        """Record a mid-price observation."""
        if ts is None:
            ts = time.monotonic()
        state = self._states.get(token_id)
        if state is None:
            window = settings.as_volatility_window_sec
            # ~1 sample/sec for the window duration
            max_samples = max(60, window * 2)
            state = ASState(
                price_history=deque(maxlen=max_samples),
                last_sigma=settings.as_min_volatility,
                last_reservation=mid,
            )
            self._states[token_id] = state
        state.price_history.append((ts, mid))

    def compute(
        self,
        token_id: str,
        current_mid: float,
        inventory_tokens: float,
        max_inventory_tokens: float = 100.0,
    ) -> tuple[float, float, float]:
        """Compute (reservation_price, sigma, inventory_penalty).

        Returns:
            reservation_price : float — A-S reservation price (clamped [0.01, 0.99])
            sigma             : float — estimated volatility (decimal, e.g. 0.02)
            inventory_penalty : float — q * gamma * sigma^2 (the shift from mid)
        """
        state = self._states.get(token_id)
        if state is None:
            return current_mid, settings.as_min_volatility, 0.0

        sigma = self._estimate_sigma(state)
        state.last_sigma = sigma

        # Normalized inventory: q ∈ [-1, +1]
        if max_inventory_tokens <= 0:
            q = 0.0
        else:
            q = max(-1.0, min(1.0, inventory_tokens / max_inventory_tokens))

        # Inventory penalty: gamma * sigma^2 * q
        # Note: in A-S original, this is per-unit-time. We use a normalized
        # horizon of 1.0 since prediction markets trade continuously.
        gamma = settings.as_gamma
        inventory_penalty = gamma * sigma * sigma * q

        # Reservation price: s - q * gamma * sigma^2
        # Long (q>0) → r < s (encourage selling). Short (q<0) → r > s.
        reservation = current_mid - inventory_penalty

        # Clamp to valid price range
        reservation = max(0.01, min(0.99, reservation))
        state.last_reservation = reservation

        return reservation, sigma, inventory_penalty

    def _estimate_sigma(self, state: ASState) -> float:
        """Estimate volatility (stdev of log returns) from price history."""
        history = list(state.price_history)
        if len(history) < 5:
            return settings.as_min_volatility

        # Compute log returns
        prices = [p for _, p in history]
        log_returns: list[float] = []
        for i in range(1, len(prices)):
            if prices[i - 1] > 0 and prices[i] > 0:
                log_returns.append(math.log(prices[i] / prices[i - 1]))

        if len(log_returns) < 4:
            return settings.as_min_volatility

        n = len(log_returns)
        mean = sum(log_returns) / n
        variance = sum((r - mean) ** 2 for r in log_returns) / max(n - 1, 1)
        sigma = math.sqrt(variance)

        # Floor to avoid divide-by-zero downstream
        return max(settings.as_min_volatility, sigma)

    def get_state(self, token_id: str) -> ASState | None:
        return self._states.get(token_id)

    def clear(self, token_id: str) -> None:
        self._states.pop(token_id, None)
