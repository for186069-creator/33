"""
app/services/market_maker.py — Professional MM engine.

Combines:
  - Avellaneda-Stoikov reservation price (inventory-aware fair price)
  - Kyle's lambda spread multiplier (order-book imbalance aware)
  - Multi-level quoting (3 price levels)
  - Inventory skew + aging discount
  - Circuit breakers + adverse selection
  - Yes/No hedging (condition_id pairs)

Two modes:
  PAPER : realistic fill simulation (with adverse selection, competition, latency)
  LIVE  : real orders via py-clob-client with EIP-712 signing

Bot starts PAUSED. User must click "Start Trading" via /api/start.
"""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.logging import get_logger
from app.core.metrics import (
    ACTIVE_QUOTES,
    ADVERSE_TRIGGERS,
    BANKROLL_USD,
    CYCLE_LATENCY_SEC,
    CYCLES_TOTAL,
    DAILY_PNL_USD,
    FILLS_TOTAL,
    HALTED,
    INVENTORY_RATIO,
    INVENTORY_USD,
    KYLE_LAMBDA,
    RESERVATION_PRICE,
    ROUND_TRIPS_TOTAL,
    SPREAD_CENTS,
)
from app.db.models import OrderMode, QuoteStatus, Side, Trade
from app.services.clob_client import ClobService, MarketBook, OrderResult
from app.services.inventory_manager import InventoryManager
from app.services.pricing.avellaneda_stoikov import AvellanedaStoikov
from app.services.pricing.kyle_lambda import KyleLambda
from app.services.pricing.spread_optimizer import SpreadOptimizer
from app.services.risk.risk_manager import RiskManager

log = get_logger(__name__)


@dataclass
class ActiveQuote:
    """Tracks one level of an actively-placed quote for a market."""

    token_id: str
    level: int  # 1, 2, or 3
    bid_price: float | None
    ask_price: float | None
    mid_at_place: float
    size_usdc: float
    reservation_price: float
    spread_cents: float
    placed_at: float = field(default_factory=time.monotonic)
    bid_filled: bool = False
    ask_filled: bool = False
    bid_order_id: str | None = None
    ask_order_id: str | None = None


class MarketMaker:
    """Main MM engine. Runs a requote loop."""

    def __init__(
        self,
        clob: ClobService,
        inventory: InventoryManager,
        risk: RiskManager,
    ) -> None:
        self.clob = clob
        self.inventory = inventory
        self.risk = risk

        # active_quotes: token_id → list of ActiveQuote (one per level)
        self.active_quotes: dict[str, list[ActiveQuote]] = {}
        self._task: asyncio.Task | None = None
        self._cleanup_task: asyncio.Task | None = None
        self._poll_task: asyncio.Task | None = None
        self._running = False
        self._cycle_count = 0
        self._fill_count = 0  # Loaded from DB on start()
        self._round_trip_count = 0

        # Bot starts PAUSED. User clicks "Start Trading" to begin.
        self._trading_paused = True

        # Pricing models
        self._as_calc = AvellanedaStoikov()
        self._kyle = KyleLambda()

        # Yes/No hedging pairs: condition_id → {"yes": token_id, "no": token_id}
        self._condition_pairs: dict[str, dict[str, str]] = {}

        # Live mode: pending orders awaiting fill confirmation
        self._pending_orders: dict[str, dict[str, Any]] = {}

        # Stats
        self._hedge_attempts = 0
        self._hedge_fills = 0

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        # Load fill_count from DB (survives bot restarts)
        try:
            from app.core.db import AsyncSessionLocal
            from sqlalchemy import select, func
            from app.db.models import Trade
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count(Trade.id)))
                self._fill_count = result.scalar() or 0
                log.info("fill_count_loaded_from_db", fill_count=self._fill_count)
        except Exception as e:
            log.debug("fill_count_load_failed", error=str(e))

        self._task = asyncio.create_task(self._requote_loop(), name="mm_loop")
        self._cleanup_task = asyncio.create_task(self._db_cleanup_loop(), name="db_cleanup")
        if not settings.paper_trading:
            self._poll_task = asyncio.create_task(self._poll_orders_loop(), name="mm_poll")
        log.info(
            "market_maker_started",
            mode="LIVE" if not settings.paper_trading else "PAPER",
            interval=settings.requote_interval_sec,
            fill_count=self._fill_count,
        )

    async def stop(self) -> None:
        log.info("market_maker_stopping")
        self._running = False
        # Cancel all active quotes
        for tid in list(self.active_quotes.keys()):
            await self._cancel_all_levels(tid)
        for task in (self._task, self._cleanup_task, self._poll_task):
            if task:
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        log.info("market_maker_stopped")

    # ── User control ──────────────────────────────────────────────────────

    def start_trading(self) -> None:
        """User clicked 'Start Trading'."""
        self._trading_paused = False
        if self.inventory.halted and "USER_PAUSE" in (self.inventory.halt_reason or ""):
            self.inventory.resume()
        log.info("trading_started_by_user")

    def stop_trading(self) -> None:
        """User clicked 'Pause' — cancel all quotes immediately."""
        self._trading_paused = True
        for tid in list(self.active_quotes.keys()):
            asyncio.create_task(self._cancel_all_levels(tid))
        log.info("trading_paused_by_user")

    @property
    def is_trading(self) -> bool:
        return not self._trading_paused and not self.inventory.halted

    # ── Main loop ─────────────────────────────────────────────────────────

    async def _requote_loop(self) -> None:
        while self._running:
            try:
                t0 = time.monotonic()
                if self._trading_paused:
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                if self.inventory.halted:
                    # Check if halt was due to stale data — auto-resume when WS recovers
                    if "STALE_DATA" in (self.inventory.halt_reason or ""):
                        if self.clob.last_ws_msg_age < 10:
                            self.inventory.resume(preserve_counters=True)
                            log.info("ws_recovered_resuming")
                            continue
                    # Cancel all quotes while halted
                    for tid in list(self.active_quotes.keys()):
                        await self._cancel_all_levels(tid)
                    await asyncio.sleep(settings.requote_interval_sec)
                    continue
                await self._cycle()
                CYCLE_LATENCY_SEC.observe(time.monotonic() - t0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("mm_cycle_error", error=str(e))
            await asyncio.sleep(settings.requote_interval_sec)

    async def _cycle(self) -> None:
        self._cycle_count += 1
        CYCLES_TOTAL.inc()

        # ── Global halt check ──
        should_halt, reason = self.risk.should_halt()
        if should_halt:
            self.inventory.halt(
                reason=reason.split(":")[0],
                detail=reason.split(":", 1)[1] if ":" in reason else "",
            )
            for tid in list(self.active_quotes.keys()):
                await self._cancel_all_levels(tid)
            HALTED.set(1)
            return

        # Auto-refill markets if too few
        await self._maybe_auto_refill()

        # ── Build hedging pairs every 30 cycles ──
        if self._cycle_count % 30 == 1 and settings.hedging_enabled:
            self._build_hedging_pairs()

        # ── Process each market ──
        for tid, book in list(self.clob.books.items()):
            await self._process_market(tid, book)

        # ── Update metrics ──
        BANKROLL_USD.set(self.inventory.bankroll)
        DAILY_PNL_USD.set(self.inventory.daily_pnl)
        total_inv = sum(inv.net_usdc_at_entry for inv in self.inventory.inventories.values())
        INVENTORY_USD.set(total_inv)
        ACTIVE_QUOTES.set(sum(len(qs) for qs in self.active_quotes.values()))
        HALTED.set(1 if self.inventory.halted else 0)

    async def _maybe_auto_refill(self) -> None:
        """If quotable markets dropped below USER'S target, discover new ones.

        FIX: previously hardcoded minimum of 3 quotable markets, which
        overrode the user's auto_pick_count setting. If user set count=1,
        bot would still add markets until 3 were quotable. Now respects
        auto_pick_count as the minimum threshold.
        """
        # Count QUOTABLE markets (spread >= min, both sides present)
        quotable = sum(
            1 for book in self.clob.books.values()
            if book.bids and book.asks and book.spread * 100 >= settings.spread_min_cents
        )
        current = len(self.clob.books)
        # Dynamic target: adjust based on current bankroll
        if settings.auto_pick_dynamic:
            target = max(1, int(self.inventory.bankroll / 10))
        else:
            target = settings.auto_pick_count

        # Refill only if quotable < target
        if quotable >= target:
            return
        if self._cycle_count % 30 != 0:
            return

        log.info(
            "auto_refill_started",
            total_markets=current,
            quotable_markets=quotable,
            target=target,
            bankroll=round(self.inventory.bankroll, 2),
            dynamic=settings.auto_pick_dynamic,
            reason=f"fewer than {target} quotable markets (bankroll-based)",
        )
        try:
            old_count = settings.auto_pick_count
            settings.auto_pick_count = max(1, target - current)
            new_markets = await self.clob.discover_markets()
            settings.auto_pick_count = old_count
            added = 0
            for info in new_markets:
                if info.token_id not in self.clob.books:
                    self.clob.books[info.token_id] = MarketBook(token_id=info.token_id)
                    self.clob.markets[info.token_id] = info
                    await self.clob._feed.subscribe(info.token_id)
                    added += 1
            if added > 0:
                await self.clob._refresh_all_books()
                log.info("auto_refill_done", added=added, quotable_before=quotable)
        except Exception as e:
            log.debug("auto_refill_error", error=str(e))

    # ── Per-market processing ─────────────────────────────────────────────

    async def _process_market(self, token_id: str, book: MarketBook) -> None:
        """Update quotes for one market."""
        if not book.bids or not book.asks:
            log.debug("market_skip_empty_book", token=token_id[:12])
            return

        info = self.clob.markets.get(token_id)
        market_name = info.question[:60] if info else token_id[:12]

        # ── Market spread (visible in logs) ──
        market_bid = book.best_bid
        market_ask = book.best_ask
        market_spread_cents = round(book.spread * 100, 2)

        # ── TTR (Time To Resolution) — hours until market ends ──
        ttr_hours = None
        if info and info.end_date_ts > 0:
            now_ts = datetime.now(timezone.utc).timestamp()
            ttr = info.end_date_ts - now_ts
            ttr_hours = round(ttr / 3600, 1)

            # ── Pre-resolution exit ──
            if ttr < settings.pre_resolution_exit_sec:
                log.info(
                    "market_skip_pre_resolution",
                    market=market_name[:40],
                    ttr_hours=ttr_hours,
                    market_spread_cents=market_spread_cents,
                )
                await self._handle_pre_resolution(token_id, book, market_name)
                return

        # ── Market quality filter: skip if spread < spread_min_cents ──
        if market_spread_cents < settings.spread_min_cents:
            log.info(
                "market_skip_tight_spread",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                min_required=settings.spread_min_cents,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # CRITICAL: Skip very low-priced markets (< 5¢) — token count explodes
        # At $0.004, $5 order = 1250 tokens, tiny price move = huge fake P&L
        if book.mid < 0.05:
            log.info(
                "market_skip_low_price",
                market=market_name[:40],
                mid=round(book.mid, 4),
                reason="price < 5¢ causes token explosion and fake P&L",
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Update A-S pricing ──
        self._as_calc.update(token_id, book.mid)
        self.risk.on_cycle(token_id, book.mid)

        # ── Adverse selection trigger check ──
        if self.risk.adverse_selection.check_trigger(token_id):
            ADVERSE_TRIGGERS.inc()
            log.info(
                "market_skip_adverse_selection",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
            )
            await self._cancel_all_levels(token_id)
            return

        # ── Risk decision ──
        decision = self.risk.should_quote(token_id, book)
        if not decision.allow_any:
            log.info(
                "market_skip_risk",
                market=market_name[:40],
                market_spread_cents=market_spread_cents,
                reasons=decision.reasons,
            )
            if token_id in self.active_quotes:
                await self._cancel_all_levels(token_id)
            return

        # ── Compute reservation price + optimal spread ──
        inv = self.inventory.get_inventory(token_id)
        max_inv_tokens = self.inventory.max_inventory_usdc() / max(book.mid, 0.01)
        reservation, sigma, inv_penalty = self._as_calc.compute(
            token_id=token_id,
            current_mid=book.mid,
            inventory_tokens=inv.net_tokens,
            max_inventory_tokens=max_inv_tokens,
        )

        # Kyle's lambda spread multiplier
        kyle_lambda_val, kyle_mult = self._kyle.update_and_compute(token_id, book)

        # Session-based multiplier
        session_mult, session_name = SpreadOptimizer.get_session_multiplier()

        # Inventory aging discount (for stale positions)
        aging_discount = self._compute_aging_discount(inv)

        # Final spread
        optimal_spread_cents = SpreadOptimizer.compute(
            base_spread_cents=settings.spread_cents,
            sigma=sigma,
            kyle_mult=kyle_mult,
            session_mult=session_mult,
            aging_discount_cents=aging_discount,
        )

        # ── Update Prometheus gauges ──
        RESERVATION_PRICE.labels(token_id=token_id[:12]).set(reservation)
        KYLE_LAMBDA.labels(token_id=token_id[:12]).set(kyle_lambda_val)
        INVENTORY_RATIO.labels(token_id=token_id[:12]).set(
            inv.inventory_ratio(self.inventory.max_inventory_usdc())
        )
        SPREAD_CENTS.labels(token_id=token_id[:12]).set(optimal_spread_cents)

        # ── Check fills on existing quotes ──
        existing = self.active_quotes.get(token_id)
        if existing:
            await self._check_fills(token_id, book, existing, market_name)
            # Cancel stale quotes (mid drifted or too old)
            existing = self.active_quotes.get(token_id, [])
            still_active: list[ActiveQuote] = []
            for q in existing:
                age = time.monotonic() - q.placed_at
                drift = abs(book.mid - q.mid_at_place)
                if age > 10 or drift > settings.requote_threshold_cents / 100:
                    await self._cancel_quote_level(token_id, q)
                else:
                    still_active.append(q)
            if still_active:
                self.active_quotes[token_id] = still_active
            else:
                self.active_quotes.pop(token_id, None)

        # ── Place new quotes if none active ──
        if token_id not in self.active_quotes or not self.active_quotes[token_id]:
            await self._place_multi_level_quotes(
                token_id=token_id,
                book=book,
                market_name=market_name,
                reservation=reservation,
                spread_cents=optimal_spread_cents,
                decision=decision,
                sigma=sigma,
                kyle_lambda=kyle_lambda_val,
                ttr_hours=ttr_hours,
            )

    async def _handle_pre_resolution(
        self, token_id: str, book: MarketBook, market_name: str
    ) -> None:
        """Cancel quotes + liquidate inventory before market resolution."""
        if token_id in self.active_quotes:
            log.warning("pre_resolution_exit", market=market_name[:40], ttr_hours=0)
            await self._cancel_all_levels(token_id)
        inv = self.inventory.get_inventory(token_id)
        if abs(inv.net_tokens) > 0.5:
            if inv.net_tokens > 0 and book.best_bid > 0:
                await self._record_fill(
                    token_id, "SELL", book.best_bid,
                    abs(inv.net_tokens) * book.best_bid, market_name, is_liquidation=True,
                )
            elif inv.net_tokens < 0 and book.best_ask < 1:
                await self._record_fill(
                    token_id, "BUY", book.best_ask,
                    abs(inv.net_tokens) * book.best_ask, market_name, is_liquidation=True,
                )

    def _compute_aging_discount(self, inv) -> float:
        """Discount spread for stale positions to encourage liquidation."""
        if inv.net_tokens == 0 or inv.open_time == 0:
            return 0.0
        age_sec = time.monotonic() - inv.open_time
        if age_sec < settings.inventory_aging_threshold_sec:
            return 0.0
        steps_past = int((age_sec - settings.inventory_aging_threshold_sec) / 60.0)
        discount = steps_past * settings.inventory_aging_discount_step_cents
        return min(discount, settings.inventory_aging_max_discount_cents)

    # ── Multi-level quote placement ───────────────────────────────────────

    async def _place_multi_level_quotes(
        self,
        token_id: str,
        book: MarketBook,
        market_name: str,
        reservation: float,
        spread_cents: float,
        decision,
        sigma: float,
        kyle_lambda: float,
        ttr_hours: float | None = None,
    ) -> None:
        """Place up to 3 levels of bid/ask quotes around reservation price.

        FIX: Polymarket minimum order size is $5 USDC. If a level's computed
        size falls below $5, we bump it to $5 (rather than skipping) so the
        order is accepted. This means total quote size can exceed base_size
        when multi-level is enabled with small base — that's expected.
        """
        # Polymarket hard minimum (live orders below this are rejected)
        POLYMARKET_MIN_ORDER_USDC = 5.0

        # Inventory skew (shifts center)
        skew_cents = self.inventory.quote_skew(token_id)
        skew_dollars = skew_cents / 100.0

        # Auto-scale size with bankroll (capped)
        scaling = min(
            settings.order_size_autoscale_max_mult,
            self.inventory.bankroll / max(self.inventory.starting_balance, 1.0),
        )
        base_size = settings.order_size_usdc * scaling
        base_size = max(
            settings.order_size_min_usdc,
            min(base_size, settings.order_size_usdc * settings.order_size_autoscale_max_mult),
        )

        # Build levels
        levels = SpreadOptimizer.compute_levels(spread_cents)
        new_quotes: list[ActiveQuote] = []

        # Current inventory for logging
        inv = self.inventory.get_inventory(token_id)
        inventory_usdc = round(inv.net_usdc_at_entry, 2)
        inventory_tokens = round(inv.net_tokens, 4)

        for level_idx, (capture_cents, size_pct) in enumerate(levels, start=1):
            level_size = base_size * size_pct
            # FIX: enforce Polymarket $5 minimum per level
            if level_size < POLYMARKET_MIN_ORDER_USDC:
                level_size = POLYMARKET_MIN_ORDER_USDC
                log.info(
                    "level_size_bumped_to_minimum",
                    market=market_name[:30],
                    level=level_idx,
                    original_size=round(base_size * size_pct, 2),
                    bumped_to=POLYMARKET_MIN_ORDER_USDC,
                    reason="Polymarket minimum order = $5",
                )

            # ── JOIN-MARKET LOGIC (fixed v1.0.18) ───────────────────────────
            # Bot places quotes INSIDE the market spread, with FIXED gap from
            # each edge. Gap does NOT scale with optimal_spread — it's a fixed
            # distance that creates the user-requested spread pattern.
            #
            # User request: market 0.3200-0.3400 (2¢) → our 0.3215-0.3385 (1.7¢)
            # So Level 1 gap = 0.15¢ → our_spread = 2¢ - 2×0.15¢ = 1.7¢ ✅
            #
            # Levels (fixed gaps, NOT proportional to optimal spread):
            #   Level 1 (tightest): gap = 0.15¢ → our_spread = market - 0.30¢
            #   Level 2 (middle):   gap = 0.30¢ → our_spread = market - 0.60¢
            #   Level 3 (widest):   gap = 0.45¢ → our_spread = market - 0.90¢
            market_bid = book.best_bid
            market_ask = book.best_ask
            market_spread = market_ask - market_bid

            # FIXED gap per level (in dollars) — from capture_cents / 100
            # capture_cents comes from compute_levels: 0.6/1.2/1.8 for L1/L2/L3
            # when optimal=4¢. But we want FIXED 0.15/0.30/0.45 gaps.
            # So use the CAPTURE PERCENTAGE (0.15/0.30/0.45) directly as cents.
            if settings.multi_level_enabled:
                # Use fixed gaps: 0.15¢, 0.30¢, 0.45¢ for L1/L2/L3
                fixed_gaps = {1: 0.15, 2: 0.30, 3: 0.45}
                gap_cents = fixed_gaps.get(level_idx, 0.15)
            else:
                # Single level: use half the optimal spread as gap
                gap_cents = spread_cents / 2 * 0.15  # 15% of optimal as gap

            gap_dollars = gap_cents / 100.0
            # Cap gap to 40% of market spread (leave room for our spread)
            gap_dollars = min(gap_dollars, market_spread * 0.40)

            # Compute target bid/ask: join market edges, move inward by gap
            effective_mid = (market_bid + market_ask) / 2 + skew_dollars
            target_bid = effective_mid - (market_spread / 2) + gap_dollars
            target_ask = effective_mid + (market_spread / 2) - gap_dollars

            # Hard clamp: never outside market
            if target_bid <= market_bid:
                target_bid = market_bid + 0.0005  # 0.05¢ inside
            if target_ask >= market_ask:
                target_ask = market_ask - 0.0005
            if target_bid >= target_ask:
                continue  # invalid (spread too tight)

            # Clamp to valid range
            target_bid = max(0.01, min(0.99, target_bid))
            target_ask = max(0.01, min(0.99, target_ask))

            # Inventory-aware side blocking
            bid_price = target_bid if decision.allow_bid else None
            ask_price = target_ask if decision.allow_ask else None

            # CRITICAL: Don't place bid if bankroll can't cover it
            # (simulates Polymarket API rejecting order if insufficient balance)
            if bid_price is not None and self.inventory.bankroll < level_size:
                log.debug(
                    "bid_blocked_insufficient_balance",
                    market=market_name[:30],
                    level=level_idx,
                    level_size=round(level_size, 2),
                    bankroll=round(self.inventory.bankroll, 2),
                )
                bid_price = None

            # CRITICAL: Don't place ask if not enough tokens to sell
            # In LIVE: Polymarket API rejects SELL if insufficient token balance
            # (no traditional shorting on CTF — can only sell what you own)
            inv = self.inventory.get_inventory(token_id)
            if ask_price is not None and inv.net_tokens <= 0:
                # No tokens to sell (or already short) — block ask
                log.debug(
                    "ask_blocked_no_tokens",
                    market=market_name[:30],
                    level=level_idx,
                    net_tokens=round(inv.net_tokens, 4),
                    reason="no tokens to sell (LIVE API would reject)",
                )
                ask_price = None

            # Don't sell below entry price (when long) — prevents realized losses
            # BUT allow if position is aged (stuck > aging threshold) to liquidate
            if ask_price is not None and inv.net_tokens > 0:
                age_sec = time.monotonic() - inv.open_time if inv.open_time else 0
                is_aged = age_sec > settings.inventory_aging_threshold_sec
                if not is_aged and ask_price < inv.avg_entry_price:
                    log.debug(
                        "ask_blocked_below_entry",
                        market=market_name[:30],
                        level=level_idx,
                        ask_price=round(ask_price, 4),
                        avg_entry=round(inv.avg_entry_price, 4),
                        age_sec=round(age_sec, 0),
                        reason="selling below entry would realize loss",
                    )
                    ask_price = None
                elif is_aged and ask_price < inv.avg_entry_price:
                    log.info(
                        "ask_aged_selling_below_entry",
                        market=market_name[:30],
                        level=level_idx,
                        ask_price=round(ask_price, 4),
                        avg_entry=round(inv.avg_entry_price, 4),
                        age_sec=round(age_sec, 0),
                        reason="position aged, liquidating even at loss",
                    )

            if bid_price is None and ask_price is None:
                continue

            # Place the quote
            quote = await self._place_quote_level(
                token_id=token_id,
                level=level_idx,
                bid_price=bid_price,
                ask_price=ask_price,
                size_usdc=level_size,
                mid=book.mid,
                reservation=reservation,
                spread_cents=spread_cents,
                market_name=market_name,
                book=book,
                inventory_usdc=inventory_usdc,
                inventory_tokens=inventory_tokens,
                ttr_hours=ttr_hours,
            )
            if quote:
                new_quotes.append(quote)

        if new_quotes:
            self.active_quotes[token_id] = new_quotes

    async def _place_quote_level(
        self,
        token_id: str,
        level: int,
        bid_price: float | None,
        ask_price: float | None,
        size_usdc: float,
        mid: float,
        reservation: float,
        spread_cents: float,
        market_name: str,
        book: MarketBook | None = None,
        inventory_usdc: float = 0.0,
        inventory_tokens: float = 0.0,
        ttr_hours: float | None = None,
    ) -> ActiveQuote | None:
        """Place bid and/or ask for a single level. PAPER=simulate, LIVE=real."""
        if bid_price is None and ask_price is None:
            return None

        bid_order_id = None
        ask_order_id = None

        if not settings.paper_trading:
            # LIVE: place real orders
            if bid_price is not None:
                result: OrderResult = await self.clob.place_order(
                    token_id, "BUY", bid_price, size_usdc, post_only=True
                )
                if result.success:
                    bid_order_id = result.order_id
                else:
                    log.warning(
                        "live_bid_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error,
                    )
                    bid_price = None  # don't track failed order

            if ask_price is not None:
                result = await self.clob.place_order(
                    token_id, "SELL", ask_price, size_usdc, post_only=True
                )
                if result.success:
                    ask_order_id = result.order_id
                else:
                    log.warning(
                        "live_ask_failed",
                        market=market_name[:30],
                        level=level,
                        error=result.error,
                    )
                    ask_price = None

            if bid_price is None and ask_price is None:
                return None

        quote = ActiveQuote(
            token_id=token_id,
            level=level,
            bid_price=bid_price,
            ask_price=ask_price,
            mid_at_place=mid,
            size_usdc=size_usdc,
            reservation_price=reservation,
            spread_cents=spread_cents,
            bid_order_id=bid_order_id,
            ask_order_id=ask_order_id,
        )

        # Compute our actual spread (after clamps) for logging
        our_bid = bid_price if bid_price is not None else None
        our_ask = ask_price if ask_price is not None else None
        our_spread_cents = (
            round((our_ask - our_bid) * 100, 2)
            if (our_bid is not None and our_ask is not None)
            else None
        )

        # Market context (from book, if available)
        market_bid_log = round(book.best_bid, 4) if book and book.best_bid > 0 else None
        market_ask_log = round(book.best_ask, 4) if book and book.best_ask < 1 else None
        market_spread_log = round(book.spread * 100, 2) if book else None

        log.info(
            "quote_placed",
            market=market_name[:30],
            level=level,
            # Market context (what the order book shows)
            market_bid=market_bid_log,
            market_ask=market_ask_log,
            market_spread_cents=market_spread_log,
            # Our quote (inside the market spread)
            our_bid=round(our_bid, 4) if our_bid is not None else None,
            our_ask=round(our_ask, 4) if our_ask is not None else None,
            our_spread_cents=our_spread_cents,
            # Strategy context
            mid=round(mid, 4),
            reservation=round(reservation, 4),
            optimal_spread_cents=round(spread_cents, 2),
            size_usdc=round(size_usdc, 2),
            # Inventory state (per user request)
            inventory_usdc=round(inventory_usdc, 2),
            inventory_tokens=round(inventory_tokens, 4),
            # Time to resolution (per user request — "ttr hours")
            ttr_hours=ttr_hours,
            mode="LIVE" if not settings.paper_trading else "PAPER",
        )
        return quote

    # ── Cancel ────────────────────────────────────────────────────────────

    async def _cancel_all_levels(self, token_id: str) -> None:
        quotes = self.active_quotes.pop(token_id, [])
        for q in quotes:
            await self._cancel_quote_level(token_id, q)

    async def _cancel_quote_level(self, token_id: str, quote: ActiveQuote) -> None:
        if not settings.paper_trading:
            if quote.bid_order_id:
                await self.clob.cancel_order(quote.bid_order_id)
                self._pending_orders.pop(quote.bid_order_id, None)
            if quote.ask_order_id:
                await self.clob.cancel_order(quote.ask_order_id)
                self._pending_orders.pop(quote.ask_order_id, None)

    # ── Fill checking ─────────────────────────────────────────────────────

    async def _check_fills(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """Check for fills on existing quotes. PAPER=simulate, LIVE=poll."""
        if settings.paper_trading:
            await self._check_fills_paper(token_id, book, quotes, market_name)
        # LIVE mode: fills are detected in _poll_orders_loop

    async def _check_fills_paper(
        self,
        token_id: str,
        book: MarketBook,
        quotes: list[ActiveQuote],
        market_name: str,
    ) -> None:
        """PAPER-mode fill simulation with realistic adverse selection."""
        direction = self._get_market_direction(token_id)

        for quote in quotes:
            # ── Bid fill simulation ──
            if not quote.bid_filled and quote.bid_price and quote.bid_price > 0:
                market_bid = book.best_bid
                if market_bid > 0:
                    distance = abs(quote.bid_price - market_bid)
                    if quote.bid_price >= market_bid - 0.003 and distance <= 0.015:
                        # Order rejection (15% — realistic Polymarket rate)
                        # Don't mark as filled — just skip this cycle (retry next)
                        if random.random() < 0.15:
                            continue
                        # Competition (40% — other MMs take the fill)
                        if random.random() < 0.40:
                            continue
                        # Directional bias (0.3 — informed traders)
                        direction_mult = 1.0 + (direction * -0.3)
                        # Fill probability (2.5% base — realistic Polymarket frequency)
                        market_spread = book.spread
                        activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                        closeness = 1.0 - (distance / 0.015)
                        fill_prob = 0.025 * closeness * activity_mult * max(0.5, direction_mult)
                        fill_prob = min(0.08, max(0.005, fill_prob))

                        if random.random() < fill_prob:
                            # Adverse drift proportional to price (0.5% of price)
                            # Fixed 0.001-0.003 was 75% on $0.004 markets → fake P&L
                            adverse_drift = book.mid * random.uniform(0.005, 0.015)
                            fill_price = min(quote.bid_price + adverse_drift, market_bid + 0.001)
                            # Partial fills (20% none, 40% partial, 40% full — realistic)
                            partial_roll = random.random()
                            if partial_roll < 0.20:
                                continue
                            elif partial_roll < 0.60:
                                fill_pct = random.uniform(0.40, 0.75)
                            else:
                                fill_pct = random.uniform(0.85, 1.0)
                            fill_size = quote.size_usdc * fill_pct
                            if fill_size < 1.0:
                                continue
                            if not self.inventory.should_quote_bid(token_id):
                                await self._cancel_all_levels(token_id)
                                return
                            # CRITICAL: check bankroll has enough cash for BUY
                            # (simulates Polymarket API rejecting order if insufficient balance)
                            if self.inventory.bankroll < fill_size:
                                log.warning(
                                    "fill_skipped_insufficient_balance",
                                    side="BUY",
                                    market=market_name[:30],
                                    fill_size=round(fill_size, 2),
                                    bankroll=round(self.inventory.bankroll, 2),
                                    reason="not enough cash to buy (would be rejected in LIVE)",
                                )
                                continue
                            await self._record_fill(
                                token_id, "BUY", fill_price, fill_size, market_name,
                                level=quote.level, mid_at_fill=quote.mid_at_place,
                            )
                            quote.bid_filled = True

            # ── Ask fill simulation ──
            if not quote.ask_filled and quote.ask_price and quote.ask_price < 1:
                market_ask = book.best_ask
                if market_ask < 1:
                    distance = abs(quote.ask_price - market_ask)
                    if quote.ask_price <= market_ask + 0.003 and distance <= 0.015:
                        # Order rejection (15% — realistic Polymarket rate)
                        # Don't mark as filled — just skip this cycle (retry next)
                        if random.random() < 0.15:
                            continue
                        # Competition (40% — other MMs take the fill)
                        if random.random() < 0.40:
                            continue
                        # Directional bias (0.3 — informed traders)
                        direction_mult = 1.0 + (direction * 0.3)
                        market_spread = book.spread
                        activity_mult = 1.3 if market_spread < 0.015 else (0.6 if market_spread > 0.04 else 1.0)
                        closeness = 1.0 - (distance / 0.015)
                        fill_prob = 0.025 * closeness * activity_mult * max(0.5, direction_mult)
                        fill_prob = min(0.08, max(0.005, fill_prob))

                        if random.random() < fill_prob:
                            # Adverse drift proportional to price (0.5% of price)
                            adverse_drift = book.mid * random.uniform(0.005, 0.015)
                            fill_price = max(quote.ask_price - adverse_drift, market_ask - 0.001)
                            fill_price = max(0.01, min(0.99, fill_price))
                            # Partial fills (20% none, 40% partial, 40% full — realistic)
                            partial_roll = random.random()
                            if partial_roll < 0.20:
                                continue
                            elif partial_roll < 0.60:
                                fill_pct = random.uniform(0.40, 0.75)
                            else:
                                fill_pct = random.uniform(0.85, 1.0)
                            fill_size = quote.size_usdc * fill_pct
                            if fill_size < 1.0:
                                continue
                            # CRITICAL: Check if we have tokens to sell
                            # In LIVE: Polymarket API rejects SELL if insufficient token balance
                            inv_now = self.inventory.get_inventory(token_id)
                            tokens_to_sell = fill_size / max(fill_price, 0.001)
                            if inv_now.net_tokens < tokens_to_sell:
                                log.warning(
                                    "sell_fill_skipped_no_tokens",
                                    market=market_name[:30],
                                    net_tokens=round(inv_now.net_tokens, 4),
                                    tokens_to_sell=round(tokens_to_sell, 4),
                                    reason="insufficient tokens (LIVE API would reject)",
                                )
                                continue
                            if not self.inventory.should_quote_ask(token_id):
                                await self._cancel_all_levels(token_id)
                                return
                            await self._record_fill(
                                token_id, "SELL", fill_price, fill_size, market_name,
                                level=quote.level, mid_at_fill=quote.mid_at_place,
                            )
                            quote.ask_filled = True

            # ── Round-trip detection (per level) ──
            if quote.bid_filled and quote.ask_filled:
                buy_p = quote.bid_price or 0
                sell_p = quote.ask_price or 0
                log.info(
                    "round_trip",
                    market=market_name[:40],
                    level=quote.level,
                    buy=round(buy_p, 4),
                    sell=round(sell_p, 4),
                    gross_spread=round(sell_p - buy_p, 4),
                )
                ROUND_TRIPS_TOTAL.inc()
                self._round_trip_count += 1

        # Remove fully-filled quotes
        self.active_quotes[token_id] = [q for q in quotes if not (q.bid_filled and q.ask_filled)]
        if not self.active_quotes[token_id]:
            self.active_quotes.pop(token_id, None)

    def _get_market_direction(self, token_id: str) -> float:
        """Estimate short-term direction (-1..+1) from price history."""
        state = self._as_calc.get_state(token_id)
        if not state or len(state.price_history) < 5:
            return 0.0
        prices = [p for _, p in state.price_history]
        recent = prices[-1]
        past = prices[-5]
        if past == 0:
            return 0.0
        change = (recent - past) / past
        return max(-1.0, min(1.0, change * 50))

    # ── LIVE mode: order polling ──────────────────────────────────────────

    async def _poll_orders_loop(self) -> None:
        """In LIVE mode: poll order status to detect fills."""
        await asyncio.sleep(5)
        while self._running:
            try:
                await self._poll_orders()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("poll_error", error=str(e))
            await asyncio.sleep(3)

    async def _poll_orders(self) -> None:
        if not self._pending_orders:
            return
        from py_clob_client.clob_types import OpenOrderParams

        try:
            open_orders = self.clob._client.get_orders(OpenOrderParams())
        except Exception as e:
            log.warning("poll_orders_failed", error=str(e))
            return

        open_ids = {o.get("id") for o in open_orders if isinstance(o, dict)}
        now_mono = time.monotonic()

        for order_id in list(self._pending_orders.keys()):
            info = self._pending_orders[order_id]
            age = now_mono - info["placed_at"]

            # If order is no longer in open list → it filled or was canceled
            if order_id not in open_ids:
                # Check final status via get_order
                try:
                    final = self.clob._client.get_order(order_id)
                    status = (final.get("status", "") or "").upper() if isinstance(final, dict) else ""
                    if status in ("MATCHED", "FILLED", "FILLED_PARTIAL"):
                        filled_size = float(final.get("size_matched", info["size_usdc"]))
                        fill_price = float(final.get("price", info["price"]))
                        await self._record_fill(
                            info["token_id"], info["side"], fill_price,
                            filled_size, info["market_name"],
                            level=info.get("level", 1),
                            mid_at_fill=info.get("mid_at_place", fill_price),
                        )
                except Exception as e:
                    log.debug("get_order_failed", order_id=order_id, error=str(e))
                self._pending_orders.pop(order_id, None)
            elif age > 30:
                # Timeout: cancel
                await self.clob.cancel_order(order_id)
                self._pending_orders.pop(order_id, None)

    # ── Fill recording ────────────────────────────────────────────────────

    async def _record_fill(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        market_name: str,
        level: int = 1,
        mid_at_fill: float | None = None,
        is_liquidation: bool = False,
        is_hedge: bool = False,
        _skip_hedge: bool = False,
    ) -> None:
        """Record a fill in inventory + DB. Triggers hedge if applicable."""
        # CRITICAL: Balance/short checks for hedge fills too
        # Hedge fills bypass the quote-placement checks (they come from _attempt_active_hedge)
        # but still must respect balance and short limits
        if is_hedge:
            inv_check = self.inventory.get_inventory(token_id)
            if side == "BUY":
                # Hedge BUY: check bankroll has enough cash
                if self.inventory.bankroll < size_usdc:
                    log.warning(
                        "hedge_fill_skipped_insufficient_balance",
                        market=market_name[:30],
                        side=side,
                        size_usdc=round(size_usdc, 2),
                        bankroll=round(self.inventory.bankroll, 2),
                    )
                    return
            elif side == "SELL":
                # Hedge SELL: check we have tokens to sell (no shorting allowed)
                tokens_to_sell = size_usdc / max(price, 0.001)
                if inv_check.net_tokens < tokens_to_sell:
                    log.warning(
                        "hedge_fill_skipped_no_tokens",
                        market=market_name[:30],
                        side=side,
                        net_tokens=round(inv_check.net_tokens, 4),
                        tokens_to_sell=round(tokens_to_sell, 4),
                        reason="insufficient tokens for hedge (LIVE API would reject)",
                    )
                    return

        realized = self.inventory.on_fill(token_id, side, price, size_usdc, market_name)

        # Costs
        gas_cost = 0.005 if settings.paper_trading else 0.001
        fees_usdc = gas_cost
        realized_net = realized - fees_usdc
        self.inventory.bankroll -= fees_usdc

        self._fill_count += 1
        FILLS_TOTAL.labels(side=side, mode="LIVE" if not settings.paper_trading else "PAPER").inc()

        if mid_at_fill is None:
            mid_at_fill = price

        log.info(
            "fill",
            market=market_name[:50],
            side=side,
            price=round(price, 4),
            size_usdc=round(size_usdc, 2),
            pnl_net=round(realized_net, 4),
            inv_after=round(self.inventory.get_inventory(token_id).net_tokens, 4),
            level=level,
            mode="LIVE" if not settings.paper_trading else "PAPER",
            liquidation=is_liquidation,
            hedge=is_hedge,
        )

        # Persist to DB
        await self._persist_trade(
            token_id, side, price, size_usdc, realized_net, fees_usdc, market_name,
            level, is_hedge,
        )

        # Update adverse selection tracking
        self.risk.on_fill(token_id, side, price, mid_at_fill)

        # Trigger hedge (Yes/No pair) — only on real fills, not on hedge fills
        if (
            settings.hedging_enabled
            and settings.hedging_active_enabled
            and not _skip_hedge
            and not is_liquidation
        ):
            try:
                await self._attempt_active_hedge(token_id, side, size_usdc, market_name, price)
            except Exception as e:
                log.debug("hedge_failed", error=str(e))

    async def _attempt_active_hedge(
        self,
        filled_token_id: str,
        filled_side: str,
        filled_size_usdc: float,
        market_name: str,
        filled_price: float,
    ) -> None:
        """Hedge by trading the paired Yes/No token (YES+NO=$1, risk-free).

        When we BUY YES at price P_yes, we can also BUY NO at P_no.
        If P_yes + P_no < 1.0, the position is risk-free (one side always pays $1).
        Same for SELL: SELL YES + SELL NO when P_yes_bid + P_no_bid > 1.0.
        """
        paired_token = self._get_paired_token(filled_token_id)
        if not paired_token:
            log.debug(
                "hedge_skipped_no_pair",
                filled_market=market_name[:30],
                filled_side=filled_side,
                reason="no paired Yes/No token found",
            )
            return
        paired_book = self.clob.books.get(paired_token)
        if not paired_book or not paired_book.bids or not paired_book.asks:
            log.debug(
                "hedge_skipped_no_book",
                filled_market=market_name[:30],
                reason="paired token has no order book",
            )
            return
        paired_info = self.clob.markets.get(paired_token)
        paired_name = paired_info.question[:50] if paired_info else paired_token[:12]

        if filled_side == "BUY":
            hedge_side = "BUY"
            hedge_price = paired_book.best_ask + 0.003
            if hedge_price > 0.99:
                log.debug("hedge_skipped_price", reason="hedge_price > 0.99")
                return
            # Profitability check: YES_ask + NO_ask must be < $1.00
            total_cost = filled_price + paired_book.best_ask
            if total_cost >= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_ask=round(paired_book.best_ask, 4),
                    total=round(total_cost, 4),
                    reason="YES_ask + NO_ask >= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (1.0 - total_cost) * 100
        else:
            hedge_side = "SELL"
            hedge_price = paired_book.best_bid - 0.003
            if hedge_price < 0.01:
                log.debug("hedge_skipped_price", reason="hedge_price < 0.01")
                return
            # Profitability check: YES_bid + NO_bid must be > $1.00
            total_revenue = filled_price + paired_book.best_bid
            if total_revenue <= 1.0:
                log.debug(
                    "hedge_skipped_unprofitable",
                    filled_price=round(filled_price, 4),
                    paired_bid=round(paired_book.best_bid, 4),
                    total=round(total_revenue, 4),
                    reason="YES_bid + NO_bid <= $1.00 (no arbitrage)",
                )
                return
            profit_cents = (total_revenue - 1.0) * 100

        hedge_size = filled_size_usdc
        if hedge_size < 1.0:
            return

        self._hedge_attempts += 1

        log.info(
            "hedge_attempt",
            filled_market=market_name[:30],
            filled_side=filled_side,
            filled_price=round(filled_price, 4),
            paired_market=paired_name[:30],
            hedge_side=hedge_side,
            hedge_price=round(hedge_price, 4),
            profit_cents=round(profit_cents, 2),
            size_usdc=round(hedge_size, 2),
        )

        if settings.paper_trading:
            if random.random() < 0.80:
                actual_price = hedge_price + random.uniform(-0.0005, 0.0005)
                actual_price = max(0.01, min(0.99, actual_price))
                await self._record_fill(
                    paired_token, hedge_side, actual_price, hedge_size, paired_name,
                    _skip_hedge=True, is_hedge=True,
                )
                self._hedge_fills += 1
                log.info(
                    "hedge_filled",
                    paired_market=paired_name[:40],
                    side=hedge_side,
                    price=round(actual_price, 4),
                    size_usdc=round(hedge_size, 2),
                    profit_cents=round(profit_cents, 2),
                )
            else:
                log.debug("hedge_not_filled", reason="20% paper rejection")

    def _build_hedging_pairs(self) -> None:
        """Link Yes and No tokens sharing the same condition_id.

        Also supports fallback pairing by identical question text when
        condition_id is missing (some markets on Polymarket don't expose it
        via the events API).
        """
        self._condition_pairs.clear()
        by_condition: dict[str, list[str]] = {}
        by_question: dict[str, list[str]] = {}

        for tid, info in self.clob.markets.items():
            cid = info.condition_id
            if cid:
                by_condition.setdefault(cid, []).append(tid)
            # Fallback: group by question text (Yes/No outcomes share question)
            if info.question:
                by_question.setdefault(info.question, []).append(tid)

        # Primary: by condition_id
        for cid, tokens in by_condition.items():
            if len(tokens) == 2:
                self._register_pair(cid, tokens)

        # Fallback: by question text (only add if not already paired via condition_id)
        already_paired = set()
        for pair in self._condition_pairs.values():
            already_paired.add(pair["yes"])
            already_paired.add(pair["no"])

        for q, tokens in by_question.items():
            if len(tokens) == 2 and tokens[0] not in already_paired:
                # Use question hash as key to avoid collisions
                key = f"q:{hash(q)}"
                self._register_pair(key, tokens)

        if self._condition_pairs:
            log.info(
                "hedging_pairs_built",
                pairs=len(self._condition_pairs),
                by_condition=sum(1 for k in self._condition_pairs if not k.startswith("q:")),
                by_question=sum(1 for k in self._condition_pairs if k.startswith("q:")),
            )

    def _register_pair(self, key: str, tokens: list[str]) -> None:
        """Register a Yes/No pair, determining which is Yes by outcome field."""
        info0 = self.clob.markets.get(tokens[0])
        info1 = self.clob.markets.get(tokens[1])
        if not info0 or not info1:
            return
        # Determine Yes/No by outcome field (case-insensitive)
        out0 = (info0.outcome or "").lower().strip()
        out1 = (info1.outcome or "").lower().strip()
        if out0 == "yes" and out1 == "no":
            self._condition_pairs[key] = {"yes": tokens[0], "no": tokens[1]}
        elif out0 == "no" and out1 == "yes":
            self._condition_pairs[key] = {"yes": tokens[1], "no": tokens[0]}
        else:
            # Fallback: token with higher mid price = "Yes" (probability of event)
            if info0 and info1:
                yes_token = tokens[0] if self.clob.books.get(tokens[0]) and self.clob.books[tokens[0]].mid > 0.5 else tokens[1]
                no_token = tokens[1] if yes_token == tokens[0] else tokens[0]
                self._condition_pairs[key] = {"yes": yes_token, "no": no_token}

    def _get_paired_token(self, token_id: str) -> str | None:
        for pair in self._condition_pairs.values():
            if pair["yes"] == token_id:
                return pair["no"]
            if pair["no"] == token_id:
                return pair["yes"]
        return None

    # ── DB persistence ────────────────────────────────────────────────────

    async def _persist_trade(
        self,
        token_id: str,
        side: str,
        price: float,
        size_usdc: float,
        pnl: float,
        fees_usdc: float,
        market_name: str,
        level: int,
        is_hedge: bool,
    ) -> None:
        try:
            from app.core.db import AsyncSessionLocal

            async with AsyncSessionLocal() as db:
                t = Trade(
                    market_id=token_id,
                    market_name=market_name,
                    condition_id=self.clob.markets.get(token_id, None).condition_id
                    if self.clob.markets.get(token_id)
                    else "",
                    side=Side.BUY if side == "BUY" else Side.SELL,
                    price=price,
                    size_usdc=size_usdc,
                    size_tokens=size_usdc / max(price, 0.001),
                    pnl_usdc=pnl,
                    fees_usdc=fees_usdc,
                    inventory_after=self.inventory.get_inventory(token_id).net_tokens,
                    spread_cents=self._get_active_spread(token_id),
                    level=level,
                    mode=OrderMode.LIVE if not settings.paper_trading else OrderMode.PAPER,
                    is_hedge=is_hedge,
                )
                db.add(t)
                await db.commit()
        except Exception as e:
            log.debug("trade_persist_failed", error=str(e))

    def _get_active_spread(self, token_id: str) -> float | None:
        quotes = self.active_quotes.get(token_id)
        if not quotes:
            return None
        return quotes[0].spread_cents

    async def _db_cleanup_loop(self) -> None:
        """Every 10 minutes, prune old quotes + snapshots (keep last 1000 each)."""
        await asyncio.sleep(600)
        while self._running:
            try:
                from app.core.db import AsyncSessionLocal
                from sqlalchemy import text

                async with AsyncSessionLocal() as db:
                    await db.execute(
                        text(
                            "DELETE FROM mm_quotes WHERE id NOT IN "
                            "(SELECT id FROM mm_quotes ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_snapshots WHERE id NOT IN "
                            "(SELECT id FROM mm_snapshots ORDER BY id DESC LIMIT 1000)"
                        )
                    )
                    await db.execute(
                        text(
                            "DELETE FROM mm_metric_points WHERE id NOT IN "
                            "(SELECT id FROM mm_metric_points ORDER BY id DESC LIMIT 5000)"
                        )
                    )
                    await db.commit()
            except Exception as e:
                log.debug("db_cleanup_error", error=str(e))
            await asyncio.sleep(600)

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        return {
            "cycle_count": self._cycle_count,
            "fill_count": self._fill_count,
            "round_trip_count": self._round_trip_count,
            "active_quotes": sum(len(qs) for qs in self.active_quotes.values()),
            "pending_live_orders": len(self._pending_orders) if not settings.paper_trading else 0,
            "mode": "LIVE" if not settings.paper_trading else "PAPER",
            "trading_paused": self._trading_paused,
            "halted": self.inventory.halted,
            "halt_reason": self.inventory.halt_reason,
            "hedge_attempts": self._hedge_attempts,
            "hedge_fills": self._hedge_fills,
            "hedge_fill_rate_pct": round(
                self._hedge_fills / max(self._hedge_attempts, 1) * 100, 1
            ),
            "adverse_global_cooldown_sec": round(
                self.risk.adverse_selection.global_cooldown_remaining(), 1
            ),
            "quotes_detail": [
                {
                    "token_id": q.token_id[:12],
                    "market_name": next(
                        (i.question[:30] for i in self.clob.markets.values()
                         if i.token_id == q.token_id),
                        q.token_id[:12]
                    ),
                    "level": q.level,
                    "bid": round(q.bid_price, 4) if q.bid_price is not None else None,
                    "ask": round(q.ask_price, 4) if q.ask_price is not None else None,
                    "mid": round(q.mid_at_place, 4),
                    "reservation": round(q.reservation_price, 4),
                    "optimal_spread_cents": round(q.spread_cents, 2),
                    "our_spread_cents": round(
                        (q.ask_price - q.bid_price) * 100, 2
                    ) if q.bid_price is not None and q.ask_price is not None else None,
                    "bid_filled": q.bid_filled,
                    "ask_filled": q.ask_filled,
                    "age_sec": round(time.monotonic() - q.placed_at, 1),
                }
                for qs in self.active_quotes.values()
                for q in qs
            ],
        }
