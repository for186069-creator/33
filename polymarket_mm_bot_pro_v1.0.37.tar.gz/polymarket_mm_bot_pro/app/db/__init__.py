"""app.db — ORM models + DB initialization."""
